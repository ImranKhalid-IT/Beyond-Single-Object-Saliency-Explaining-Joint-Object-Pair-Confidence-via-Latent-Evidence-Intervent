from __future__ import annotations

import numpy as np

from rce_suite.geometry import calculate_iou, union_box
from rce_suite.metrics import concept_effect
from rce_suite.statistics import holm_adjust, wilson_interval


def test_union_box() -> None:
    a = np.array([10, 20, 30, 40], dtype=np.float32)
    b = np.array([25, 5, 50, 35], dtype=np.float32)
    assert np.allclose(union_box(a, b), [10, 5, 50, 40])


def test_iou() -> None:
    a = np.array([0, 0, 10, 10], dtype=np.float32)
    b = np.array([5, 5, 15, 15], dtype=np.float32)
    assert np.isclose(calculate_iou(a, b), 25 / 175)


def test_manuscript_concept_effect() -> None:
    value = concept_effect(0.8, 0.5, 0.4, 0.25)
    assert np.isclose(value, 0.8 * 0.5 - 0.4 * 0.25)


def test_holm_adjust_monotonic() -> None:
    adjusted = holm_adjust([0.01, 0.04, 0.03])
    assert all(0 <= value <= 1 for value in adjusted)


def test_wilson_interval() -> None:
    low, high = wilson_interval(95, 100)
    assert 0 < low < 0.95 < high <= 1
