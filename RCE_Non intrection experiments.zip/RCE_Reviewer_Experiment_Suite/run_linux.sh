#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run_experiments.py --config config.json check
printf '\nEnvironment is ready. See README.md for the next command.\n'
