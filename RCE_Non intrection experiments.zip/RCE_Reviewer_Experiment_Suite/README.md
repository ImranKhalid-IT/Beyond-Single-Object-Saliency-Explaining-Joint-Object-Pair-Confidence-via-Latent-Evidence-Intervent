# RCE Reviewer Experiment Suite

This project consolidates the uploaded RCE/COCO and baseline-comparison code into a standalone Python experiment suite. It is designed for the **remaining reviewer requests**, not merely for producing qualitative heatmaps.

## What the suite runs

The main command performs the following operations on every object pair in a manifest:

1. Matches both detector instances using **class and IoU**, with a default IoU threshold of `0.30` rather than accepting any same-class detection.
2. Extracts union-region YOLOv5 features and discovers `K` image-specific concepts.
3. Uses the manuscript-consistent squared Euclidean similarity and the configured softmax temperature.
4. Applies percentile masking and Gaussian replacement.
5. Calculates the manuscript concept-effect score:

   `CE_k = (score_a × score_b) − (post_score_a × post_score_b)`

6. Evaluates RCE and every enabled baseline using the **same pair, union region, Gaussian replacement, disappearance rule, deletion fractions, and AOC calculation**.
7. Runs the activation-ranking versus intervention-ranking ablation.
8. Runs paired Wilcoxon tests for AOC comparisons, bootstrap confidence intervals, and Holm correction.
9. When the manifest contains both `relation_label=1` and `relation_label=0`, runs the positive-versus-non-interacting experiment with Mann–Whitney tests, effect sizes, bootstrap intervals, and ROC AUC.
10. Runs real sensitivity experiments for `K`, temperature, intervention percentile, and blur radius. No simulated sensitivity values are used.
11. Analyzes expert/non-expert human-study data, including Wilson confidence intervals, Fleiss' kappa, and the reviewer check for at least 30 non-experts.

## Important scientific boundary: GCE and CoE

The supplied files do not contain complete GCE or CoE implementations. The suite therefore **does not invent them or report fabricated values**. It includes a ready external-adapter interface in `templates/external_baselines.json`.

After a genuine GCE/CoE implementation is available, enable the corresponding entry and provide a command that reads the generated request JSON and saves one pair-level saliency map as `.npy`. The main experiment will then evaluate that map under the same AOC protocol and include it automatically in the tables and figures.

`CRAFT-adapted` is clearly labelled as a detector adaptation of the NMF concept core. It is never presented as an unchanged official detector implementation.

## 1. Install

### Windows

Open Command Prompt inside this folder and run:

```bat
run_windows.bat
```

Or install manually:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run_experiments.py --config config.json check
```

### Linux or Google Colab terminal

```bash
bash run_linux.sh
```

The first model run needs internet access because YOLOv5 weights are loaded through Torch Hub.

## 2. Choose the dataset workflow

### Option A: Visual Genome — strongest response to the dataset and negative-pair reviewer comments

Download/extract Visual Genome images and `relationships.json`, then run:

```bash
python run_experiments.py --config config.json prepare-vg \
  --relationships-json "D:/VisualGenome/relationships.json" \
  --image-root "D:/VisualGenome" \
  --output "data/visual_genome_pair_manifest.csv" \
  --max-positive 100 \
  --max-negative 100
```

The generated positive pairs have explicit Visual Genome relationship annotations. Candidate negatives are nearby co-occurring object pairs with no annotated relation. Because Visual Genome can have missing annotations, check the generated contact sheets before publication and correct any questionable `relation_label` values.

### Option B: COCO — manual positive/negative annotation required

```bash
python run_experiments.py --config config.json prepare-coco \
  --coco-root "data/coco" \
  --output "data/coco_pair_manifest.csv" \
  --candidates-per-pair 30
```

This downloads COCO 2017 validation data when needed and creates contact sheets. COCO does **not** contain relationship annotations. Open the CSV and fill:

- `relation_label = 1`: genuine visible interaction/relation
- `relation_label = 0`: spatial co-occurrence without visible interaction

Do not leave labels blank when claiming the positive-versus-negative experiment.

Additional pairs can be requested:

```bash
python run_experiments.py --config config.json prepare-coco \
  --pair person+bicycle \
  --pair person+laptop \
  --pair person+tv \
  --pair person+horse
```

## 3. Run the reviewer experiment

```bash
python run_experiments.py --config config.json run-main \
  --manifest "data/visual_genome_pair_manifest.csv" \
  --external-baselines "templates/external_baselines.json"
```

Outputs are written under `outputs/`:

- `all_pair_results.csv`
- `errors.csv`
- `statistics/paired_baseline_statistics.csv`
- `statistics/positive_vs_negative_statistics.csv` when both labels exist
- one folder per pair containing concept scores, pair maps, AOC curves, figures, and a JSON audit trail

## 4. Run real hyperparameter sensitivity

```bash
python run_experiments.py --config config.json run-sensitivity \
  --manifest "data/visual_genome_pair_manifest.csv"
```

The tested values are controlled in `config.json`:

- `K`: 2, 4, 6, 8, 10, 12, 14
- temperature: 0.01, 0.03, 0.05, 0.10, 0.20
- percentile: 75, 80, 85, 90, 95
- blur radius: 5, 10, 15, 20, 25

This experiment is computationally expensive. Start with `sensitivity_max_pairs: 3` to validate the installation, then increase it for the final paper run.

## 5. Analyze the human study

Use `templates/human_study.csv` as the required format:

```bash
python run_experiments.py --config config.json human-stats \
  --human-csv "data/human_study.csv"
```

The `expertise` field should clearly distinguish `expert` and `non-expert`. The script reports whether the unique non-expert count reaches 30.

## 6. Run everything

```bash
python run_experiments.py --config config.json run-all \
  --manifest "data/visual_genome_pair_manifest.csv" \
  --human-csv "data/human_study.csv"
```

## Fast validation versus paper mode

The default configuration is a validation setting. For a final run:

- set `paper_mode` to `true`;
- use at least 100 labelled pairs where feasible;
- keep a balanced positive/negative sample;
- use a GPU;
- inspect `errors.csv` rather than silently ignoring failed pairs;
- preserve `run_config.json`, per-pair JSON files, and the environment versions for reproducibility.

`paper_mode=true` raises D-RISE to at least 1,000 masks and increases the default pair counts. This can take many hours.

## External GCE/CoE adapter contract

For each pair, the suite writes a request JSON containing:

- image path and image ID;
- both matched detections and boxes;
- union-region box;
- expected output height and width.

Your adapter command must save a float NumPy array to the requested `.npy` path. The array must match the original image dimensions. The suite then normalizes and evaluates it using the common AOC protocol.

Example configuration:

```json
{
  "GCE": {
    "enabled": true,
    "command": "python D:/GCE/gce_adapter.py --request \"{request_json}\" --output \"{output_npy}\""
  },
  "CoE": {
    "enabled": false,
    "command": "python D:/CoE/coe_adapter.py --request \"{request_json}\" --output \"{output_npy}\""
  }
}
```

## Recommended sequence

1. `check`
2. `prepare-vg` or `prepare-coco`
3. inspect/correct relation labels
4. `run-main` on 3–5 pairs
5. inspect figures and `errors.csv`
6. increase sample size
7. `run-sensitivity`
8. `human-stats`
9. freeze the configuration and run the final paper experiment

## Test core calculations

```bash
pip install pytest
pytest -q
```

The tests include the union box, IoU, Wilson interval, and the exact joint-confidence `CE_k` formula used by the manuscript.

---

## Google Colab import error: `No module named rce_suite`

This error means Colab has the notebook but not the complete project package on its Python path. Upload the complete `RCE_Reviewer_Experiment_Suite.zip`, then use `RCE_Reviewer_Colab_FIXED.ipynb`. Its first cell automatically extracts the ZIP, changes into the correct project directory, installs the dependencies, installs the local package in editable mode, and verifies `from rce_suite.config import ExperimentConfig`.

Do not run the experiment/import cells before the setup cell reports:

```text
SUCCESS: rce_suite is installed and importable.
```
