# Reviewer-comment to experiment-output mapping

| Reviewer issue | Implemented experiment/output | Remaining human/external requirement |
|---|---|---|
| Benchmark limited to three COCO pairs | `prepare-vg` creates a relation-labelled Visual Genome manifest; `prepare-coco` supports additional COCO pairs | Visual Genome images/annotations must be downloaded by the researcher |
| No non-interacting co-occurrence test | Balanced `relation_label=1/0` manifest; `positive_vs_negative_statistics.csv` | Candidate negatives must be visually checked because missing relation annotations are possible |
| GCE and CoE missing from core comparison | External adapter contract automatically adds genuine GCE/CoE maps to the same AOC protocol | Complete GCE/CoE implementations were not present in the supplied files and cannot be fabricated |
| Human study lacked non-experts | `human-stats` reports participant composition and checks whether non-expert count is at least 30 | Real participant data must be supplied |
| High accuracy lacked uncertainty/statistical analysis | Wilson confidence intervals, paired Wilcoxon tests, Mann–Whitney tests, bootstrap intervals, effect sizes, Holm correction | Interpret results only after genuine runs |
| Hyperparameters insufficiently justified | Real sweeps for K, temperature, percentile and blur radius | Final sample size and GPU runtime are researcher decisions |
| 85th percentile appeared arbitrary | Percentile sweep at 75/80/85/90/95 with AOC, top-1 stability and Kendall rank agreement | No simulated values are used |
| Causal language too strong | Code and outputs use “interventional concept effect/necessity”; CE is the local joint-confidence response | Manuscript wording still needs final proofreading |
| Equation/code mismatch | Correct `CE_k=(s_i s_j)-(s'_i s'_j)` and squared Euclidean distance are implemented | Paper equations and captions should use the same definitions |
| Baseline fairness/reproducibility | Same image, detections, union support, Gaussian replacement, disappearance rule, deletion schedule and AOC | CRAFT is labelled `CRAFT-adapted`; external implementations must be documented accurately |
