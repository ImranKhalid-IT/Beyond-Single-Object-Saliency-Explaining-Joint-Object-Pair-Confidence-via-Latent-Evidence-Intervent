from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List


@dataclass
class ExperimentConfig:
    # Reproducibility and runtime
    seed: int = 42
    device: str = "auto"
    output_dir: str = "outputs"
    paper_mode: bool = False

    # Detector
    model_name: str = "yolov5x6"
    model_input_size: int = 1280
    initial_detection_conf: float = 0.05
    intervention_detection_conf: float = 0.01
    detection_nms_iou: float = 0.45
    matching_iou_threshold: float = 0.30

    # RCE operating point
    k_concepts: int = 8
    softmax_temperature: float = 0.05
    activation_percentile: float = 85.0
    blur_radius: float = 15.0

    # Data selection
    max_pairs: int = 30
    min_object_area_fraction: float = 0.005
    max_union_fraction: float = 0.92
    max_gap_fraction: float = 0.35

    # Baselines and AOC
    run_baselines: bool = True
    drise_mask_count: int = 256
    drise_batch_size: int = 8
    drise_grid_size: int = 16
    drise_keep_probability: float = 0.5
    craft_concepts: int = 8
    craft_evaluated_concepts: int = 6
    finer_alpha: float = 1.0
    finer_reference_count: int = 3
    deletion_fractions: List[float] = field(
        default_factory=lambda: [0.0, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50]
    )

    # Sensitivity values requested by the reviewers
    sensitivity_k: List[int] = field(default_factory=lambda: [2, 4, 6, 8, 10, 12, 14])
    sensitivity_temperature: List[float] = field(
        default_factory=lambda: [0.01, 0.03, 0.05, 0.10, 0.20]
    )
    sensitivity_percentile: List[float] = field(
        default_factory=lambda: [75, 80, 85, 90, 95]
    )
    sensitivity_blur: List[float] = field(
        default_factory=lambda: [5, 10, 15, 20, 25]
    )
    sensitivity_max_pairs: int = 10

    # Statistical reporting
    bootstrap_iterations: int = 2000
    confidence_level: float = 0.95

    # Optional external implementations for reviewer-requested GCE/CoE.
    external_baselines_file: str = "templates/external_baselines.json"

    def resolved_device(self) -> str:
        if self.device != "auto":
            return self.device
        try:
            import torch

            return "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            return "cpu"

    def apply_paper_mode(self) -> None:
        if self.paper_mode:
            self.drise_mask_count = max(self.drise_mask_count, 1000)
            self.max_pairs = max(self.max_pairs, 100)
            self.sensitivity_max_pairs = max(self.sensitivity_max_pairs, 30)

    @classmethod
    def from_json(cls, path: str | Path) -> "ExperimentConfig":
        path = Path(path)
        data: Dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        known = set(cls.__dataclass_fields__)
        unknown = sorted(set(data) - known)
        if unknown:
            raise ValueError(f"Unknown configuration fields: {unknown}")
        config = cls(**data)
        config.apply_paper_mode()
        return config

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
