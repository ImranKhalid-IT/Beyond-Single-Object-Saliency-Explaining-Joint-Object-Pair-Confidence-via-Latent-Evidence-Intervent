from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np
import torch
import torchvision
from PIL import Image, ImageFilter
from sklearn.decomposition import NMF
from tqdm.auto import tqdm

from .config import ExperimentConfig
from .detector import (
    Detection,
    YOLOv5Processor,
    _collect_4d_tensors,
    matched_detection_score,
    matched_detection_similarity,
)
from .geometry import (
    LetterboxMeta,
    box_mask,
    feature_map_to_original,
    letterbox_rgb,
    map_box_to_feature,
    normalize_map,
)


@dataclass
class BaselineResult:
    pair_maps: Dict[str, np.ndarray]
    object_maps: Dict[str, np.ndarray]
    metadata: Dict[str, Any]
    runtimes: Dict[str, float]


def combine_object_maps(
    map_a: np.ndarray,
    map_b: np.ndarray,
    union_support: np.ndarray,
) -> np.ndarray:
    """Create a neutral pair-level map from two object-specific explanations.

    The arithmetic mean is used because the baseline methods explain the two
    detections independently. The same combined map is then evaluated with the
    shared pair-level deletion protocol.
    """
    combined = 0.5 * normalize_map(map_a) + 0.5 * normalize_map(map_b)
    combined *= union_support
    return normalize_map(combined, union_support)


def random_drise_masks(
    count: int,
    height: int,
    width: int,
    grid_size: int,
    keep_probability: float,
    seed: int,
) -> Iterable[np.ndarray]:
    rng = np.random.default_rng(seed)
    cell_h = int(math.ceil(height / grid_size))
    cell_w = int(math.ceil(width / grid_size))
    up_h = (grid_size + 1) * cell_h
    up_w = (grid_size + 1) * cell_w
    for _ in range(count):
        coarse = (rng.random((grid_size, grid_size)) < keep_probability).astype(
            np.float32
        )
        upsampled = cv2.resize(coarse, (up_w, up_h), interpolation=cv2.INTER_LINEAR)
        shift_y = int(rng.integers(0, cell_h))
        shift_x = int(rng.integers(0, cell_w))
        yield upsampled[shift_y : shift_y + height, shift_x : shift_x + width]


def drise_pair_maps(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    config: ExperimentConfig,
) -> Tuple[np.ndarray, np.ndarray]:
    image_rgb = np.asarray(image.convert("RGB"), dtype=np.float32)
    height, width = image_rgb.shape[:2]
    saliency_a = np.zeros((height, width), dtype=np.float64)
    saliency_b = np.zeros((height, width), dtype=np.float64)
    masks = list(
        random_drise_masks(
            config.drise_mask_count,
            height,
            width,
            config.drise_grid_size,
            config.drise_keep_probability,
            config.seed,
        )
    )
    for start in tqdm(
        range(0, config.drise_mask_count, config.drise_batch_size),
        desc="D-RISE masks",
        leave=False,
    ):
        batch_masks = masks[start : start + config.drise_batch_size]
        masked_images = [
            Image.fromarray(np.uint8(np.clip(image_rgb * mask[..., None], 0, 255)))
            for mask in batch_masks
        ]
        batch_detections = processor.detect_batch(
            masked_images, conf_threshold=config.intervention_detection_conf
        )
        for mask, detections in zip(batch_masks, batch_detections):
            saliency_a += matched_detection_similarity(detections, detection_a) * mask
            saliency_b += matched_detection_similarity(detections, detection_b) * mask
    denominator = (
        float(config.drise_mask_count) * float(config.drise_keep_probability) + 1e-8
    )
    return normalize_map(saliency_a / denominator), normalize_map(
        saliency_b / denominator
    )


def _find_prediction_tensor(value: Any) -> Optional[torch.Tensor]:
    if torch.is_tensor(value) and value.ndim == 3 and value.shape[-1] >= 6:
        return value
    if isinstance(value, (list, tuple)):
        for item in value:
            found = _find_prediction_tensor(item)
            if found is not None:
                return found
    if isinstance(value, dict):
        for item in value.values():
            found = _find_prediction_tensor(item)
            if found is not None:
                return found
    return None


def xywh_tensor_to_xyxy(boxes: torch.Tensor) -> torch.Tensor:
    x, y, w, h = boxes.unbind(dim=-1)
    return torch.stack((x - w / 2, y - h / 2, x + w / 2, y + h / 2), dim=-1)


def map_box_to_letterbox_tensor(
    box: np.ndarray, meta: LetterboxMeta, device: torch.device
) -> torch.Tensor:
    return torch.tensor(
        [
            box[0] * meta.ratio + meta.left,
            box[1] * meta.ratio + meta.top,
            box[2] * meta.ratio + meta.left,
            box[3] * meta.ratio + meta.top,
        ],
        dtype=torch.float32,
        device=device,
    )


class YOLOv5GradientAdapter:
    """YOLOv5 bridge for ODAM-style and Finer-CAM-style detector maps."""

    def __init__(self, processor: YOLOv5Processor, config: ExperimentConfig) -> None:
        self.processor = processor
        self.config = config
        self.backend = processor.backend
        self.detect_layer = processor.detect_layer

    def _prepare(self, image: Image.Image) -> Tuple[torch.Tensor, LetterboxMeta]:
        image_rgb = np.asarray(image.convert("RGB"))
        padded, meta = letterbox_rgb(
            image_rgb,
            new_shape=(self.processor.input_size, self.processor.input_size),
        )
        tensor = (
            torch.from_numpy(padded)
            .to(self.processor.device)
            .permute(2, 0, 1)
            .contiguous()
            .unsqueeze(0)
            .float()
            / 255.0
        )
        if getattr(self.backend, "fp16", False):
            tensor = tensor.half()
        tensor.requires_grad_(True)
        return tensor, meta

    def _forward(
        self, image: Image.Image
    ) -> Tuple[torch.Tensor, List[torch.Tensor], LetterboxMeta]:
        tensor, meta = self._prepare(image)
        captured: List[torch.Tensor] = []

        def capture_inputs(module: torch.nn.Module, inputs: Tuple[Any, ...]) -> None:
            tensors: List[torch.Tensor] = []
            _collect_4d_tensors(inputs, tensors)
            captured.extend(tensors)
            for feature in tensors:
                if feature.requires_grad:
                    feature.retain_grad()

        handle = self.detect_layer.register_forward_pre_hook(capture_inputs)
        try:
            output = self.backend(tensor, augment=False, visualize=False)
        finally:
            handle.remove()
        prediction = _find_prediction_tensor(output)
        if prediction is None:
            raise RuntimeError("Could not locate YOLOv5 raw prediction tensor.")
        if not captured:
            raise RuntimeError("Could not capture YOLOv5 detector features.")
        return prediction, captured, meta

    def _select_anchor(
        self,
        prediction: torch.Tensor,
        target: Detection,
        meta: LetterboxMeta,
    ) -> Tuple[int, torch.Tensor, torch.Tensor]:
        candidates = prediction[0]
        class_index = 5 + int(target.label_idx)
        if class_index >= candidates.shape[1]:
            raise IndexError(f"Class index {target.label_idx} is outside prediction tensor.")
        boxes = xywh_tensor_to_xyxy(candidates[:, :4].float())
        target_box = map_box_to_letterbox_tensor(
            target.box_xyxy, meta, candidates.device
        ).unsqueeze(0)
        overlaps = torchvision.ops.box_iou(target_box, boxes)[0]
        class_score = candidates[:, 4].float() * candidates[:, class_index].float()
        quality = overlaps * class_score
        selected_index = int(torch.argmax(quality).item())
        return selected_index, overlaps[selected_index], class_score[selected_index]

    def _aggregate_feature_maps(
        self,
        features: Sequence[torch.Tensor],
        meta: LetterboxMeta,
        method: str,
    ) -> np.ndarray:
        maps: List[np.ndarray] = []
        for feature in features:
            gradient = feature.grad
            if gradient is None:
                continue
            activation = feature.float()
            gradient = gradient.float()
            if float(gradient.detach().abs().sum()) <= 1e-12:
                continue
            if method == "odam":
                local_map = torch.relu((activation * gradient).sum(dim=1))[0]
            elif method == "finer_cam":
                weights = gradient.mean(dim=(2, 3), keepdim=True)
                local_map = torch.relu((activation * weights).sum(dim=1))[0]
            else:
                raise ValueError(f"Unknown method: {method}")
            original_map = feature_map_to_original(
                local_map.detach().cpu().numpy(), meta
            )
            maps.append(normalize_map(original_map))
        if not maps:
            original_w, original_h = meta.original_size
            return np.zeros((original_h, original_w), dtype=np.float32)
        merged = np.max(np.stack(maps, axis=0), axis=0)
        merged = cv2.GaussianBlur(merged, (0, 0), sigmaX=1.2)
        return normalize_map(merged)

    def odam(
        self, image: Image.Image, target: Detection
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        self.backend.zero_grad(set_to_none=True)
        prediction, features, meta = self._forward(image)
        index, overlap, anchor_score = self._select_anchor(prediction, target, meta)
        selected = prediction[0, index]
        objective = selected[4].float() * selected[5 + target.label_idx].float()
        objective.backward(retain_graph=False)
        heatmap = self._aggregate_feature_maps(features, meta, method="odam")
        return heatmap, {
            "selected_anchor": index,
            "anchor_iou": float(overlap.detach().cpu()),
            "anchor_class_score": float(anchor_score.detach().cpu()),
        }

    def finer_cam(
        self, image: Image.Image, target: Detection
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        self.backend.zero_grad(set_to_none=True)
        prediction, features, meta = self._forward(image)
        index, overlap, anchor_score = self._select_anchor(prediction, target, meta)
        selected = prediction[0, index]
        probabilities = selected[5:].float().clamp(1e-6, 1.0 - 1e-6)
        logits = torch.logit(probabilities)
        main_index = int(target.label_idx)
        differences = torch.abs(logits - logits[main_index])
        differences[main_index] = torch.inf
        references = torch.argsort(differences)[: self.config.finer_reference_count]
        reference_weights = torch.softmax(logits[references], dim=0)
        relative_objective = (
            reference_weights
            * (
                logits[main_index]
                - float(self.config.finer_alpha) * logits[references]
            )
        ).sum() / (reference_weights.sum() + 1e-9)
        objective = selected[4].float() * relative_objective
        objective.backward(retain_graph=False)
        heatmap = self._aggregate_feature_maps(features, meta, method="finer_cam")
        reference_names = [
            str(self.processor.detector.names[int(index_value)])
            for index_value in references.detach().cpu().tolist()
        ]
        return heatmap, {
            "selected_anchor": index,
            "anchor_iou": float(overlap.detach().cpu()),
            "anchor_class_score": float(anchor_score.detach().cpu()),
            "reference_classes": reference_names,
        }


@dataclass
class CraftConcept:
    concept_index: int
    importance: float
    activation_mass: float
    activation_map: np.ndarray


def craft_object_concepts(
    processor: YOLOv5Processor,
    image: Image.Image,
    target: Detection,
    feature_tensor: torch.Tensor,
    meta: LetterboxMeta,
    config: ExperimentConfig,
) -> Tuple[np.ndarray, List[CraftConcept]]:
    """Detector adaptation of CRAFT's non-negative concept factorization core.

    This is explicitly labelled CRAFT-adapted in outputs; it is not represented as
    an unmodified official detector implementation.
    """
    _, channels, feature_h, feature_w = feature_tensor.shape
    x1, y1, x2, y2 = map_box_to_feature(
        target.box_xyxy, meta, (feature_h, feature_w)
    )
    if x2 <= x1 or y2 <= y1:
        return np.zeros((image.height, image.width), dtype=np.float32), []
    feature_grid = feature_tensor[0].permute(1, 2, 0).detach().float().cpu().numpy()
    feature_grid = np.clip(feature_grid, 0.0, None)
    region_vectors = feature_grid[y1:y2, x1:x2].reshape(-1, channels)
    region_vectors = region_vectors[np.isfinite(region_vectors).all(axis=1)]
    if region_vectors.shape[0] < 2 or float(region_vectors.max()) <= 0.0:
        return np.zeros((image.height, image.width), dtype=np.float32), []
    component_count = max(
        1,
        min(
            int(config.craft_concepts),
            region_vectors.shape[0],
            region_vectors.shape[1],
        ),
    )
    factorizer = NMF(
        n_components=component_count,
        init="nndsvda",
        random_state=config.seed,
        max_iter=500,
    )
    factorizer.fit(region_vectors + 1e-8)
    all_vectors = feature_grid.reshape(-1, channels)
    concept_coefficients = factorizer.transform(all_vectors + 1e-8)
    concept_maps = concept_coefficients.reshape(feature_h, feature_w, component_count)

    object_support = box_mask(target.box_xyxy, image.size)
    candidates: List[Tuple[int, float, np.ndarray]] = []
    for concept_index in range(component_count):
        original_map = feature_map_to_original(concept_maps[..., concept_index], meta)
        normalized = normalize_map(original_map, object_support)
        activation_mass = float((original_map * object_support).sum())
        candidates.append((concept_index, activation_mass, normalized))
    candidates.sort(key=lambda item: item[1], reverse=True)

    image_rgb = np.asarray(image.convert("RGB"))
    blurred = np.asarray(image.filter(ImageFilter.GaussianBlur(radius=config.blur_radius)))
    concepts: List[CraftConcept] = []
    for concept_index, activation_mass, normalized in candidates[
        : config.craft_evaluated_concepts
    ]:
        values = normalized[object_support.astype(bool)]
        if values.size == 0 or float(values.max()) <= 0.0:
            importance = 0.0
        else:
            threshold = float(np.percentile(values, config.activation_percentile))
            mask = ((normalized >= threshold) & (object_support > 0)).astype(np.uint8)
            counterfactual = np.where(
                mask[..., None] > 0, blurred, image_rgb
            ).astype(np.uint8)
            detections = processor.detect(
                Image.fromarray(counterfactual),
                conf_threshold=config.intervention_detection_conf,
            )
            post_score = matched_detection_score(
                detections, target, config.matching_iou_threshold
            )
            importance = max(0.0, float(target.score) - post_score)
        concepts.append(
            CraftConcept(
                concept_index=int(concept_index),
                importance=float(importance),
                activation_mass=float(activation_mass),
                activation_map=normalized,
            )
        )
    if not concepts:
        return np.zeros((image.height, image.width), dtype=np.float32), []
    weights = np.array([concept.importance for concept in concepts], dtype=np.float32)
    if float(weights.sum()) <= 1e-8:
        weights = np.array(
            [concept.activation_mass for concept in concepts], dtype=np.float32
        )
    if float(weights.sum()) <= 1e-8:
        weights = np.ones(len(concepts), dtype=np.float32)
    weights /= float(weights.sum())
    combined = np.zeros((image.height, image.width), dtype=np.float32)
    for weight, concept in zip(weights, concepts):
        combined += float(weight) * concept.activation_map
    return normalize_map(combined, object_support), concepts


def compute_baselines(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    feature_tensor: torch.Tensor,
    feature_meta: LetterboxMeta,
    pair_union: np.ndarray,
    config: ExperimentConfig,
) -> BaselineResult:
    """Compute every baseline independently.

    A failure in one adapter is recorded in metadata and does not discard the
    remaining methods or the RCE result for that pair.
    """
    support = box_mask(pair_union, image.size)
    object_maps: Dict[str, np.ndarray] = {}
    pair_maps: Dict[str, np.ndarray] = {}
    metadata: Dict[str, Any] = {"adapter_errors": {}}
    runtimes: Dict[str, float] = {}

    start = time.perf_counter()
    try:
        object_maps["D-RISE_a"], object_maps["D-RISE_b"] = drise_pair_maps(
            processor, image, detection_a, detection_b, config
        )
        pair_maps["D-RISE"] = combine_object_maps(
            object_maps["D-RISE_a"], object_maps["D-RISE_b"], support
        )
    except Exception as exc:
        metadata["adapter_errors"]["D-RISE"] = f"{type(exc).__name__}: {exc}"
    runtimes["D-RISE"] = time.perf_counter() - start

    try:
        gradient_adapter = YOLOv5GradientAdapter(processor, config)
    except Exception as exc:
        gradient_adapter = None
        metadata["adapter_errors"]["gradient_adapter"] = f"{type(exc).__name__}: {exc}"

    start = time.perf_counter()
    if gradient_adapter is not None:
        try:
            object_maps["ODAM_a"], metadata["ODAM_a"] = gradient_adapter.odam(
                image, detection_a
            )
            object_maps["ODAM_b"], metadata["ODAM_b"] = gradient_adapter.odam(
                image, detection_b
            )
            pair_maps["ODAM"] = combine_object_maps(
                object_maps["ODAM_a"], object_maps["ODAM_b"], support
            )
        except Exception as exc:
            metadata["adapter_errors"]["ODAM"] = f"{type(exc).__name__}: {exc}"
    runtimes["ODAM"] = time.perf_counter() - start

    start = time.perf_counter()
    if gradient_adapter is not None:
        try:
            object_maps["Finer-CAM_a"], metadata["Finer-CAM_a"] = gradient_adapter.finer_cam(
                image, detection_a
            )
            object_maps["Finer-CAM_b"], metadata["Finer-CAM_b"] = gradient_adapter.finer_cam(
                image, detection_b
            )
            pair_maps["Finer-CAM"] = combine_object_maps(
                object_maps["Finer-CAM_a"], object_maps["Finer-CAM_b"], support
            )
        except Exception as exc:
            metadata["adapter_errors"]["Finer-CAM"] = f"{type(exc).__name__}: {exc}"
    runtimes["Finer-CAM"] = time.perf_counter() - start

    start = time.perf_counter()
    try:
        object_maps["CRAFT-adapted_a"], craft_a = craft_object_concepts(
            processor, image, detection_a, feature_tensor, feature_meta, config
        )
        object_maps["CRAFT-adapted_b"], craft_b = craft_object_concepts(
            processor, image, detection_b, feature_tensor, feature_meta, config
        )
        pair_maps["CRAFT-adapted"] = combine_object_maps(
            object_maps["CRAFT-adapted_a"], object_maps["CRAFT-adapted_b"], support
        )
        metadata["CRAFT-adapted_a"] = [
            {
                "concept": concept.concept_index + 1,
                "importance": concept.importance,
                "activation_mass": concept.activation_mass,
            }
            for concept in craft_a
        ]
        metadata["CRAFT-adapted_b"] = [
            {
                "concept": concept.concept_index + 1,
                "importance": concept.importance,
                "activation_mass": concept.activation_mass,
            }
            for concept in craft_b
        ]
    except Exception as exc:
        metadata["adapter_errors"]["CRAFT-adapted"] = f"{type(exc).__name__}: {exc}"
    runtimes["CRAFT-adapted"] = time.perf_counter() - start

    return BaselineResult(
        pair_maps=pair_maps,
        object_maps=object_maps,
        metadata=metadata,
        runtimes=runtimes,
    )
