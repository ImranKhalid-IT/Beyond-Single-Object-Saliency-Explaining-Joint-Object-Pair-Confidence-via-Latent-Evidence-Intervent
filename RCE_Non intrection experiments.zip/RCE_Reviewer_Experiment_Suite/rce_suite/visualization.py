from __future__ import annotations

from pathlib import Path
from typing import Dict, Mapping, Sequence

import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

from .detector import Detection
from .geometry import normalize_map
from .metrics import DeletionResult


def draw_detection_boxes(
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
) -> np.ndarray:
    result = np.asarray(image.convert("RGB")).copy()
    for detection, color in [(detection_a, (255, 255, 0)), (detection_b, (0, 255, 255))]:
        x1, y1, x2, y2 = np.round(detection.box_xyxy).astype(int)
        cv2.rectangle(result, (x1, y1), (x2, y2), color, 3)
        cv2.putText(
            result,
            f"{detection.class_name} {detection.score:.2f}",
            (x1, max(18, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            color,
            2,
            cv2.LINE_AA,
        )
    x1, y1, x2, y2 = np.round(pair_union).astype(int)
    cv2.rectangle(result, (x1, y1), (x2, y2), (255, 0, 255), 3)
    return result


def overlay_heatmap(image: Image.Image, heatmap: np.ndarray) -> np.ndarray:
    image_rgb = np.asarray(image.convert("RGB"))
    normalized = normalize_map(heatmap)
    colored_bgr = cv2.applyColorMap(
        np.uint8(np.clip(normalized, 0.0, 1.0) * 255), cv2.COLORMAP_JET
    )
    colored_rgb = cv2.cvtColor(colored_bgr, cv2.COLOR_BGR2RGB)
    alpha = (0.72 * normalized)[..., None]
    return np.uint8(
        np.clip(
            image_rgb.astype(np.float32) * (1.0 - alpha)
            + colored_rgb.astype(np.float32) * alpha,
            0,
            255,
        )
    )


def create_method_dashboard(
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
    pair_maps: Mapping[str, np.ndarray],
    deletion_results: Mapping[str, DeletionResult],
    output_path: str | Path,
    title: str,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    methods = list(pair_maps)
    panels = 1 + len(methods)
    columns = 3
    rows = int(np.ceil(panels / columns))
    fig, axes = plt.subplots(rows, columns, figsize=(5.2 * columns, 4.5 * rows))
    axes_array = np.asarray(axes).reshape(-1)
    axes_array[0].imshow(draw_detection_boxes(image, detection_a, detection_b, pair_union))
    axes_array[0].set_title("Selected object pair and union region")
    axes_array[0].axis("off")
    for axis, method in zip(axes_array[1:], methods):
        axis.imshow(overlay_heatmap(image, pair_maps[method]))
        aoc = deletion_results.get(method)
        suffix = "" if aoc is None else f"\nAOC={aoc.aoc:.3f}"
        axis.set_title(f"{method}{suffix}")
        axis.axis("off")
    for axis in axes_array[panels:]:
        axis.axis("off")
    fig.suptitle(title, fontsize=15, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_deletion_curves(
    deletion_results: Mapping[str, DeletionResult],
    output_path: str | Path,
    title: str,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, axis = plt.subplots(figsize=(8, 6))
    for method, result in deletion_results.items():
        axis.plot(
            result.fractions,
            result.normalized_joint_scores,
            marker="o",
            label=f"{method} (AOC={result.aoc:.3f})",
        )
    axis.set_xlabel("Fraction of union-region pixels replaced (MoRF)")
    axis.set_ylabel("Normalized joint detection confidence")
    axis.set_title(title)
    axis.grid(True, linestyle=":", alpha=0.4)
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_sensitivity(
    aggregate_frame,
    output_dir: str | Path,
) -> Sequence[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for parameter, group in aggregate_frame.groupby("parameter"):
        group = group.sort_values("value_numeric")
        fig, axis = plt.subplots(figsize=(7.5, 5.5))
        axis.errorbar(
            group.value_numeric,
            group.mean_aoc,
            yerr=group.std_aoc.fillna(0.0),
            marker="o",
            capsize=4,
        )
        axis.set_xlabel(parameter)
        axis.set_ylabel("Mean RCE AOC (lower is better)")
        axis.set_title(f"Sensitivity to {parameter}")
        axis.grid(True, linestyle=":", alpha=0.4)
        path = output_dir / f"sensitivity_{parameter}.png"
        fig.tight_layout()
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        paths.append(path)
    return paths
