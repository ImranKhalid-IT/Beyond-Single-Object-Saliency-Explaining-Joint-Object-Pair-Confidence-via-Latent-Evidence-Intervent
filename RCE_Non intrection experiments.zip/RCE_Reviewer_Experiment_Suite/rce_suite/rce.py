from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageFilter
from sklearn.cluster import KMeans

from .config import ExperimentConfig
from .detector import Detection, YOLOv5Processor, matched_detection_score
from .geometry import (
    LetterboxMeta,
    box_mask,
    feature_map_to_original,
    map_box_to_feature,
    normalize_map,
)


@dataclass
class ConceptResult:
    concept_index: int
    effect_score: float
    original_score_a: float
    original_score_b: float
    post_score_a: float
    post_score_b: float
    original_joint_score: float
    post_joint_score: float
    mask_fraction: float
    activation_mass: float
    auto_region_label: str
    activation_map: np.ndarray
    intervention_mask: np.ndarray

    def summary(self) -> dict:
        return {
            "concept_id": self.concept_index + 1,
            "effect_score_CE_k": float(self.effect_score),
            "original_score_a": float(self.original_score_a),
            "original_score_b": float(self.original_score_b),
            "post_score_a": float(self.post_score_a),
            "post_score_b": float(self.post_score_b),
            "original_joint_score": float(self.original_joint_score),
            "post_joint_score": float(self.post_joint_score),
            "mask_fraction_of_union": float(self.mask_fraction),
            "activation_mass": float(self.activation_mass),
            "auto_region_label": self.auto_region_label,
        }


class KMeansConceptExplainer:
    """Image-specific RCE concept discovery in a selected union region."""

    def __init__(
        self,
        number_of_concepts: int,
        temperature: float,
        seed: int = 42,
    ) -> None:
        if number_of_concepts < 1:
            raise ValueError("number_of_concepts must be at least 1")
        if temperature <= 0:
            raise ValueError("temperature must be positive")
        self.number_of_concepts = int(number_of_concepts)
        self.temperature = float(temperature)
        self.seed = int(seed)

    def discover(
        self,
        feature_tensor: torch.Tensor,
        relational_box: np.ndarray,
        meta: LetterboxMeta,
    ) -> torch.Tensor:
        if feature_tensor.ndim != 4 or feature_tensor.shape[0] != 1:
            raise ValueError(
                f"Expected feature tensor [1,C,H,W], got {tuple(feature_tensor.shape)}"
            )
        _, channels, feature_h, feature_w = feature_tensor.shape
        x1, y1, x2, y2 = map_box_to_feature(
            relational_box, meta, (feature_h, feature_w)
        )
        if x2 <= x1 or y2 <= y1:
            raise RuntimeError("Relational box maps to an empty feature region.")

        feature_grid = feature_tensor[0].permute(1, 2, 0).contiguous()
        region_vectors = feature_grid[y1:y2, x1:x2].reshape(-1, channels)
        region_vectors = region_vectors[
            torch.isfinite(region_vectors).all(dim=1)
        ]
        if region_vectors.shape[0] < 2:
            raise RuntimeError("Too few valid feature vectors for concept discovery.")

        k_final = min(self.number_of_concepts, int(region_vectors.shape[0]))
        kmeans = KMeans(
            n_clusters=k_final,
            random_state=self.seed,
            n_init=10,
        )
        centers_np = kmeans.fit(region_vectors.detach().cpu().numpy()).cluster_centers_
        centers = torch.as_tensor(
            centers_np,
            dtype=feature_tensor.dtype,
            device=feature_tensor.device,
        )
        all_vectors = feature_grid.reshape(-1, channels)
        # Manuscript Eq. (13): squared Euclidean distance.
        squared_distances = torch.cdist(
            all_vectors.float(), centers.float(), p=2
        ).pow(2)
        similarity = F.softmax(-squared_distances / self.temperature, dim=1)
        activation_maps = similarity.T.reshape(k_final, feature_h, feature_w)
        return activation_maps.unsqueeze(0)


def automatic_region_label(
    activation_map: np.ndarray,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
) -> str:
    size = (activation_map.shape[1], activation_map.shape[0])
    support = box_mask(pair_union, size)
    normalized = normalize_map(activation_map, support)
    total = float((normalized * support).sum()) + 1e-8
    mass_a = float((normalized * box_mask(detection_a.box_xyxy, size)).sum()) / total
    mass_b = float((normalized * box_mask(detection_b.box_xyxy, size)).sum()) / total
    context_mass = max(0.0, 1.0 - min(1.0, mass_a + mass_b))
    if mass_a >= 0.25 and mass_b >= 0.25:
        return "shared pair region"
    if mass_a >= max(0.20, mass_b):
        return f"{detection_a.class_name}-dominant region"
    if mass_b >= max(0.20, mass_a):
        return f"{detection_b.class_name}-dominant region"
    if context_mass >= 0.45:
        return "shared context"
    return "mixed relational region"


class RelationalInterventionExplainer:
    """Controlled model-level concept intervention for a frozen detector."""

    def __init__(
        self,
        processor: YOLOv5Processor,
        config: ExperimentConfig,
        percentile: Optional[float] = None,
        blur_radius: Optional[float] = None,
    ) -> None:
        self.processor = processor
        self.config = config
        self.percentile = float(
            config.activation_percentile if percentile is None else percentile
        )
        self.blur_radius = float(config.blur_radius if blur_radius is None else blur_radius)

    def evaluate(
        self,
        image: Image.Image,
        activation_maps: torch.Tensor,
        meta: LetterboxMeta,
        detection_a: Detection,
        detection_b: Detection,
        pair_union: np.ndarray,
        counterfactual_dir: Optional[Path] = None,
    ) -> List[ConceptResult]:
        image_rgb = np.asarray(image.convert("RGB"))
        union_support = box_mask(pair_union, image.size)
        blurred = np.asarray(
            image.filter(ImageFilter.GaussianBlur(radius=self.blur_radius))
        )
        original_joint = float(detection_a.score * detection_b.score)
        results: List[ConceptResult] = []

        for concept_index in range(activation_maps.shape[1]):
            feature_map = activation_maps[0, concept_index].detach().cpu().numpy()
            original_map = feature_map_to_original(feature_map, meta)
            normalized = normalize_map(original_map, union_support)
            values = normalized[union_support.astype(bool)]
            if values.size == 0 or float(values.max()) <= 0.0:
                threshold = 1.0
            else:
                threshold = float(np.percentile(values, self.percentile))
            intervention_mask = (
                (normalized >= threshold) & (union_support > 0)
            ).astype(np.uint8)
            mask_fraction = float(intervention_mask.sum()) / (
                float(union_support.sum()) + 1e-8
            )
            counterfactual = np.where(
                intervention_mask[..., None] > 0,
                blurred,
                image_rgb,
            ).astype(np.uint8)
            counterfactual_image = Image.fromarray(counterfactual)
            post_detections = self.processor.detect(
                counterfactual_image,
                conf_threshold=self.config.intervention_detection_conf,
            )
            post_a = matched_detection_score(
                post_detections,
                detection_a,
                self.config.matching_iou_threshold,
            )
            post_b = matched_detection_score(
                post_detections,
                detection_b,
                self.config.matching_iou_threshold,
            )
            post_joint = float(post_a * post_b)
            # Manuscript Eq. (23), kept signed. A negative value means confidence increased.
            effect = float(original_joint - post_joint)
            activation_mass = float((normalized * union_support).sum())

            if counterfactual_dir is not None:
                counterfactual_dir.mkdir(parents=True, exist_ok=True)
                counterfactual_image.save(
                    counterfactual_dir / f"concept_{concept_index + 1:02d}.png"
                )

            results.append(
                ConceptResult(
                    concept_index=concept_index,
                    effect_score=effect,
                    original_score_a=float(detection_a.score),
                    original_score_b=float(detection_b.score),
                    post_score_a=float(post_a),
                    post_score_b=float(post_b),
                    original_joint_score=original_joint,
                    post_joint_score=post_joint,
                    mask_fraction=mask_fraction,
                    activation_mass=activation_mass,
                    auto_region_label=automatic_region_label(
                        normalized, detection_a, detection_b, pair_union
                    ),
                    activation_map=normalized,
                    intervention_mask=intervention_mask,
                )
            )
        return results


def combined_rce_map(
    concept_results: Sequence[ConceptResult],
    pair_union: np.ndarray,
    image_size: tuple[int, int],
    top_n: int = 3,
) -> np.ndarray:
    width, height = image_size
    support = box_mask(pair_union, image_size)
    if not concept_results:
        return np.zeros((height, width), dtype=np.float32)
    ranked = sorted(
        concept_results, key=lambda result: result.effect_score, reverse=True
    )
    selected = ranked[: max(1, min(top_n, len(ranked)))]
    weights = np.array(
        [max(0.0, result.effect_score) for result in selected], dtype=np.float32
    )
    if float(weights.sum()) <= 1e-8:
        weights = np.array(
            [max(0.0, result.activation_mass) for result in selected], dtype=np.float32
        )
    if float(weights.sum()) <= 1e-8:
        weights = np.ones(len(selected), dtype=np.float32)
    weights /= float(weights.sum())
    heatmap = np.zeros((height, width), dtype=np.float32)
    for weight, result in zip(weights, selected):
        heatmap += float(weight) * result.activation_map
    heatmap *= support
    sigma = max(1.0, min(width, height) / 160.0)
    heatmap = cv2.GaussianBlur(heatmap, (0, 0), sigmaX=sigma, sigmaY=sigma)
    return normalize_map(heatmap, support)


def rank_signature(concept_results: Sequence[ConceptResult]) -> List[int]:
    return [
        result.concept_index
        for result in sorted(
            concept_results, key=lambda result: result.effect_score, reverse=True
        )
    ]
