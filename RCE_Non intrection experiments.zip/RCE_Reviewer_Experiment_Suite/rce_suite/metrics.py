from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence

import numpy as np
from PIL import Image, ImageFilter

from .config import ExperimentConfig
from .detector import Detection, YOLOv5Processor, matched_detection_score
from .geometry import box_mask, normalize_map


@dataclass
class DeletionResult:
    fractions: List[float]
    normalized_joint_scores: List[float]
    aoc: float

    def to_dict(self) -> Dict[str, object]:
        return {
            "fractions": self.fractions,
            "normalized_joint_scores": self.normalized_joint_scores,
            "aoc": float(self.aoc),
        }


def concept_effect(
    original_score_a: float,
    original_score_b: float,
    post_score_a: float,
    post_score_b: float,
) -> float:
    return float(
        original_score_a * original_score_b - post_score_a * post_score_b
    )


def deletion_curve(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    pair_map: np.ndarray,
    pair_union: np.ndarray,
    config: ExperimentConfig,
) -> DeletionResult:
    """Shared MoRF deletion protocol for all methods.

    At each requested fraction, the highest-ranked pixels inside the same union
    region are replaced by the same Gaussian-blurred baseline. The y-axis is the
    post-intervention joint score divided by the original joint score.
    """
    image_rgb = np.asarray(image.convert("RGB"))
    blurred = np.asarray(image.filter(ImageFilter.GaussianBlur(radius=config.blur_radius)))
    support = box_mask(pair_union, image.size).astype(bool)
    normalized_map = normalize_map(pair_map, support.astype(np.uint8))
    support_indices = np.flatnonzero(support.ravel())
    if support_indices.size == 0:
        raise ValueError("Union support is empty.")
    saliency_values = normalized_map.ravel()[support_indices]
    ranked_support_indices = support_indices[np.argsort(-saliency_values, kind="stable")]
    original_joint = float(detection_a.score * detection_b.score)
    scores: List[float] = []
    fractions = sorted(set(float(value) for value in config.deletion_fractions))
    if not fractions or fractions[0] != 0.0:
        fractions = [0.0] + fractions

    for fraction in fractions:
        fraction = min(max(fraction, 0.0), 1.0)
        count = int(round(fraction * ranked_support_indices.size))
        mask_flat = np.zeros(image_rgb.shape[:2][0] * image_rgb.shape[:2][1], dtype=bool)
        if count > 0:
            mask_flat[ranked_support_indices[:count]] = True
        deletion_mask = mask_flat.reshape(image_rgb.shape[:2])
        counterfactual = np.where(
            deletion_mask[..., None], blurred, image_rgb
        ).astype(np.uint8)
        detections = processor.detect(
            Image.fromarray(counterfactual),
            conf_threshold=config.intervention_detection_conf,
        )
        post_a = matched_detection_score(
            detections, detection_a, config.matching_iou_threshold
        )
        post_b = matched_detection_score(
            detections, detection_b, config.matching_iou_threshold
        )
        post_joint = float(post_a * post_b)
        normalized_score = post_joint / (original_joint + 1e-8)
        scores.append(float(np.clip(normalized_score, 0.0, 1.5)))

    x = np.asarray(fractions, dtype=np.float64)
    y = np.asarray(scores, dtype=np.float64)
    span = float(x[-1] - x[0])
    aoc = float(np.trapz(y, x) / span) if span > 0 else float(y.mean())
    return DeletionResult(
        fractions=[float(value) for value in x],
        normalized_joint_scores=[float(value) for value in y],
        aoc=aoc,
    )
