from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score


def holm_adjust(p_values: Sequence[float]) -> List[float]:
    p = np.asarray(p_values, dtype=float)
    n = len(p)
    order = np.argsort(p)
    adjusted = np.empty(n, dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        value = min(1.0, (n - rank) * p[index])
        running = max(running, value)
        adjusted[index] = running
    return adjusted.tolist()


def bootstrap_difference_ci(
    group_a: Sequence[float],
    group_b: Sequence[float],
    iterations: int,
    confidence_level: float,
    seed: int,
    statistic: str = "median",
) -> Tuple[float, float, float]:
    a = np.asarray(group_a, dtype=float)
    b = np.asarray(group_b, dtype=float)
    if a.size == 0 or b.size == 0:
        return math.nan, math.nan, math.nan
    rng = np.random.default_rng(seed)
    stat = np.median if statistic == "median" else np.mean
    observed = float(stat(a) - stat(b))
    samples = np.empty(iterations, dtype=float)
    for index in range(iterations):
        sampled_a = rng.choice(a, size=a.size, replace=True)
        sampled_b = rng.choice(b, size=b.size, replace=True)
        samples[index] = stat(sampled_a) - stat(sampled_b)
    alpha = 1.0 - confidence_level
    lower, upper = np.quantile(samples, [alpha / 2.0, 1.0 - alpha / 2.0])
    return observed, float(lower), float(upper)


def run_negative_pair_statistics(
    summary_csv: str | Path,
    output_dir: str | Path,
    bootstrap_iterations: int = 2000,
    confidence_level: float = 0.95,
    seed: int = 42,
) -> pd.DataFrame:
    frame = pd.read_csv(summary_csv)
    if "relation_label" not in frame.columns:
        raise ValueError("Summary CSV has no relation_label column.")
    labelled = frame[frame["relation_label"].isin([0, 1])].copy()
    if labelled.empty:
        raise ValueError("No labelled positive/negative pairs were found.")
    positive = labelled[labelled.relation_label == 1]
    negative = labelled[labelled.relation_label == 0]
    if positive.empty or negative.empty:
        raise ValueError("Both positive and negative groups are required.")

    candidate_metrics = [
        "max_effect_score",
        "top3_mean_effect_score",
        "RCE_aoc",
    ]
    metrics = [metric for metric in candidate_metrics if metric in labelled.columns]
    rows: List[Dict[str, float | str | int]] = []
    for metric in metrics:
        pos = positive[metric].dropna().to_numpy(dtype=float)
        neg = negative[metric].dropna().to_numpy(dtype=float)
        alternative = "less" if metric.endswith("_aoc") else "greater"
        test = stats.mannwhitneyu(pos, neg, alternative=alternative)
        # Rank-biserial correlation oriented so positive values support the hypothesis.
        u_value = float(test.statistic)
        if alternative == "greater":
            rbc = 2.0 * u_value / (len(pos) * len(neg)) - 1.0
        else:
            rbc = 1.0 - 2.0 * u_value / (len(pos) * len(neg))
        observed, ci_low, ci_high = bootstrap_difference_ci(
            pos,
            neg,
            iterations=bootstrap_iterations,
            confidence_level=confidence_level,
            seed=seed,
            statistic="median",
        )
        if metric.endswith("_aoc"):
            observed, ci_low, ci_high = -observed, -ci_high, -ci_low
        try:
            if metric.endswith("_aoc"):
                auc = roc_auc_score(labelled.relation_label, -labelled[metric])
            else:
                auc = roc_auc_score(labelled.relation_label, labelled[metric])
        except Exception:
            auc = math.nan
        rows.append(
            {
                "metric": metric,
                "positive_n": len(pos),
                "negative_n": len(neg),
                "positive_median": float(np.median(pos)),
                "negative_median": float(np.median(neg)),
                "hypothesis_oriented_median_difference": float(observed),
                "difference_ci_low": float(ci_low),
                "difference_ci_high": float(ci_high),
                "mann_whitney_u": u_value,
                "p_value": float(test.pvalue),
                "rank_biserial_effect": float(rbc),
                "roc_auc": float(auc),
            }
        )
    result = pd.DataFrame(rows)
    if not result.empty:
        result["p_holm"] = holm_adjust(result.p_value.tolist())
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_dir / "positive_vs_negative_statistics.csv", index=False)
    return result


def run_paired_baseline_statistics(
    summary_csv: str | Path,
    output_dir: str | Path,
    bootstrap_iterations: int = 2000,
    confidence_level: float = 0.95,
    seed: int = 42,
) -> pd.DataFrame:
    frame = pd.read_csv(summary_csv)
    if "RCE_aoc" not in frame.columns:
        raise ValueError("Summary CSV has no RCE_aoc column.")
    baseline_columns = [
        column
        for column in frame.columns
        if column.endswith("_aoc") and column != "RCE_aoc"
    ]
    rows: List[Dict[str, float | str | int]] = []
    for column in baseline_columns:
        paired = frame[["RCE_aoc", column]].dropna()
        if len(paired) < 2:
            continue
        rce = paired.RCE_aoc.to_numpy(dtype=float)
        baseline = paired[column].to_numpy(dtype=float)
        differences = baseline - rce  # positive means RCE has lower/better AOC
        if np.allclose(differences, 0.0):
            statistic, p_value = 0.0, 1.0
        else:
            test = stats.wilcoxon(
                differences,
                alternative="greater",
                zero_method="wilcox",
            )
            statistic, p_value = float(test.statistic), float(test.pvalue)
        observed, ci_low, ci_high = bootstrap_paired_ci(
            differences,
            bootstrap_iterations,
            confidence_level,
            seed,
        )
        rows.append(
            {
                "baseline": column.removesuffix("_aoc"),
                "n_pairs": len(paired),
                "RCE_mean_aoc": float(np.mean(rce)),
                "baseline_mean_aoc": float(np.mean(baseline)),
                "mean_aoc_improvement": observed,
                "improvement_ci_low": ci_low,
                "improvement_ci_high": ci_high,
                "wilcoxon_statistic": statistic,
                "p_value": p_value,
            }
        )
    result = pd.DataFrame(rows)
    if not result.empty:
        result["p_holm"] = holm_adjust(result.p_value.tolist())
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_dir / "paired_baseline_statistics.csv", index=False)
    return result


def bootstrap_paired_ci(
    differences: np.ndarray,
    iterations: int,
    confidence_level: float,
    seed: int,
) -> Tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    observed = float(np.mean(differences))
    boot = np.empty(iterations, dtype=float)
    for index in range(iterations):
        boot[index] = float(
            np.mean(rng.choice(differences, size=len(differences), replace=True))
        )
    alpha = 1.0 - confidence_level
    low, high = np.quantile(boot, [alpha / 2.0, 1.0 - alpha / 2.0])
    return observed, float(low), float(high)


def wilson_interval(successes: int, total: int, confidence_level: float = 0.95) -> Tuple[float, float]:
    if total <= 0:
        return math.nan, math.nan
    z = stats.norm.ppf(0.5 + confidence_level / 2.0)
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    margin = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * total)) / total) / denominator
    return center - margin, center + margin


def fleiss_kappa_from_binary(frame: pd.DataFrame) -> float:
    """Calculate Fleiss' kappa from item × participant binary judgments."""
    required = {"item_id", "participant_id", "binary_alignment"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing Fleiss-kappa columns: {sorted(missing)}")
    pivot = frame.pivot_table(
        index="item_id",
        columns="participant_id",
        values="binary_alignment",
        aggfunc="first",
    )
    pivot = pivot.dropna(axis=0, how="any")
    if pivot.empty:
        return math.nan
    values = pivot.to_numpy(dtype=int)
    n_raters = values.shape[1]
    if n_raters < 2:
        return math.nan
    counts_1 = values.sum(axis=1)
    counts_0 = n_raters - counts_1
    p_item = (
        counts_0 * (counts_0 - 1) + counts_1 * (counts_1 - 1)
    ) / (n_raters * (n_raters - 1))
    p_bar = float(np.mean(p_item))
    p1 = float(counts_1.sum() / values.size)
    p0 = 1.0 - p1
    p_e = p0 * p0 + p1 * p1
    if abs(1.0 - p_e) <= 1e-12:
        return math.nan
    return float((p_bar - p_e) / (1.0 - p_e))


def run_human_study_statistics(
    human_csv: str | Path,
    output_dir: str | Path,
    confidence_level: float = 0.95,
) -> Dict[str, pd.DataFrame]:
    frame = pd.read_csv(human_csv)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    required = {"participant_id", "expertise", "method", "image_id"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Human-study CSV is missing: {sorted(missing)}")

    participant_table = (
        frame[["participant_id", "expertise"]]
        .drop_duplicates()
        .groupby("expertise")
        .size()
        .rename("participants")
        .reset_index()
    )
    participant_table.to_csv(output_dir / "participant_composition.csv", index=False)

    outputs: Dict[str, pd.DataFrame] = {"participants": participant_table}

    if "rating" in frame.columns and "criterion" in frame.columns:
        ratings = (
            frame.dropna(subset=["rating"])
            .groupby(["method", "criterion", "expertise"])["rating"]
            .agg(["count", "mean", "std"])
            .reset_index()
        )
        ratings["sem"] = ratings["std"] / np.sqrt(ratings["count"].clip(lower=1))
        z = stats.norm.ppf(0.5 + confidence_level / 2.0)
        ratings["ci_low"] = ratings["mean"] - z * ratings["sem"]
        ratings["ci_high"] = ratings["mean"] + z * ratings["sem"]
        ratings.to_csv(output_dir / "likert_summary.csv", index=False)
        outputs["ratings"] = ratings

    if "binary_alignment" in frame.columns:
        binary = frame.dropna(subset=["binary_alignment"]).copy()
        binary["binary_alignment"] = binary.binary_alignment.astype(int)
        binary["item_id"] = (
            binary["method"].astype(str) + "|" + binary["image_id"].astype(str)
        )
        fidelity_rows = []
        for method, group in binary.groupby("method"):
            successes = int(group.binary_alignment.sum())
            total = int(len(group))
            low, high = wilson_interval(successes, total, confidence_level)
            fidelity_rows.append(
                {
                    "method": method,
                    "positive_judgments": successes,
                    "total_judgments": total,
                    "human_fidelity_percent": 100.0 * successes / total if total else math.nan,
                    "wilson_ci_low_percent": 100.0 * low,
                    "wilson_ci_high_percent": 100.0 * high,
                }
            )
        fidelity = pd.DataFrame(fidelity_rows)
        fidelity.to_csv(output_dir / "human_fidelity.csv", index=False)
        outputs["fidelity"] = fidelity
        kappa = fleiss_kappa_from_binary(binary)
        pd.DataFrame([{"fleiss_kappa": kappa}]).to_csv(
            output_dir / "fleiss_kappa.csv", index=False
        )

    if "forward_correct" in frame.columns and "scenario" in frame.columns:
        forward = frame.dropna(subset=["forward_correct"]).copy()
        rows = []
        for keys, group in forward.groupby(["method", "scenario"]):
            successes = int(group.forward_correct.astype(int).sum())
            total = len(group)
            low, high = wilson_interval(successes, total, confidence_level)
            rows.append(
                {
                    "method": keys[0],
                    "scenario": keys[1],
                    "correct": successes,
                    "total": total,
                    "accuracy_percent": 100.0 * successes / total if total else math.nan,
                    "wilson_ci_low_percent": 100.0 * low,
                    "wilson_ci_high_percent": 100.0 * high,
                }
            )
        forward_table = pd.DataFrame(rows)
        forward_table.to_csv(output_dir / "forward_simulation.csv", index=False)
        outputs["forward"] = forward_table

    nonexpert_count = int(
        participant_table.loc[
            participant_table.expertise.astype(str).str.lower().isin(
                ["non-expert", "nonexpert", "student", "general user"]
            ),
            "participants",
        ].sum()
    )
    warning = "OK" if nonexpert_count >= 30 else "FEWER_THAN_30_NONEXPERTS"
    pd.DataFrame(
        [{"nonexpert_participants": nonexpert_count, "reviewer_requirement_status": warning}]
    ).to_csv(output_dir / "nonexpert_requirement_check.csv", index=False)
    return outputs
