"""Reviewer-oriented experiment suite for Relational Concept Explainer (RCE)."""

__version__ = "1.0.0"
