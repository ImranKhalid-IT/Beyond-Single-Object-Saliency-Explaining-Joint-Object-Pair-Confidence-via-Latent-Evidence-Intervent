from __future__ import annotations

import json
import shlex
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

from .datasets import PairRecord
from .detector import Detection
from .geometry import normalize_map


class ExternalBaselineRunner:
    """Run optional GCE/CoE adapters without fabricating implementations.

    Each configured command receives a request JSON and must create a NumPy .npy
    file containing one pair-level saliency map with the same height/width as the
    input image. Placeholders available in a command string:
      {request_json}, {output_npy}, {method}
    """

    def __init__(self, config_path: str | Path) -> None:
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            self.methods: Dict[str, Dict[str, Any]] = {}
            return
        raw = json.loads(self.config_path.read_text(encoding="utf-8"))
        self.methods = {
            str(name): value
            for name, value in raw.items()
            if isinstance(value, dict) and value.get("enabled", False)
        }

    def run(
        self,
        method: str,
        work_dir: Path,
        image_shape: tuple[int, int],
        record: PairRecord,
        detection_a: Detection,
        detection_b: Detection,
        pair_union: np.ndarray,
    ) -> Optional[np.ndarray]:
        specification = self.methods.get(method)
        if specification is None:
            return None
        command_template = str(specification.get("command", "")).strip()
        if not command_template:
            return None
        work_dir.mkdir(parents=True, exist_ok=True)
        request_path = work_dir / f"{method.lower()}_request.json"
        output_path = work_dir / f"{method.lower()}_pair_map.npy"
        request = {
            "method": method,
            "image_path": record.image_path,
            "image_id": record.image_id,
            "object_a": detection_a.to_json(),
            "object_b": detection_b.to_json(),
            "pair_union_xyxy": [float(value) for value in pair_union],
            "expected_map_shape_hw": [int(image_shape[0]), int(image_shape[1])],
        }
        request_path.write_text(json.dumps(request, indent=2), encoding="utf-8")
        command = command_template.format(
            request_json=str(request_path),
            output_npy=str(output_path),
            method=method,
        )
        completed = subprocess.run(
            command,
            shell=True,
            cwd=str(work_dir),
            text=True,
            capture_output=True,
        )
        log_path = work_dir / f"{method.lower()}_adapter.log"
        log_path.write_text(
            f"COMMAND:\n{command}\n\nSTDOUT:\n{completed.stdout}\n\nSTDERR:\n{completed.stderr}\n",
            encoding="utf-8",
        )
        if completed.returncode != 0 or not output_path.exists():
            print(
                f"[{method}] external adapter did not produce a map; see {log_path}."
            )
            return None
        values = np.asarray(np.load(output_path), dtype=np.float32)
        if values.shape != image_shape:
            raise ValueError(
                f"{method} returned shape {values.shape}; expected {image_shape}."
            )
        return normalize_map(values)
