from __future__ import annotations

import json
import math
import random
import re
import time
import traceback
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
from PIL import Image
from scipy import stats
from tqdm.auto import tqdm

from .baselines import BaselineResult, compute_baselines
from .config import ExperimentConfig
from .datasets import PairRecord, load_manifest
from .detector import Detection, YOLOv5Processor, match_detection
from .external_baselines import ExternalBaselineRunner
from .geometry import box_area, box_mask, normalize_map, union_box
from .metrics import DeletionResult, deletion_curve
from .rce import (
    ConceptResult,
    KMeansConceptExplainer,
    RelationalInterventionExplainer,
    combined_rce_map,
    rank_signature,
)
from .statistics import (
    run_negative_pair_statistics,
    run_paired_baseline_statistics,
)
from .visualization import (
    create_method_dashboard,
    plot_deletion_curves,
    plot_sensitivity,
)


def set_reproducibility(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def sanitize_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "item"


def json_safe(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return value


def _match_pair_detections(
    processor: YOLOv5Processor,
    image: Image.Image,
    record: PairRecord,
    config: ExperimentConfig,
) -> Tuple[Detection, Detection]:
    detections = processor.detect(image, config.initial_detection_conf)
    detection_a = match_detection(
        detections,
        record.object_a,
        record.box_a,
        config.matching_iou_threshold,
    )
    detection_b = match_detection(
        detections,
        record.object_b,
        record.box_b,
        config.matching_iou_threshold,
    )
    if detection_a is None or detection_b is None:
        raise RuntimeError(
            "The detector did not match both manifest objects at the configured IoU "
            f"threshold ({config.matching_iou_threshold})."
        )
    image_area = float(image.width * image.height)
    if min(box_area(detection_a.box_xyxy), box_area(detection_b.box_xyxy)) / image_area < config.min_object_area_fraction:
        raise RuntimeError("At least one matched object is below min_object_area_fraction.")
    return detection_a, detection_b


def activation_ranked_map(
    concept_results: Sequence[ConceptResult],
    pair_union: np.ndarray,
    image_size: tuple[int, int],
    top_n: int = 3,
) -> np.ndarray:
    width, height = image_size
    support = box_mask(pair_union, image_size)
    if not concept_results:
        return np.zeros((height, width), dtype=np.float32)
    selected = sorted(
        concept_results, key=lambda result: result.activation_mass, reverse=True
    )[: max(1, min(top_n, len(concept_results)))]
    weights = np.asarray(
        [max(0.0, result.activation_mass) for result in selected], dtype=np.float32
    )
    if float(weights.sum()) <= 1e-8:
        weights = np.ones(len(selected), dtype=np.float32)
    weights /= float(weights.sum())
    heatmap = np.zeros((height, width), dtype=np.float32)
    for weight, result in zip(weights, selected):
        heatmap += float(weight) * result.activation_map
    return normalize_map(heatmap * support, support)


def analyze_pair(
    processor: YOLOv5Processor,
    record: PairRecord,
    config: ExperimentConfig,
    output_root: Path,
    external_runner: Optional[ExternalBaselineRunner] = None,
) -> Dict[str, Any]:
    image_path = Path(record.image_path)
    if not image_path.exists():
        raise FileNotFoundError(image_path)
    image = Image.open(image_path).convert("RGB")
    detection_a, detection_b = _match_pair_detections(
        processor, image, record, config
    )
    pair_union = union_box(detection_a.box_xyxy, detection_b.box_xyxy)
    union_fraction = box_area(pair_union) / float(image.width * image.height)
    if union_fraction > config.max_union_fraction:
        raise RuntimeError("Matched union region exceeds max_union_fraction.")

    pair_name = sanitize_name(
        f"{record.dataset}_{record.image_id}_{record.object_a}_{record.object_b}"
    )
    pair_dir = output_root / "pairs" / pair_name
    pair_dir.mkdir(parents=True, exist_ok=True)

    features, meta = processor.extract_features(image)
    concept_explainer = KMeansConceptExplainer(
        config.k_concepts, config.softmax_temperature, config.seed
    )
    start = time.perf_counter()
    activation_maps = concept_explainer.discover(features, pair_union, meta)
    intervention_explainer = RelationalInterventionExplainer(processor, config)
    concept_results = intervention_explainer.evaluate(
        image=image,
        activation_maps=activation_maps,
        meta=meta,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
        counterfactual_dir=None,
    )
    rce_runtime = time.perf_counter() - start

    concept_frame = pd.DataFrame([result.summary() for result in concept_results])
    concept_frame.to_csv(pair_dir / "rce_concept_scores.csv", index=False)

    rce_map = combined_rce_map(concept_results, pair_union, image.size)
    activation_map = activation_ranked_map(concept_results, pair_union, image.size)
    pair_maps: Dict[str, np.ndarray] = {
        "RCE": rce_map,
        "ActivationRanking": activation_map,
    }
    runtimes: Dict[str, float] = {"RCE": rce_runtime}
    baseline_metadata: Dict[str, Any] = {}

    if config.run_baselines:
        baseline_result: BaselineResult = compute_baselines(
            processor,
            image,
            detection_a,
            detection_b,
            features,
            meta,
            pair_union,
            config,
        )
        pair_maps.update(baseline_result.pair_maps)
        runtimes.update(baseline_result.runtimes)
        baseline_metadata.update(baseline_result.metadata)
        maps_dir = pair_dir / "object_maps"
        maps_dir.mkdir(exist_ok=True)
        for name, values in baseline_result.object_maps.items():
            np.save(maps_dir / f"{sanitize_name(name)}.npy", values.astype(np.float32))

    if external_runner is not None:
        for method in ("GCE", "CoE"):
            external_map = external_runner.run(
                method=method,
                work_dir=pair_dir / "external_baselines" / method,
                image_shape=(image.height, image.width),
                record=record,
                detection_a=detection_a,
                detection_b=detection_b,
                pair_union=pair_union,
            )
            if external_map is not None:
                pair_maps[method] = external_map

    maps_dir = pair_dir / "pair_maps"
    maps_dir.mkdir(exist_ok=True)
    for name, values in pair_maps.items():
        np.save(maps_dir / f"{sanitize_name(name)}.npy", values.astype(np.float32))

    deletion_results: Dict[str, DeletionResult] = {}
    for method, pair_map in pair_maps.items():
        deletion_results[method] = deletion_curve(
            processor,
            image,
            detection_a,
            detection_b,
            pair_map,
            pair_union,
            config,
        )

    create_method_dashboard(
        image=image,
        detection_a=detection_a,
        detection_b=detection_b,
        pair_union=pair_union,
        pair_maps=pair_maps,
        deletion_results=deletion_results,
        output_path=pair_dir / "method_dashboard.png",
        title=f"{record.dataset} {record.image_id}: {record.object_a} + {record.object_b}",
    )
    plot_deletion_curves(
        deletion_results,
        pair_dir / "deletion_curves.png",
        title=f"Shared MoRF deletion: {record.object_a} + {record.object_b}",
    )

    ranked = sorted(
        concept_results, key=lambda result: result.effect_score, reverse=True
    )
    summary: Dict[str, Any] = {
        "dataset": record.dataset,
        "image_id": record.image_id,
        "image_path": record.image_path,
        "object_a": record.object_a,
        "object_b": record.object_b,
        "relation_label": record.relation_label,
        "relation_name": record.relation_name,
        "annotation_source": record.annotation_source,
        "detector_score_a": detection_a.score,
        "detector_score_b": detection_b.score,
        "original_joint_score": detection_a.score * detection_b.score,
        "matched_box_a": detection_a.box_xyxy,
        "matched_box_b": detection_b.box_xyxy,
        "pair_union": pair_union,
        "union_fraction": union_fraction,
        "max_effect_score": max(result.effect_score for result in concept_results),
        "top3_mean_effect_score": float(
            np.mean([result.effect_score for result in ranked[:3]])
        ),
        "mean_mask_fraction": float(
            np.mean([result.mask_fraction for result in concept_results])
        ),
        "top_concept_id": ranked[0].concept_index + 1,
        "top_concept_region": ranked[0].auto_region_label,
        "RCE_runtime_seconds": rce_runtime,
        "pair_output_dir": str(pair_dir),
    }
    for method, result in deletion_results.items():
        summary[f"{method}_aoc"] = result.aoc
        summary[f"{method}_deletion_curve"] = result.to_dict()
    for method, runtime in runtimes.items():
        summary[f"{method}_runtime_seconds"] = runtime

    detail = {
        "summary": summary,
        "config": asdict(config),
        "detections": {
            "object_a": detection_a.to_json(),
            "object_b": detection_b.to_json(),
        },
        "concept_results": [result.summary() for result in concept_results],
        "baseline_metadata": baseline_metadata,
    }
    (pair_dir / "pair_result.json").write_text(
        json.dumps(json_safe(detail), indent=2), encoding="utf-8"
    )
    return summary


def run_main_experiment(
    manifest_path: str | Path,
    config: ExperimentConfig,
    external_baselines_path: Optional[str | Path] = None,
) -> pd.DataFrame:
    set_reproducibility(config.seed)
    output_root = Path(config.output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    records = load_manifest(manifest_path, require_labels=False)
    records = records[: config.max_pairs]
    processor = YOLOv5Processor(config)
    external_runner = (
        ExternalBaselineRunner(external_baselines_path)
        if external_baselines_path is not None
        else None
    )
    summaries: List[Dict[str, Any]] = []
    errors: List[Dict[str, str]] = []
    for record in tqdm(records, desc="Reviewer experiment pairs"):
        try:
            summaries.append(
                analyze_pair(
                    processor,
                    record,
                    config,
                    output_root,
                    external_runner=external_runner,
                )
            )
        except Exception as exc:
            errors.append(
                {
                    "dataset": record.dataset,
                    "image_id": record.image_id,
                    "object_a": record.object_a,
                    "object_b": record.object_b,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
            print(
                f"Skipped {record.dataset} {record.image_id} "
                f"({record.object_a}+{record.object_b}): {type(exc).__name__}: {exc}"
            )

    summary_frame = pd.DataFrame(summaries)
    summary_path = output_root / "all_pair_results.csv"
    summary_frame.to_csv(summary_path, index=False)
    pd.DataFrame(errors).to_csv(output_root / "errors.csv", index=False)
    (output_root / "run_config.json").write_text(
        json.dumps(asdict(config), indent=2), encoding="utf-8"
    )

    if not summary_frame.empty:
        run_paired_baseline_statistics(
            summary_path,
            output_root / "statistics",
            config.bootstrap_iterations,
            config.confidence_level,
            config.seed,
        )
        labels = set(summary_frame.relation_label.dropna().astype(int).tolist())
        if labels >= {0, 1}:
            run_negative_pair_statistics(
                summary_path,
                output_root / "statistics",
                config.bootstrap_iterations,
                config.confidence_level,
                config.seed,
            )
        else:
            print(
                "Positive-versus-negative statistics were skipped because the manifest "
                "does not contain both relation_label=1 and relation_label=0."
            )
    return summary_frame


def _prepare_sensitivity_pair(
    processor: YOLOv5Processor,
    record: PairRecord,
    config: ExperimentConfig,
):
    image = Image.open(record.image_path).convert("RGB")
    detection_a, detection_b = _match_pair_detections(processor, image, record, config)
    pair_union = union_box(detection_a.box_xyxy, detection_b.box_xyxy)
    features, meta = processor.extract_features(image)
    return image, detection_a, detection_b, pair_union, features, meta


def _evaluate_setting(
    processor: YOLOv5Processor,
    image: Image.Image,
    detection_a: Detection,
    detection_b: Detection,
    pair_union: np.ndarray,
    features: torch.Tensor,
    meta,
    config: ExperimentConfig,
    k: int,
    temperature: float,
    percentile: float,
    blur_radius: float,
) -> Tuple[List[ConceptResult], DeletionResult]:
    maps = KMeansConceptExplainer(k, temperature, config.seed).discover(
        features, pair_union, meta
    )
    results = RelationalInterventionExplainer(
        processor, config, percentile=percentile, blur_radius=blur_radius
    ).evaluate(
        image,
        maps,
        meta,
        detection_a,
        detection_b,
        pair_union,
    )
    pair_map = combined_rce_map(results, pair_union, image.size)
    # Match deletion baseline to the setting-specific blur radius.
    local_config = ExperimentConfig(**asdict(config))
    local_config.blur_radius = blur_radius
    deletion = deletion_curve(
        processor,
        image,
        detection_a,
        detection_b,
        pair_map,
        pair_union,
        local_config,
    )
    return results, deletion


def _kendall_for_rankings(reference: Sequence[int], candidate: Sequence[int]) -> float:
    if len(reference) != len(candidate) or len(reference) < 2:
        return math.nan
    reference_positions = {concept: index for index, concept in enumerate(reference)}
    if set(reference_positions) != set(candidate):
        return math.nan
    candidate_positions = [reference_positions[concept] for concept in candidate]
    tau = stats.kendalltau(range(len(candidate_positions)), candidate_positions).statistic
    return float(tau) if tau is not None else math.nan


def run_sensitivity_experiment(
    manifest_path: str | Path,
    config: ExperimentConfig,
) -> pd.DataFrame:
    set_reproducibility(config.seed)
    output_dir = Path(config.output_dir).resolve() / "sensitivity"
    output_dir.mkdir(parents=True, exist_ok=True)
    records = load_manifest(manifest_path, require_labels=False)[
        : config.sensitivity_max_pairs
    ]
    processor = YOLOv5Processor(config)
    rows: List[Dict[str, Any]] = []

    for record in tqdm(records, desc="Sensitivity pairs"):
        try:
            image, detection_a, detection_b, pair_union, features, meta = _prepare_sensitivity_pair(
                processor, record, config
            )
            reference_results, _ = _evaluate_setting(
                processor,
                image,
                detection_a,
                detection_b,
                pair_union,
                features,
                meta,
                config,
                config.k_concepts,
                config.softmax_temperature,
                config.activation_percentile,
                config.blur_radius,
            )
            reference_rank = rank_signature(reference_results)
            sweeps = {
                "K": config.sensitivity_k,
                "temperature": config.sensitivity_temperature,
                "percentile": config.sensitivity_percentile,
                "blur_radius": config.sensitivity_blur,
            }
            for parameter, values in sweeps.items():
                for value in values:
                    k = int(value) if parameter == "K" else config.k_concepts
                    temperature = (
                        float(value)
                        if parameter == "temperature"
                        else config.softmax_temperature
                    )
                    percentile = (
                        float(value)
                        if parameter == "percentile"
                        else config.activation_percentile
                    )
                    blur_radius = (
                        float(value)
                        if parameter == "blur_radius"
                        else config.blur_radius
                    )
                    results, deletion = _evaluate_setting(
                        processor,
                        image,
                        detection_a,
                        detection_b,
                        pair_union,
                        features,
                        meta,
                        config,
                        k,
                        temperature,
                        percentile,
                        blur_radius,
                    )
                    ranking = rank_signature(results)
                    same_top = int(bool(ranking and reference_rank and ranking[0] == reference_rank[0]))
                    tau = (
                        math.nan
                        if parameter == "K"
                        else _kendall_for_rankings(reference_rank, ranking)
                    )
                    rows.append(
                        {
                            "dataset": record.dataset,
                            "image_id": record.image_id,
                            "object_a": record.object_a,
                            "object_b": record.object_b,
                            "parameter": parameter,
                            "value": value,
                            "value_numeric": float(value),
                            "aoc": deletion.aoc,
                            "max_effect_score": max(
                                result.effect_score for result in results
                            ),
                            "top1_same_as_default": same_top,
                            "kendall_tau_vs_default": tau,
                            "concept_count_observed": len(results),
                        }
                    )
        except Exception as exc:
            print(
                f"Sensitivity skipped {record.image_id}: {type(exc).__name__}: {exc}"
            )

    raw = pd.DataFrame(rows)
    raw.to_csv(output_dir / "sensitivity_raw.csv", index=False)
    if raw.empty:
        return raw
    aggregate = (
        raw.groupby(["parameter", "value", "value_numeric"], dropna=False)
        .agg(
            mean_aoc=("aoc", "mean"),
            std_aoc=("aoc", "std"),
            n=("aoc", "count"),
            mean_max_effect=("max_effect_score", "mean"),
            top1_stability=("top1_same_as_default", "mean"),
            mean_kendall_tau=("kendall_tau_vs_default", "mean"),
        )
        .reset_index()
    )
    aggregate.to_csv(output_dir / "sensitivity_aggregate.csv", index=False)
    plot_sensitivity(aggregate, output_dir / "figures")
    return raw
