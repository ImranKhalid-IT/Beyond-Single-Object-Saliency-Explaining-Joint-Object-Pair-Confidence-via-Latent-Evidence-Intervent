from __future__ import annotations

import json
import math
import random
import heapq
import shutil
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import cv2
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw
from tqdm.auto import tqdm

from .config import ExperimentConfig
from .geometry import (
    box_area,
    normalized_box_gap,
    normalized_center_distance,
    union_box,
    xywh_to_xyxy,
)


MANIFEST_COLUMNS = [
    "dataset",
    "image_id",
    "image_path",
    "object_a",
    "object_b",
    "box_a_x1",
    "box_a_y1",
    "box_a_x2",
    "box_a_y2",
    "box_b_x1",
    "box_b_y1",
    "box_b_x2",
    "box_b_y2",
    "relation_label",
    "relation_name",
    "annotation_source",
    "quality_score",
]


@dataclass
class PairRecord:
    dataset: str
    image_id: str
    image_path: str
    object_a: str
    object_b: str
    box_a: np.ndarray
    box_b: np.ndarray
    relation_label: Optional[int] = None
    relation_name: str = ""
    annotation_source: str = ""
    quality_score: float = 0.0

    def to_row(self) -> Dict[str, Any]:
        return {
            "dataset": self.dataset,
            "image_id": self.image_id,
            "image_path": self.image_path,
            "object_a": self.object_a,
            "object_b": self.object_b,
            "box_a_x1": float(self.box_a[0]),
            "box_a_y1": float(self.box_a[1]),
            "box_a_x2": float(self.box_a[2]),
            "box_a_y2": float(self.box_a[3]),
            "box_b_x1": float(self.box_b[0]),
            "box_b_y1": float(self.box_b[1]),
            "box_b_x2": float(self.box_b[2]),
            "box_b_y2": float(self.box_b[3]),
            "relation_label": "" if self.relation_label is None else int(self.relation_label),
            "relation_name": self.relation_name,
            "annotation_source": self.annotation_source,
            "quality_score": float(self.quality_score),
        }

    @classmethod
    def from_row(cls, row: pd.Series) -> "PairRecord":
        raw_label = row.get("relation_label", "")
        label: Optional[int]
        if pd.isna(raw_label) or str(raw_label).strip() == "":
            label = None
        else:
            label = int(float(raw_label))
        return cls(
            dataset=str(row["dataset"]),
            image_id=str(row["image_id"]),
            image_path=str(row["image_path"]),
            object_a=str(row["object_a"]),
            object_b=str(row["object_b"]),
            box_a=np.array(
                [row.box_a_x1, row.box_a_y1, row.box_a_x2, row.box_a_y2],
                dtype=np.float32,
            ),
            box_b=np.array(
                [row.box_b_x1, row.box_b_y1, row.box_b_x2, row.box_b_y2],
                dtype=np.float32,
            ),
            relation_label=label,
            relation_name=str(row.get("relation_name", "") or ""),
            annotation_source=str(row.get("annotation_source", "") or ""),
            quality_score=float(row.get("quality_score", 0.0)),
        )


def save_manifest(records: Sequence[PairRecord], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame([record.to_row() for record in records], columns=MANIFEST_COLUMNS)
    frame.to_csv(path, index=False)
    return path


def load_manifest(path: str | Path, require_labels: bool = False) -> List[PairRecord]:
    path = Path(path)
    frame = pd.read_csv(path, dtype={"image_id": str})
    missing = sorted(set(MANIFEST_COLUMNS[:13]) - set(frame.columns))
    if missing:
        raise ValueError(f"Manifest is missing required columns: {missing}")
    records = [PairRecord.from_row(row) for _, row in frame.iterrows()]
    if require_labels:
        unlabeled = [record.image_id for record in records if record.relation_label is None]
        if unlabeled:
            raise ValueError(
                f"Manifest contains {len(unlabeled)} unlabeled pairs. Fill relation_label "
                "with 1 for an interaction and 0 for non-interacting co-occurrence."
            )
    return records


def _download(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {url}")
    with urllib.request.urlopen(url) as response, destination.open("wb") as output:
        shutil.copyfileobj(response, output)


def _extract(zip_path: Path, destination: Path) -> None:
    print(f"Extracting {zip_path.name}...")
    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(destination)


def ensure_coco(root: str | Path, auto_download: bool = True) -> Tuple[Path, Path]:
    root = Path(root)
    image_dir = root / "val2017"
    annotation_file = root / "annotations" / "instances_val2017.json"
    if image_dir.exists() and annotation_file.exists():
        return image_dir, annotation_file
    if not auto_download:
        raise FileNotFoundError(
            f"COCO was not found at {root}. Expected {image_dir} and {annotation_file}."
        )
    root.mkdir(parents=True, exist_ok=True)
    image_zip = root / "val2017.zip"
    annotation_zip = root / "annotations_trainval2017.zip"
    if not image_zip.exists():
        _download("https://images.cocodataset.org/zips/val2017.zip", image_zip)
    if not annotation_zip.exists():
        _download(
            "https://images.cocodataset.org/annotations/annotations_trainval2017.zip",
            annotation_zip,
        )
    if not image_dir.exists():
        _extract(image_zip, root)
    if not annotation_file.exists():
        _extract(annotation_zip, root)
    if not image_dir.exists() or not annotation_file.exists():
        raise RuntimeError("COCO download/extraction did not create expected files.")
    return image_dir, annotation_file


DEFAULT_COCO_PAIRS: List[Tuple[str, str]] = [
    ("person", "bicycle"),
    ("person", "laptop"),
    ("car", "traffic light"),
    ("dog", "frisbee"),
    ("person", "horse"),
    ("person", "motorcycle"),
    ("person", "tv"),
]


def prepare_coco_manifest(
    coco_root: str | Path,
    output_csv: str | Path,
    config: ExperimentConfig,
    object_pairs: Optional[Sequence[Tuple[str, str]]] = None,
    candidates_per_pair: int = 30,
    auto_download: bool = True,
) -> Path:
    try:
        from pycocotools.coco import COCO
    except ImportError as exc:
        raise ImportError("Install pycocotools before preparing COCO data.") from exc

    image_dir, annotation_file = ensure_coco(coco_root, auto_download=auto_download)
    coco = COCO(str(annotation_file))
    categories = coco.loadCats(coco.getCatIds())
    category_id = {category["name"]: category["id"] for category in categories}
    pairs = list(object_pairs or DEFAULT_COCO_PAIRS)
    records: List[PairRecord] = []

    def annotations_for(image_id: int, category_name: str) -> List[Dict[str, Any]]:
        ann_ids = coco.getAnnIds(
            imgIds=[image_id], catIds=[category_id[category_name]], iscrowd=False
        )
        return [
            ann
            for ann in coco.loadAnns(ann_ids)
            if float(ann.get("area", 0.0)) > 1.0
        ]

    for object_a, object_b in pairs:
        if object_a not in category_id or object_b not in category_id:
            print(f"Skipping unavailable COCO pair: {object_a}+{object_b}")
            continue
        image_ids = coco.getImgIds(
            catIds=[category_id[object_a], category_id[object_b]]
        )
        scored: List[PairRecord] = []
        for image_id in tqdm(image_ids, desc=f"COCO {object_a}+{object_b}"):
            info = coco.loadImgs([image_id])[0]
            width, height = int(info["width"]), int(info["height"])
            best: Optional[PairRecord] = None
            for ann_a in annotations_for(image_id, object_a):
                box_a = xywh_to_xyxy(ann_a["bbox"])
                if box_area(box_a) / (width * height) < config.min_object_area_fraction:
                    continue
                for ann_b in annotations_for(image_id, object_b):
                    box_b = xywh_to_xyxy(ann_b["bbox"])
                    if box_area(box_b) / (width * height) < config.min_object_area_fraction:
                        continue
                    gap = normalized_box_gap(box_a, box_b, width, height)
                    pair_union = union_box(box_a, box_b)
                    union_fraction = box_area(pair_union) / float(width * height)
                    if gap > config.max_gap_fraction or union_fraction > config.max_union_fraction:
                        continue
                    center_distance = normalized_center_distance(
                        box_a, box_b, width, height
                    )
                    quality = 0.50 * gap + 0.30 * center_distance + 0.20 * union_fraction
                    candidate = PairRecord(
                        dataset="COCO2017",
                        image_id=str(image_id),
                        image_path=str((image_dir / info["file_name"]).resolve()),
                        object_a=object_a,
                        object_b=object_b,
                        box_a=box_a,
                        box_b=box_b,
                        relation_label=None,
                        relation_name="",
                        annotation_source="COCO co-occurrence; manual relation label required",
                        quality_score=float(quality),
                    )
                    if best is None or candidate.quality_score < best.quality_score:
                        best = candidate
            if best is not None:
                scored.append(best)
        scored.sort(key=lambda record: record.quality_score)
        records.extend(scored[:candidates_per_pair])

    path = save_manifest(records, output_csv)
    create_manifest_contact_sheets(records, path.parent / "contact_sheets")
    print(
        f"Saved {len(records)} COCO candidates to {path}. COCO has object labels, not "
        "relationship labels; manually set relation_label to 1 or 0 before the "
        "positive-versus-negative experiment."
    )
    return path


# Common aliases needed to align Visual Genome object names with COCO detector classes.
VG_TO_COCO = {
    "man": "person",
    "woman": "person",
    "boy": "person",
    "girl": "person",
    "people": "person",
    "bike": "bicycle",
    "cycle": "bicycle",
    "motorbike": "motorcycle",
    "motor cycle": "motorcycle",
    "automobile": "car",
    "vehicle": "car",
    "traffic signal": "traffic light",
    "signal light": "traffic light",
    "television": "tv",
    "tv monitor": "tv",
    "notebook computer": "laptop",
    "computer": "laptop",
    "cellphone": "cell phone",
    "mobile phone": "cell phone",
    "sofa": "couch",
}

COCO_CLASS_NAMES: Set[str] = {
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier",
    "toothbrush",
}


def normalize_vg_name(names: Sequence[str] | str) -> Optional[str]:
    if isinstance(names, str):
        candidates = [names]
    else:
        candidates = list(names)
    for raw in candidates:
        name = str(raw).strip().lower().replace("_", " ")
        name = VG_TO_COCO.get(name, name)
        if name in COCO_CLASS_NAMES:
            return name
    return None


def _resolve_vg_image(image_root: Path, image_id: int) -> Optional[Path]:
    candidates = [
        image_root / f"{image_id}.jpg",
        image_root / "VG_100K" / f"{image_id}.jpg",
        image_root / "VG_100K_2" / f"{image_id}.jpg",
        image_root / f"{image_id}.png",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    return None


def _vg_box(entity: Dict[str, Any]) -> np.ndarray:
    return xywh_to_xyxy(
        [entity.get("x", 0), entity.get("y", 0), entity.get("w", 0), entity.get("h", 0)]
    )


def prepare_visual_genome_manifest(
    relationships_json: str | Path,
    image_root: str | Path,
    output_csv: str | Path,
    config: ExperimentConfig,
    max_positive: int = 100,
    max_negative: int = 100,
) -> Path:
    """Build a balanced relation-labelled manifest from Visual Genome.

    Positive pairs are explicit Visual Genome relationships. Negative pairs are
    spatially plausible object pairs in the same image that have no annotated
    directed or reverse relationship between their object IDs. Because missing
    annotations are possible in Visual Genome, these negatives should still be
    spot-checked before publication.
    """
    relationships_json = Path(relationships_json)
    image_root = Path(image_root)
    positives_heap: List[Tuple[float, int, PairRecord]] = []
    negatives_heap: List[Tuple[float, int, PairRecord]] = []
    heap_counter = 0
    rng = random.Random(config.seed)

    try:
        import ijson

        source_file = relationships_json.open("rb")
        data_iter = ijson.items(source_file, "item")
    except ImportError:
        source_file = None
        data_iter = iter(json.loads(relationships_json.read_text(encoding="utf-8")))

    def keep_best(
        heap: List[Tuple[float, int, PairRecord]],
        record: PairRecord,
        limit: int,
    ) -> None:
        nonlocal heap_counter
        heap_counter += 1
        # Negative quality makes the worst (largest quality) record the heap minimum.
        heapq.heappush(heap, (-float(record.quality_score), heap_counter, record))
        if len(heap) > max(1, limit):
            heapq.heappop(heap)

    try:
        for image_entry in tqdm(data_iter, desc="Visual Genome relationships"):
            image_id = int(image_entry.get("image_id"))
            image_path = _resolve_vg_image(image_root, image_id)
            if image_path is None:
                continue
            try:
                with Image.open(image_path) as image:
                    width, height = image.size
            except Exception:
                continue
            image_area = float(width * height)
            relationships = image_entry.get("relationships", [])
            related_ids: Set[frozenset[int]] = set()
            object_by_id: Dict[int, Tuple[str, np.ndarray]] = {}

            for relation in relationships:
                subject = relation.get("subject", {})
                obj = relation.get("object", {})
                subject_id = int(subject.get("object_id", -1))
                object_id = int(obj.get("object_id", -1))
                subject_name = normalize_vg_name(
                    subject.get("names", subject.get("name", ""))
                )
                object_name = normalize_vg_name(
                    obj.get("names", obj.get("name", ""))
                )
                subject_box = _vg_box(subject)
                object_box = _vg_box(obj)
                if subject_id >= 0 and subject_name:
                    object_by_id[subject_id] = (subject_name, subject_box)
                if object_id >= 0 and object_name:
                    object_by_id[object_id] = (object_name, object_box)
                if subject_id < 0 or object_id < 0:
                    continue
                related_ids.add(frozenset((subject_id, object_id)))
                if not subject_name or not object_name:
                    continue
                if (
                    min(box_area(subject_box), box_area(object_box)) / image_area
                    < config.min_object_area_fraction
                ):
                    continue
                pair_union = union_box(subject_box, object_box)
                union_fraction = box_area(pair_union) / image_area
                gap = normalized_box_gap(subject_box, object_box, width, height)
                if (
                    union_fraction > config.max_union_fraction
                    or gap > config.max_gap_fraction
                ):
                    continue
                quality = (
                    0.5 * gap
                    + 0.3
                    * normalized_center_distance(
                        subject_box, object_box, width, height
                    )
                    + 0.2 * union_fraction
                )
                keep_best(
                    positives_heap,
                    PairRecord(
                        dataset="VisualGenome",
                        image_id=str(image_id),
                        image_path=str(image_path),
                        object_a=subject_name,
                        object_b=object_name,
                        box_a=subject_box,
                        box_b=object_box,
                        relation_label=1,
                        relation_name=str(
                            relation.get("predicate", "interaction")
                        ).strip().lower(),
                        annotation_source="Visual Genome relationship annotation",
                        quality_score=float(quality),
                    ),
                    max_positive * 4,
                )

            objects = list(object_by_id.items())
            candidate_negatives: List[PairRecord] = []
            for index_a in range(len(objects)):
                id_a, (name_a, box_a) = objects[index_a]
                for index_b in range(index_a + 1, len(objects)):
                    id_b, (name_b, box_b) = objects[index_b]
                    if frozenset((id_a, id_b)) in related_ids:
                        continue
                    if (
                        name_a == name_b
                        and calculate_box_overlap_for_duplicate(box_a, box_b) > 0.7
                    ):
                        continue
                    if (
                        min(box_area(box_a), box_area(box_b)) / image_area
                        < config.min_object_area_fraction
                    ):
                        continue
                    gap = normalized_box_gap(box_a, box_b, width, height)
                    pair_union = union_box(box_a, box_b)
                    union_fraction = box_area(pair_union) / image_area
                    if (
                        gap > config.max_gap_fraction
                        or union_fraction > config.max_union_fraction
                    ):
                        continue
                    quality = (
                        0.5 * gap
                        + 0.3
                        * normalized_center_distance(box_a, box_b, width, height)
                        + 0.2 * union_fraction
                    )
                    candidate_negatives.append(
                        PairRecord(
                            dataset="VisualGenome",
                            image_id=str(image_id),
                            image_path=str(image_path),
                            object_a=name_a,
                            object_b=name_b,
                            box_a=box_a,
                            box_b=box_b,
                            relation_label=0,
                            relation_name="no annotated relationship",
                            annotation_source=(
                                "Visual Genome co-occurrence without annotated relation; "
                                "manual verification advised"
                            ),
                            quality_score=float(quality),
                        )
                    )
            candidate_negatives.sort(key=lambda record: record.quality_score)
            for candidate in candidate_negatives[:2]:
                keep_best(negatives_heap, candidate, max_negative * 4)
    finally:
        if source_file is not None:
            source_file.close()

    positives = [item[2] for item in positives_heap]
    negatives = [item[2] for item in negatives_heap]
    positives.sort(key=lambda record: record.quality_score)
    negatives.sort(key=lambda record: record.quality_score)
    positives = deduplicate_records(positives)[:max_positive]
    negatives = deduplicate_records(negatives)[:max_negative]
    rng.shuffle(positives)
    rng.shuffle(negatives)
    records = positives + negatives
    rng.shuffle(records)
    path = save_manifest(records, output_csv)
    create_manifest_contact_sheets(records, path.parent / "contact_sheets")
    print(
        f"Saved Visual Genome manifest: {len(positives)} positive and "
        f"{len(negatives)} candidate negative pairs. Manually verify negatives before publication."
    )
    return path

def calculate_box_overlap_for_duplicate(box_a: np.ndarray, box_b: np.ndarray) -> float:
    x1 = max(float(box_a[0]), float(box_b[0]))
    y1 = max(float(box_a[1]), float(box_b[1]))
    x2 = min(float(box_a[2]), float(box_b[2]))
    y2 = min(float(box_a[3]), float(box_b[3]))
    intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    return intersection / (min(box_area(box_a), box_area(box_b)) + 1e-8)


def deduplicate_records(records: Sequence[PairRecord]) -> List[PairRecord]:
    seen: Set[Tuple[str, str, str, Tuple[int, ...], Tuple[int, ...]]] = set()
    result: List[PairRecord] = []
    for record in records:
        key = (
            record.dataset,
            record.image_id,
            f"{record.object_a}|{record.object_b}",
            tuple(np.round(record.box_a).astype(int)),
            tuple(np.round(record.box_b).astype(int)),
        )
        if key not in seen:
            seen.add(key)
            result.append(record)
    return result


def create_manifest_contact_sheets(
    records: Sequence[PairRecord],
    output_dir: str | Path,
    page_size: int = 20,
    thumb_size: Tuple[int, int] = (360, 260),
) -> List[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    saved: List[Path] = []
    for page_start in range(0, len(records), page_size):
        subset = list(records[page_start : page_start + page_size])
        columns = 4
        rows = math.ceil(len(subset) / columns)
        cell_w, cell_h = thumb_size[0], thumb_size[1] + 70
        sheet = Image.new("RGB", (columns * cell_w, rows * cell_h), "white")
        draw = ImageDraw.Draw(sheet)
        for local_index, record in enumerate(subset):
            try:
                image = Image.open(record.image_path).convert("RGB")
            except Exception:
                continue
            scale = min(thumb_size[0] / image.width, thumb_size[1] / image.height)
            resized = image.resize(
                (max(1, int(image.width * scale)), max(1, int(image.height * scale))),
                Image.Resampling.LANCZOS,
            )
            canvas = Image.new("RGB", thumb_size, "black")
            offset = ((thumb_size[0] - resized.width) // 2, (thumb_size[1] - resized.height) // 2)
            canvas.paste(resized, offset)
            # Boxes transformed to thumbnail coordinates.
            canvas_np = np.asarray(canvas).copy()
            for box, color in [(record.box_a, (255, 255, 0)), (record.box_b, (0, 255, 255))]:
                transformed = np.array(box, dtype=float) * scale
                transformed[[0, 2]] += offset[0]
                transformed[[1, 3]] += offset[1]
                x1, y1, x2, y2 = np.round(transformed).astype(int)
                cv2.rectangle(canvas_np, (x1, y1), (x2, y2), color, 2)
            canvas = Image.fromarray(canvas_np)
            col = local_index % columns
            row = local_index // columns
            x, y = col * cell_w, row * cell_h
            sheet.paste(canvas, (x, y))
            global_index = page_start + local_index
            label = "?" if record.relation_label is None else str(record.relation_label)
            draw.text(
                (x + 5, y + thumb_size[1] + 5),
                f"row={global_index} label={label}\n{record.object_a} + {record.object_b}\nimage={record.image_id}",
                fill="black",
            )
        path = output_dir / f"manifest_page_{page_start // page_size + 1:03d}.jpg"
        sheet.save(path, quality=92)
        saved.append(path)
    return saved
