from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from PIL import Image

from .config import ExperimentConfig
from .geometry import LetterboxMeta, calculate_iou, letterbox_rgb


@dataclass
class Detection:
    box_xyxy: np.ndarray
    score: float
    label_idx: int
    class_name: str

    def to_json(self) -> Dict[str, Any]:
        return {
            "box_xyxy": [float(v) for v in self.box_xyxy],
            "score": float(self.score),
            "label_idx": int(self.label_idx),
            "class_name": self.class_name,
        }


def _collect_4d_tensors(value: Any, output: List[torch.Tensor]) -> None:
    if torch.is_tensor(value) and value.ndim == 4:
        output.append(value)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _collect_4d_tensors(item, output)
    elif isinstance(value, dict):
        for item in value.values():
            _collect_4d_tensors(item, output)


class YOLOv5Processor:
    """YOLOv5 detector plus high-resolution neck-feature capture.

    The model is loaded through the official Ultralytics YOLOv5 Torch Hub entry.
    The detector remains frozen throughout all explanation experiments.
    """

    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config
        self.device = config.resolved_device()
        self.input_size = int(config.model_input_size)
        print(f"Loading {config.model_name} on {self.device}...")
        try:
            self.detector = torch.hub.load(
                "ultralytics/yolov5",
                config.model_name,
                pretrained=True,
                trust_repo=True,
                skip_validation=True,
            )
        except TypeError:
            self.detector = torch.hub.load(
                "ultralytics/yolov5",
                config.model_name,
                pretrained=True,
                trust_repo=True,
            )
        self.detector = self.detector.to(self.device).eval()
        self.detector.max_det = 300
        self.backend = self.detector.model
        try:
            self.detect_layer = self.backend.model.model[-1]
        except Exception as exc:
            raise RuntimeError(
                "Could not resolve the YOLOv5 Detect layer. The Torch Hub model "
                "structure may have changed. Pin a known YOLOv5 commit or use the "
                "environment versions in requirements.txt."
            ) from exc
        self._captured_feature: Optional[torch.Tensor] = None

    def _capture_detect_inputs(
        self, module: torch.nn.Module, inputs: Tuple[Any, ...]
    ) -> None:
        tensors: List[torch.Tensor] = []
        _collect_4d_tensors(inputs, tensors)
        if not tensors:
            self._captured_feature = None
            return
        selected = max(tensors, key=lambda tensor: tensor.shape[-2] * tensor.shape[-1])
        self._captured_feature = selected.detach().clone()

    def detect(
        self,
        image: Image.Image,
        conf_threshold: Optional[float] = None,
        iou_threshold: Optional[float] = None,
    ) -> List[Detection]:
        conf = (
            self.config.initial_detection_conf
            if conf_threshold is None
            else float(conf_threshold)
        )
        nms_iou = (
            self.config.detection_nms_iou
            if iou_threshold is None
            else float(iou_threshold)
        )
        self.detector.conf = conf
        self.detector.iou = nms_iou
        with torch.no_grad():
            results = self.detector(image, size=self.input_size)
        detections: List[Detection] = []
        dataframe = results.pandas().xyxy[0]
        for _, row in dataframe.iterrows():
            label_idx = int(row["class"])
            detections.append(
                Detection(
                    box_xyxy=np.array(
                        [row.xmin, row.ymin, row.xmax, row.ymax], dtype=np.float32
                    ),
                    score=float(row.confidence),
                    label_idx=label_idx,
                    class_name=str(self.detector.names[label_idx]),
                )
            )
        return detections

    def detect_batch(
        self,
        images: Sequence[Image.Image],
        conf_threshold: Optional[float] = None,
    ) -> List[List[Detection]]:
        if not images:
            return []
        conf = (
            self.config.intervention_detection_conf
            if conf_threshold is None
            else float(conf_threshold)
        )
        old_conf = float(self.detector.conf)
        self.detector.conf = conf
        try:
            with torch.no_grad():
                results = self.detector(list(images), size=self.input_size)
            frames = results.pandas().xyxy
            all_detections: List[List[Detection]] = []
            for frame in frames:
                detections: List[Detection] = []
                for _, row in frame.iterrows():
                    label_idx = int(row["class"])
                    detections.append(
                        Detection(
                            box_xyxy=np.array(
                                [row.xmin, row.ymin, row.xmax, row.ymax],
                                dtype=np.float32,
                            ),
                            score=float(row.confidence),
                            label_idx=label_idx,
                            class_name=str(self.detector.names[label_idx]),
                        )
                    )
                all_detections.append(detections)
            return all_detections
        finally:
            self.detector.conf = old_conf

    def extract_features(
        self, image: Image.Image
    ) -> Tuple[torch.Tensor, LetterboxMeta]:
        image_rgb = np.asarray(image.convert("RGB"))
        padded, meta = letterbox_rgb(
            image_rgb, new_shape=(self.input_size, self.input_size)
        )
        tensor = (
            torch.from_numpy(padded)
            .to(self.device)
            .permute(2, 0, 1)
            .contiguous()
            .unsqueeze(0)
            .float()
            / 255.0
        )
        if getattr(self.backend, "fp16", False):
            tensor = tensor.half()
        self._captured_feature = None
        handle = self.detect_layer.register_forward_pre_hook(
            self._capture_detect_inputs
        )
        try:
            with torch.no_grad():
                _ = self.backend(tensor, augment=False, visualize=False)
        finally:
            handle.remove()
        if self._captured_feature is None:
            raise RuntimeError("YOLOv5 feature capture failed.")
        return self._captured_feature, meta


def match_detection(
    detections: Sequence[Detection],
    class_name: str,
    reference_box: np.ndarray,
    minimum_iou: float,
) -> Optional[Detection]:
    candidates: List[Tuple[float, float, Detection]] = []
    for detection in detections:
        if detection.class_name != class_name:
            continue
        iou = calculate_iou(detection.box_xyxy, reference_box)
        candidates.append((iou, detection.score, detection))
    if not candidates:
        return None
    best_iou, _, best_detection = max(candidates, key=lambda item: (item[0], item[1]))
    return best_detection if best_iou >= minimum_iou else None


def matched_detection_score(
    detections: Sequence[Detection],
    target: Detection,
    minimum_iou: float,
) -> float:
    best = 0.0
    for detection in detections:
        if detection.label_idx != target.label_idx:
            continue
        overlap = calculate_iou(target.box_xyxy, detection.box_xyxy)
        if overlap >= minimum_iou:
            best = max(best, float(detection.score))
    return best


def matched_detection_similarity(
    detections: Sequence[Detection], target: Detection
) -> float:
    """D-RISE localization × same-class confidence similarity."""
    best = 0.0
    for detection in detections:
        if detection.label_idx != target.label_idx:
            continue
        overlap = calculate_iou(target.box_xyxy, detection.box_xyxy)
        best = max(best, overlap * float(detection.score))
    return best
