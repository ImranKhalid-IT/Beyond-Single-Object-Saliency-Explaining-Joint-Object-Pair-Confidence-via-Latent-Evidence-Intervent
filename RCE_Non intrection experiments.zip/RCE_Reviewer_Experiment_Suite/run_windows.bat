@echo off
setlocal
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run_experiments.py --config config.json check
 echo.
 echo Environment is ready. See README.md for the next command.
endlocal
