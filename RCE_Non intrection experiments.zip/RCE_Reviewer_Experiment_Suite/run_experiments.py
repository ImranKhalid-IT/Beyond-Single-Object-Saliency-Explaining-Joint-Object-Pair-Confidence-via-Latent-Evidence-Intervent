from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path
from typing import List, Tuple

import numpy as np

from rce_suite.config import ExperimentConfig
from rce_suite.datasets import (
    DEFAULT_COCO_PAIRS,
    prepare_coco_manifest,
    prepare_visual_genome_manifest,
)
from rce_suite.experiments import run_main_experiment, run_sensitivity_experiment
from rce_suite.statistics import run_human_study_statistics


PROJECT_ROOT = Path(__file__).resolve().parent


def load_config(path: str | Path) -> ExperimentConfig:
    config_path = Path(path)
    if not config_path.is_absolute():
        config_path = (Path.cwd() / config_path).resolve()
    config = ExperimentConfig.from_json(config_path)
    output = Path(config.output_dir)
    if not output.is_absolute():
        config.output_dir = str((Path.cwd() / output).resolve())
    return config


def parse_pairs(values: List[str] | None) -> List[Tuple[str, str]]:
    if not values:
        return DEFAULT_COCO_PAIRS
    pairs: List[Tuple[str, str]] = []
    for value in values:
        if "+" not in value:
            raise ValueError(f"Pair must be written as object_a+object_b: {value}")
        object_a, object_b = value.split("+", 1)
        pairs.append((object_a.strip(), object_b.strip()))
    return pairs


def command_check(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    import cv2
    import pandas
    import PIL
    import scipy
    import sklearn
    import torch
    import torchvision

    details = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pandas.__version__,
        "scipy": scipy.__version__,
        "scikit_learn": sklearn.__version__,
        "opencv": cv2.__version__,
        "pillow": PIL.__version__,
        "torch": torch.__version__,
        "torchvision": torchvision.__version__,
        "cuda_available": torch.cuda.is_available(),
        "resolved_device": config.resolved_device(),
        "output_dir": config.output_dir,
    }
    try:
        import pycocotools  # noqa: F401

        details["pycocotools"] = "available"
    except Exception as exc:
        details["pycocotools"] = f"unavailable: {exc}"
    print(json.dumps(details, indent=2))
    if args.with_model:
        from rce_suite.detector import YOLOv5Processor

        processor = YOLOv5Processor(config)
        print(f"Model loaded with {len(processor.detector.names)} classes.")


def command_prepare_coco(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    prepare_coco_manifest(
        coco_root=args.coco_root,
        output_csv=args.output,
        config=config,
        object_pairs=parse_pairs(args.pair),
        candidates_per_pair=args.candidates_per_pair,
        auto_download=not args.no_download,
    )


def command_prepare_vg(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    prepare_visual_genome_manifest(
        relationships_json=args.relationships_json,
        image_root=args.image_root,
        output_csv=args.output,
        config=config,
        max_positive=args.max_positive,
        max_negative=args.max_negative,
    )


def resolve_external_file(args: argparse.Namespace) -> Path | None:
    if args.external_baselines is None:
        return None
    path = Path(args.external_baselines)
    if not path.is_absolute():
        path = (Path.cwd() / path).resolve()
    return path


def command_run_main(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    frame = run_main_experiment(
        manifest_path=args.manifest,
        config=config,
        external_baselines_path=resolve_external_file(args),
    )
    print(frame.to_string(index=False) if not frame.empty else "No valid results.")


def command_run_sensitivity(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    frame = run_sensitivity_experiment(args.manifest, config)
    print(frame.head(30).to_string(index=False) if not frame.empty else "No valid results.")


def command_human_stats(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    outputs = run_human_study_statistics(
        args.human_csv,
        Path(config.output_dir) / "human_study_statistics",
        config.confidence_level,
    )
    for name, table in outputs.items():
        print(f"\n[{name}]\n{table.to_string(index=False)}")


def command_run_all(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    run_main_experiment(
        args.manifest,
        config,
        external_baselines_path=resolve_external_file(args),
    )
    run_sensitivity_experiment(args.manifest, config)
    if args.human_csv:
        run_human_study_statistics(
            args.human_csv,
            Path(config.output_dir) / "human_study_statistics",
            config.confidence_level,
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Reviewer-oriented RCE experiment suite",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--config", default="config.json", help="Experiment JSON file")
    subparsers = parser.add_subparsers(dest="command", required=True)

    check = subparsers.add_parser("check", help="Validate Python environment")
    check.add_argument("--with-model", action="store_true", help="Also download/load YOLOv5")
    check.set_defaults(func=command_check)

    coco = subparsers.add_parser(
        "prepare-coco",
        help="Download/read COCO and export candidate object pairs for manual relation labelling",
    )
    coco.add_argument("--coco-root", default="data/coco")
    coco.add_argument("--output", default="data/coco_pair_manifest.csv")
    coco.add_argument(
        "--pair",
        action="append",
        help="Repeatable object pair, e.g. --pair person+bicycle",
    )
    coco.add_argument("--candidates-per-pair", type=int, default=30)
    coco.add_argument("--no-download", action="store_true")
    coco.set_defaults(func=command_prepare_coco)

    vg = subparsers.add_parser(
        "prepare-vg",
        help="Create positive and candidate-negative Visual Genome relation manifest",
    )
    vg.add_argument("--relationships-json", required=True)
    vg.add_argument("--image-root", required=True)
    vg.add_argument("--output", default="data/visual_genome_pair_manifest.csv")
    vg.add_argument("--max-positive", type=int, default=100)
    vg.add_argument("--max-negative", type=int, default=100)
    vg.set_defaults(func=command_prepare_vg)

    main = subparsers.add_parser(
        "run-main",
        help="Run corrected RCE, common AOC, baselines, negative-pair and paired statistics",
    )
    main.add_argument("--manifest", required=True)
    main.add_argument(
        "--external-baselines",
        default="templates/external_baselines.json",
        help="Optional GCE/CoE adapter configuration",
    )
    main.set_defaults(func=command_run_main)

    sensitivity = subparsers.add_parser(
        "run-sensitivity",
        help="Run K, temperature, percentile and blur-radius sensitivity experiments",
    )
    sensitivity.add_argument("--manifest", required=True)
    sensitivity.set_defaults(func=command_run_sensitivity)

    human = subparsers.add_parser(
        "human-stats", help="Analyze expert/non-expert human-study CSV"
    )
    human.add_argument("--human-csv", required=True)
    human.set_defaults(func=command_human_stats)

    all_parser = subparsers.add_parser(
        "run-all", help="Run main experiment, sensitivity and optional human statistics"
    )
    all_parser.add_argument("--manifest", required=True)
    all_parser.add_argument("--human-csv")
    all_parser.add_argument(
        "--external-baselines", default="templates/external_baselines.json"
    )
    all_parser.set_defaults(func=command_run_all)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        raise SystemExit("Interrupted by user")
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
