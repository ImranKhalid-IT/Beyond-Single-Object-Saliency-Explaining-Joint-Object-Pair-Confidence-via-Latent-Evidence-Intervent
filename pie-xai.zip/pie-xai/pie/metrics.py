"""Pair-level deletion (MoRF) and insertion metrics (Section IV-A, Eqs. 38-42)."""
from __future__ import annotations

import numpy as np

from .intervention import gaussian_blur
from .matching import match_pair

_trapz = getattr(np, "trapezoid", None) or np.trapz


def unit_pixel_order(scores: np.ndarray, maps: np.ndarray, masks: np.ndarray, omega: np.ndarray,
                     tie_break: np.ndarray = None):
    """Pixel ordering of a unit-based explanation (Eq. 38 and the lexicographic keys after it).

    Masked pixels first, then increasing unit rank, then decreasing map value, then raster order.
    `tie_break` (optional, lower first) orders units with equal score.
    """
    K = len(scores)
    tb = np.zeros(K) if tie_break is None else np.asarray(tie_break)
    order = np.lexsort((tb, -np.round(np.asarray(scores, np.float64), 8)))
    rank = np.empty(K, int); rank[order] = np.arange(K)
    ys, xs = np.nonzero(omega)
    m = masks[:, ys, xs]
    covered = m.any(0)
    u = np.where(covered, np.where(m, rank[:, None], K + 1).argmin(0), maps[:, ys, xs].argmax(0))
    keys = np.lexsort((ys * omega.shape[1] + xs, -maps[u, ys, xs], rank[u], ~covered))
    return ys[keys], xs[keys]


def map_pixel_order(rel: np.ndarray, omega: np.ndarray):
    """Pixel ordering of a relevance map R_m: decreasing value, raster tie-break."""
    ys, xs = np.nonzero(omega)
    keys = np.lexsort((ys * omega.shape[1] + xs, -rel[ys, xs]))
    return ys[keys], xs[keys]


def deletion_insertion(detector, img, omega, order, di, dj, fractions, sigma, theta_m, blur=None):
    """MoRF-AUC (Eqs. 39-42) and insertion AUC for one pixel ordering.

    Deletion: the top floor(alpha |Omega|) pixels are replaced by I_blur (Eq. 40).
    Insertion: Omega starts fully blurred and the same pixels are restored.
    Both curves use Algorithm 4 and are normalised by S_ij(I).
    """
    ys, xs = order
    n = len(ys)
    blur = gaussian_blur(img, sigma) if blur is None else blur
    base = np.where(omega[..., None], blur, img).astype(np.uint8)
    dele, ins = [], []
    for a in fractions:
        k = int(np.floor(a * n))
        m = np.zeros(omega.shape, bool)
        m[ys[:k], xs[:k]] = True
        dele.append(np.where(m[..., None], blur, img).astype(np.uint8))
        ins.append(np.where(m[..., None], img, base).astype(np.uint8))
    res = detector.detect_many(dele + ins)
    L = len(fractions)
    S0 = max(di["score"] * dj["score"], 1e-8)
    sd = np.array([np.prod(match_pair(r, di, dj, theta_m)) for r in res[:L]]) / S0
    si = np.array([np.prod(match_pair(r, di, dj, theta_m)) for r in res[L:]]) / S0
    fr = np.asarray(fractions, np.float64)
    return float(_trapz(sd, fr)), float(_trapz(si, fr)), sd, si


def merge_object_maps(ri: np.ndarray, rj: np.ndarray) -> np.ndarray:
    """R_ij = (R~_i + R~_j) / 2 with each map scaled to [0, 1] (Eq. 2)."""
    from .geometry import norm01
    return 0.5 * (norm01(ri) + norm01(rj))
