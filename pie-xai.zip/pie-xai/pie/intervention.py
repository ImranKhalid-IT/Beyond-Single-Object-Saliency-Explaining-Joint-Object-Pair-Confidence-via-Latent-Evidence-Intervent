"""Interventional ranking (Section III-D/E, Eqs. 25-37, Algorithm 3)."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import cv2
import numpy as np

from .geometry import union_box
from .matching import match_pair
from .units import discover_units


# ----------------------------------------------------------------------------- masks (Eqs. 25-26)
def top_fraction_mask(m: np.ndarray, omega: np.ndarray, frac: float) -> np.ndarray:
    """Exactly the top `frac` of Omega_ij pixels by map value (ties in raster order).

    Equivalent to thresholding at the (1 - frac) percentile (Eq. 25) but with a fixed area,
    so a mask can never cover the whole union region when many values are tied.
    """
    ys, xs = np.nonzero(omega)
    v = m[ys, xs]
    n = max(1, int(math.ceil(frac * len(v))))
    keep = np.argsort(-v, kind="stable")[:n]
    out = np.zeros_like(omega)
    out[ys[keep], xs[keep]] = True
    return out


# ----------------------------------------------------------------------------- replacement (Eq. 27)
def gaussian_blur(img: np.ndarray, sigma: float) -> np.ndarray:
    """I_blur = I * G_sigma (Eq. 27)."""
    return cv2.GaussianBlur(img, (0, 0), sigmaX=sigma, sigmaY=sigma, borderType=cv2.BORDER_REFLECT)


def replacement_image(img: np.ndarray, op: str, sigma: float, omega: np.ndarray, mask: np.ndarray = None,
                      seed: int = 0) -> np.ndarray:
    """Replacement content for the operators of Table 10."""
    if op == "gaussian":
        return gaussian_blur(img, sigma)
    if op == "mean":
        out = img.copy(); out[:] = img[omega].mean(0).astype(np.uint8); return out
    if op == "noise":
        rng = np.random.default_rng(seed)
        return rng.integers(0, 256, img.shape, dtype=np.uint8)
    if op == "inpaint":                                 # structure-preserving inpainting (Telea)
        assert mask is not None, "inpainting needs the mask"
        bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        out = cv2.inpaint(bgr, mask.astype(np.uint8) * 255, 5, cv2.INPAINT_TELEA)
        return cv2.cvtColor(out, cv2.COLOR_BGR2RGB)
    raise ValueError(f"unknown replacement operator {op}")


def intervene(img: np.ndarray, mask: np.ndarray, replacement: np.ndarray) -> np.ndarray:
    """I'_k = (1 - M_k) * I + M_k * I_blur (Eq. 28)."""
    return np.where(mask[..., None], replacement, img).astype(np.uint8)


# ----------------------------------------------------------------------------- PIE
@dataclass
class PIEResult:
    maps: np.ndarray            # (K, H, W) pixel unit maps U~_k
    masks: np.ndarray           # (K, H, W) intervention masks M_k
    omega: np.ndarray           # (H, W) union region
    union: np.ndarray           # union box b_ij
    S: float                    # joint confidence S_ij = s_i s_j (Eq. 11)
    post: np.ndarray            # (K, 2) matched post-intervention scores (Eq. 33)
    ce: np.ndarray              # (K,) confidence effects CE_k (Eq. 34)
    fo: np.ndarray              # (K,) first-order terms FO_k = -(s_j ds_i + s_i ds_j)
    cross: np.ndarray           # (K,) cross term ds_i ds_j (Eq. 35)
    activation: np.ndarray      # (K,) activation strength of each unit
    n_forward: int = 0          # detector forward passes used (Eq. 37)
    extra: dict = field(default_factory=dict)

    def order(self, scores=None) -> np.ndarray:
        """Ranking L (Eq. 36): decreasing score; ties broken by lower remaining s'_i + s'_j."""
        s = self.ce if scores is None else np.asarray(scores)
        return np.lexsort((self.post.sum(1), -np.round(s, 8)))


def explain_pair(detector, img: np.ndarray, di: dict, dj: dict, cfg: dict, replacement: str = "gaussian",
                 readout=None, units=None) -> PIEResult | None:
    """Algorithm 1 -> 2 -> 3 for one target pair. Returns None if the union is too small for K units."""
    H, W = img.shape[:2]
    U = union_box(di["box"], dj["box"])
    if units is None:
        readout = readout if readout is not None else detector.readout(img, U)
        units = discover_units(readout, U, W, H, cfg["K"], cfg["tau_s"], seed=cfg["seed"],
                               n_init=cfg.get("kmeans_n_init", 10))
        if units is None:
            return None
    K = units["maps"].shape[0]
    frac = 1.0 - cfg["mask_percentile"] / 100.0
    masks = np.stack([top_fraction_mask(units["maps"][k], units["omega"], frac) for k in range(K)])
    if replacement == "inpaint":
        imgs = [intervene(img, masks[k], replacement_image(img, "inpaint", cfg["sigma"], units["omega"], masks[k]))
                for k in range(K)]
    else:
        rep = replacement_image(img, replacement, cfg["sigma"], units["omega"], seed=cfg["seed"])
        imgs = [intervene(img, masks[k], rep) for k in range(K)]
    post_dets = detector.detect_many(imgs)                                                   # Eq. 29
    post = np.array([match_pair(p, di, dj, cfg["theta_m"]) for p in post_dets], np.float32)  # Eqs. 30-33
    si, sj = di["score"], dj["score"]
    S = si * sj
    dsi, dsj = post[:, 0] - si, post[:, 1] - sj
    ce = S - post[:, 0] * post[:, 1]                                                         # Eq. 34
    fo = -(sj * dsi + si * dsj)
    cross = dsi * dsj
    return PIEResult(maps=units["maps"], masks=masks, omega=units["omega"], union=U, S=S, post=post, ce=ce,
                     fo=fo, cross=cross, activation=units["activation"], n_forward=K + 1,
                     extra=dict(labels=units.get("labels")))


def explain_partition(detector, img, di, dj, masks: np.ndarray, omega, cfg, maps=None) -> PIEResult:
    """CE for an arbitrary partition of Omega_ij (spatial controls: random regions, PC-Grid)."""
    rep = gaussian_blur(img, cfg["sigma"])
    post_dets = detector.detect_many([intervene(img, m, rep) for m in masks])
    post = np.array([match_pair(p, di, dj, cfg["theta_m"]) for p in post_dets], np.float32)
    si, sj = di["score"], dj["score"]
    S = si * sj
    dsi, dsj = post[:, 0] - si, post[:, 1] - sj
    maps = masks.astype(np.float32) if maps is None else maps
    return PIEResult(maps=maps, masks=masks, omega=omega, union=union_box(di["box"], dj["box"]), S=S, post=post,
                     ce=S - post[:, 0] * post[:, 1], fo=-(sj * dsi + si * dsj), cross=dsi * dsj,
                     activation=np.zeros(len(masks), np.float32), n_forward=len(masks) + 1)
