"""Pair-preserving detection matching (Section III-E, Eqs. 30-33, Algorithm 4)."""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .geometry import iou

Detection = Dict  # {"box": np.ndarray xyxy, "score": float, "cls": str}


def match_pair(dets: List[Detection], di: Detection, dj: Detection, theta_m: float) -> Tuple[float, float]:
    """Return the matched post-intervention scores (s'_i, s'_j).

    Candidates are same-class detections with IoU >= theta_m (Eq. 31). The two targets are
    matched jointly and one-to-one by maximising the summed IoU (Eq. 32); ties are broken by the
    higher summed confidence. An unmatched target receives score 0 (Eq. 33).
    """
    ci = [None] + [k for k, d in enumerate(dets) if d["cls"] == di["cls"] and iou(d["box"], di["box"]) >= theta_m]
    cj = [None] + [k for k, d in enumerate(dets) if d["cls"] == dj["cls"] and iou(d["box"], dj["box"]) >= theta_m]
    best: Tuple[Optional[int], Optional[int]] = (None, None)
    key = (-1.0, -1.0)
    for a in ci:
        for b in cj:
            if a is not None and a == b:
                continue
            s = (iou(dets[a]["box"], di["box"]) if a is not None else 0.0) + \
                (iou(dets[b]["box"], dj["box"]) if b is not None else 0.0)
            c = (dets[a]["score"] if a is not None else 0.0) + (dets[b]["score"] if b is not None else 0.0)
            if (s, c) > key:
                key, best = (s, c), (a, b)
    a, b = best
    return (dets[a]["score"] if a is not None else 0.0), (dets[b]["score"] if b is not None else 0.0)


def pick_target(dets: List[Detection], cls: str, gt_box, min_iou: float = 0.5) -> Optional[Detection]:
    """Detection of class `cls` that best overlaps a ground-truth box (used to define the pair)."""
    cand = [d for d in dets if d["cls"] == cls and iou(d["box"], gt_box) >= min_iou]
    return max(cand, key=lambda d: iou(d["box"], gt_box)) if cand else None
