"""One-stage readout: YOLOv5x, PANet P4 (stride 16) grid features (Eq. 15)."""
from __future__ import annotations

import cv2
import numpy as np
import torch

from ..geometry import iou_many, norm01
from ..units import Readout
from .base import Detector, cells_for_region


class YOLOv5Detector(Detector):
    name, family = "yolov5", "one-stage"

    def __init__(self, cfg):
        d = cfg["detectors"]["yolov5"]
        self.size = d.get("input_size", 640)
        self.batch = cfg.get("batch", 32)
        self.device = cfg.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")
        self.m = torch.hub.load("ultralytics/yolov5", d.get("weights", "yolov5x"), pretrained=True,
                                trust_repo=True).to(self.device).eval()
        self.m.conf, self.m.iou, self.m.max_det = cfg["conf"], cfg["nms_iou"], cfg["max_det"]
        self.names = self.m.names
        self.cls_index = {v: k for k, v in self.names.items()}
        self.detect_layer = self.m.model.model.model[-1]
        self.stride = d.get("readout_stride", 16)

    # ------------------------------------------------------------------ detection
    def detect_many(self, images):
        out = []
        for s in range(0, len(images), self.batch):
            with torch.no_grad():
                res = self.m(list(images[s:s + self.batch]), size=self.size).xyxy
            for r in res:
                r = r.cpu().numpy()
                out.append([dict(box=d[:4].astype(np.float32), score=float(d[4]), cls=self.names[int(d[5])]) for d in r])
        return out

    # ------------------------------------------------------------------ internals
    def _letterbox(self, img):
        H, W = img.shape[:2]
        r = min(self.size / H, self.size / W)
        nw, nh = int(round(W * r)), int(round(H * r))
        top, left = (self.size - nh) // 2, (self.size - nw) // 2
        pad = np.full((self.size, self.size, 3), 114, np.uint8)
        pad[top:top + nh, left:left + nw] = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
        x = torch.from_numpy(pad).permute(2, 0, 1)[None].float().div(255).to(self.device)
        return x, dict(r=r, top=top, left=left, nw=nw, nh=nh, W=W, H=H)

    def _forward(self, x, keep_grad):
        box = {}

        def hook(mod, inp):
            maps = [t for t in inp[0] if torch.is_tensor(t) and t.ndim == 4]
            f = min(maps, key=lambda t: abs(self.size / t.shape[-1] - self.stride))
            if keep_grad:
                f.retain_grad()
            box["f"] = f

        h = self.detect_layer.register_forward_pre_hook(hook)
        try:
            if keep_grad:
                with torch.enable_grad():
                    y = self.m.model(x.clone().requires_grad_(True))
            else:
                with torch.no_grad():
                    y = self.m.model(x)
        finally:
            h.remove()
        pred = y[0] if isinstance(y, (list, tuple)) else y
        return pred[0], box["f"]

    def _to_pixels(self, fmap, g):
        up = cv2.resize(fmap.astype(np.float32), (self.size, self.size), interpolation=cv2.INTER_LINEAR)
        crop = up[g["top"]:g["top"] + g["nh"], g["left"]:g["left"] + g["nw"]]
        return cv2.resize(crop, (g["W"], g["H"]), interpolation=cv2.INTER_LINEAR)

    # ------------------------------------------------------------------ readout (Eq. 15)
    def readout(self, image, union_box):
        x, g = self._letterbox(image)
        _, f = self._forward(x, keep_grad=False)
        F = f[0].float().permute(1, 2, 0).cpu().numpy()                     # (h, w, C)
        h, w = F.shape[:2]
        cell = (self.size / w) / g["r"]
        r0, r1, c0, c1, inside, extent = cells_for_region(union_box, -g["left"] / g["r"], -g["top"] / g["r"],
                                                          cell, cell, w, h)
        return Readout(grid=F[r0:r1, c0:c1], extent=extent, inside=inside)

    # ------------------------------------------------------------------ gradients
    def _score(self, pred, targets, g, kind):
        p = pred.detach().float().cpu().numpy()
        xyxy = np.stack([p[:, 0] - p[:, 2] / 2, p[:, 1] - p[:, 3] / 2, p[:, 0] + p[:, 2] / 2, p[:, 1] + p[:, 3] / 2], 1)
        total = None
        for t in targets:
            c = self.cls_index[t["cls"]]
            tb = t["box"] * g["r"] + np.array([g["left"], g["top"], g["left"], g["top"]])
            idx = int(np.argmax(iou_many(xyxy, tb) * p[:, 4] * p[:, 5 + c]))
            s = pred[idx, 4] * pred[idx, 5 + c]
            if kind == "finercam":                       # contrast with the most similar other class
                others = torch.cat([pred[idx, 5:5 + c], pred[idx, 6 + c:]])
                s = s - pred[idx, 4] * others.max()
            total = s if total is None else total * s
        return total

    def gradient_map(self, image, targets, kind="odam"):
        x, g = self._letterbox(image)
        pred, f = self._forward(x, keep_grad=True)
        self._score(pred, targets, g, kind).backward()
        grad, feat = f.grad[0].float(), f[0].detach().float()
        if kind == "odam":
            m = torch.relu((grad * feat).sum(0))
        else:                                            # Grad-CAM and Finer-CAM weighting
            m = torch.relu((grad.mean((1, 2))[:, None, None] * feat).sum(0))
        self.m.model.zero_grad(set_to_none=True)
        return norm01(self._to_pixels(m.cpu().numpy(), g))
