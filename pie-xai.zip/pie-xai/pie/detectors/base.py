"""Common detector interface used by PIE, the baselines and the metrics."""
from __future__ import annotations

from typing import Dict, List

import numpy as np

Detection = Dict  # {"box": np.float32[4] xyxy in original pixels, "score": float, "cls": str}


class Detector:
    """Frozen detector adapter.

    detect_many(images)                 -> list of detection lists (same thresholds for every call)
    readout(image, union_box)           -> pie.units.Readout (grid / ROI / token readout, Eqs. 13-18)
    gradient_map(image, targets, kind)  -> (H, W) relevance map, kind in {"gradcam", "odam", "finercam"};
                                           with two targets the gradient of s_i * s_j is used
                                           ("pair-union attribution").
    """
    name = "base"
    family = "base"

    def detect_many(self, images: List[np.ndarray]) -> List[List[Detection]]:
        raise NotImplementedError

    def detect(self, image: np.ndarray) -> List[Detection]:
        return self.detect_many([image])[0]

    def readout(self, image: np.ndarray, union_box):
        raise NotImplementedError

    def gradient_map(self, image: np.ndarray, targets: List[Detection], kind: str = "odam") -> np.ndarray:
        raise NotImplementedError


def cells_for_region(union, cell_x0, cell_y0, cell_w, cell_h, gw, gh):
    """Rows/cols of a regular feature grid that overlap the union box, plus centre-inside flags.

    Cell (r, c) covers image x in [cell_x0 + c*cell_w, cell_x0 + (c+1)*cell_w) (same for y).
    Returns (r0, r1, c0, c1, inside, extent).
    """
    x0, y0, x1, y1 = union
    c0 = int(np.clip(np.floor((x0 - cell_x0) / cell_w), 0, gw - 1))
    c1 = int(np.clip(np.ceil((x1 - cell_x0) / cell_w), c0 + 1, gw))
    r0 = int(np.clip(np.floor((y0 - cell_y0) / cell_h), 0, gh - 1))
    r1 = int(np.clip(np.ceil((y1 - cell_y0) / cell_h), r0 + 1, gh))
    cx = cell_x0 + (np.arange(c0, c1) + 0.5) * cell_w
    cy = cell_y0 + (np.arange(r0, r1) + 0.5) * cell_h
    inside = ((cy[:, None] >= y0) & (cy[:, None] <= y1)) & ((cx[None] >= x0) & (cx[None] <= x1))
    extent = (cell_x0 + c0 * cell_w, cell_y0 + r0 * cell_h, cell_x0 + c1 * cell_w, cell_y0 + r1 * cell_h)
    return r0, r1, c0, c1, inside, extent


def build_detector(name: str, cfg: dict) -> Detector:
    if name == "yolov5":
        from .yolov5 import YOLOv5Detector
        return YOLOv5Detector(cfg)
    if name == "faster_rcnn":
        from .faster_rcnn import FasterRCNNDetector
        return FasterRCNNDetector(cfg)
    if name == "detr":
        from .detr import DETRDetector
        return DETRDetector(cfg)
    raise ValueError(f"unknown detector {name}")
