"""Two-stage readout: Faster R-CNN R101-FPN (Detectron2), ROI-Align on b_ij (Eq. 16)."""
from __future__ import annotations

import math

import cv2
import numpy as np
import torch
from torchvision.ops import roi_align

from ..geometry import norm01
from ..units import Readout
from .base import Detector


class FasterRCNNDetector(Detector):
    name, family = "faster_rcnn", "two-stage"

    def __init__(self, cfg):
        from detectron2 import model_zoo
        from detectron2.checkpoint import DetectionCheckpointer
        from detectron2.config import get_cfg
        from detectron2.data import MetadataCatalog
        from detectron2.data import transforms as T
        from detectron2.modeling import build_model

        d = cfg["detectors"]["faster_rcnn"]
        zoo = d.get("zoo_config", "COCO-Detection/faster_rcnn_R_101_FPN_3x.yaml")
        c = get_cfg()
        c.merge_from_file(model_zoo.get_config_file(zoo))
        c.MODEL.WEIGHTS = d.get("weights") or model_zoo.get_checkpoint_url(zoo)
        c.MODEL.ROI_HEADS.SCORE_THRESH_TEST = cfg["conf"]
        c.MODEL.ROI_HEADS.NMS_THRESH_TEST = cfg["nms_iou"]
        c.TEST.DETECTIONS_PER_IMAGE = cfg["max_det"]
        c.MODEL.DEVICE = cfg.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = build_model(c).eval()
        DetectionCheckpointer(self.model).load(c.MODEL.WEIGHTS)
        self.aug = T.ResizeShortestEdge([c.INPUT.MIN_SIZE_TEST] * 2, c.INPUT.MAX_SIZE_TEST)
        self.names = MetadataCatalog.get(c.DATASETS.TEST[0]).thing_classes
        self.cls_index = {n: i for i, n in enumerate(self.names)}
        self.G = d.get("roi_grid", 7)
        self.sampling_ratio = d.get("sampling_ratio", 2)
        self.batch = cfg.get("batch", 8)
        self.device = c.MODEL.DEVICE

    # ------------------------------------------------------------------ helpers
    def _inputs(self, img):
        H, W = img.shape[:2]
        bgr = img[:, :, ::-1]
        t = self.aug.get_transform(bgr).apply_image(bgr)
        tensor = torch.as_tensor(np.ascontiguousarray(t.transpose(2, 0, 1))).float()
        return {"image": tensor, "height": H, "width": W}, (t.shape[1] / W, t.shape[0] / H), t.shape[:2]

    @staticmethod
    def _level(box_resized):
        w, h = box_resized[2] - box_resized[0], box_resized[3] - box_resized[1]
        k = math.floor(4 + math.log2(math.sqrt(max(w * h, 1e-6)) / 224 + 1e-8))      # FPN rule, canonical 224
        return int(min(max(k, 2), 5))

    # ------------------------------------------------------------------ detection
    def detect_many(self, images):
        out = []
        for s in range(0, len(images), self.batch):
            inputs = [self._inputs(im)[0] for im in images[s:s + self.batch]]
            with torch.no_grad():
                res = self.model(inputs)
            for r in res:
                ins = r["instances"].to("cpu")
                boxes = ins.pred_boxes.tensor.numpy(); sc = ins.scores.numpy(); cl = ins.pred_classes.numpy()
                out.append([dict(box=b.astype(np.float32), score=float(p), cls=self.names[int(k)])
                            for b, p, k in zip(boxes, sc, cl)])
        return out

    # ------------------------------------------------------------------ readout (Eq. 16)
    def readout(self, image, union_box):
        inp, (sx, sy), _ = self._inputs(image)
        ub = np.array([union_box[0] * sx, union_box[1] * sy, union_box[2] * sx, union_box[3] * sy], np.float32)
        lvl = self._level(ub)
        with torch.no_grad():
            images = self.model.preprocess_image([inp])
            feats = self.model.backbone(images.tensor)
            f = feats[f"p{lvl}"]
            rois = torch.tensor([[0, *ub]], dtype=f.dtype, device=f.device)
            pooled = roi_align(f, rois, output_size=self.G, spatial_scale=1.0 / 2 ** lvl,
                               sampling_ratio=self.sampling_ratio, aligned=True)
        grid = pooled[0].permute(1, 2, 0).float().cpu().numpy()                          # (G, G, C)
        return Readout(grid=grid, extent=tuple(float(v) for v in union_box), inside=np.ones((self.G, self.G), bool))

    # ------------------------------------------------------------------ gradients
    def gradient_map(self, image, targets, kind="odam"):
        from detectron2.structures import Boxes

        H, W = image.shape[:2]
        inp, (sx, sy), (rh, rw) = self._inputs(image)
        with torch.enable_grad():
            images = self.model.preprocess_image([inp])
            feats = self.model.backbone(images.tensor)
            for f in feats.values():
                f.retain_grad()
            rh_ = self.model.roi_heads
            total = None
            for t in targets:
                tb = torch.tensor([[t["box"][0] * sx, t["box"][1] * sy, t["box"][2] * sx, t["box"][3] * sy]],
                                  device=images.tensor.device)
                x = rh_.box_pooler([feats[k] for k in rh_.box_in_features], [Boxes(tb)])
                logits, _ = rh_.box_predictor(rh_.box_head(x))
                prob = torch.softmax(logits[0], 0)
                c = self.cls_index[t["cls"]]
                s = prob[c]
                if kind == "finercam":
                    others = torch.cat([prob[:c], prob[c + 1:-1]])          # last entry is background
                    s = s - others.max()
                total = s if total is None else total * s
            total.backward()
        acc = np.zeros((H, W), np.float32)
        for name, f in feats.items():
            if f.grad is None or not torch.any(f.grad != 0):
                continue
            grad, feat = f.grad[0].float(), f[0].detach().float()
            m = torch.relu((grad * feat).sum(0)) if kind == "odam" else \
                torch.relu((grad.mean((1, 2))[:, None, None] * feat).sum(0))
            stride = 2 ** int(name[1:])
            m = m.cpu().numpy()[: int(math.ceil(rh / stride)), : int(math.ceil(rw / stride))]
            acc += cv2.resize(m, (W, H), interpolation=cv2.INTER_LINEAR)
        self.model.zero_grad(set_to_none=True)
        return norm01(acc)
