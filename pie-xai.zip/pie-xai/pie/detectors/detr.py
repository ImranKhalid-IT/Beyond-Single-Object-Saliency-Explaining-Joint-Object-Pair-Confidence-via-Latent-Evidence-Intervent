"""Transformer readout: DETR-DC5 (R50), tokens of the 6th encoder layer (Eq. 17)."""
from __future__ import annotations

import cv2
import numpy as np
import torch
import torchvision.transforms.functional as TF

from ..geometry import iou_many, norm01
from ..units import Readout
from .base import Detector, cells_for_region

COCO91 = ["N/A", "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
          "traffic light", "fire hydrant", "N/A", "stop sign", "parking meter", "bench", "bird", "cat", "dog",
          "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "N/A", "backpack", "umbrella", "N/A",
          "N/A", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
          "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "N/A",
          "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
          "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
          "N/A", "dining table", "N/A", "N/A", "toilet", "N/A", "tv", "laptop", "mouse", "remote", "keyboard",
          "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "N/A", "book", "clock", "vase",
          "scissors", "teddy bear", "hair drier", "toothbrush"]
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


class DETRDetector(Detector):
    """DETR is a set predictor: no NMS is applied (the nms_iou setting does not apply here)."""
    name, family = "detr", "transformer"

    def __init__(self, cfg):
        d = cfg["detectors"]["detr"]
        self.device = cfg.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = torch.hub.load("facebookresearch/detr:main", d.get("hub_model", "detr_resnet50_dc5"),
                                    pretrained=True).to(self.device).eval()
        self.conf, self.max_det = cfg["conf"], cfg["max_det"]
        self.min_size, self.max_size = d.get("min_size", 800), d.get("max_size", 1333)
        self.batch = cfg.get("batch", 8)
        self.cls_index = {n: i for i, n in enumerate(COCO91) if n != "N/A"}

    # ------------------------------------------------------------------ helpers
    def _resize_hw(self, H, W):
        s = self.min_size / min(H, W)
        if max(H, W) * s > self.max_size:
            s = self.max_size / max(H, W)
        return int(round(H * s)), int(round(W * s))

    def _tensor(self, img):
        H, W = img.shape[:2]
        h, w = self._resize_hw(H, W)
        t = TF.to_tensor(cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR))
        return TF.normalize(t, MEAN, STD).to(self.device), (h, w)

    def _post(self, logits, boxes, H, W):
        prob = logits.softmax(-1)[:, :-1]
        sc, lab = prob.max(-1)
        keep = torch.nonzero(sc >= self.conf).flatten()
        keep = keep[sc[keep].argsort(descending=True)][: self.max_det]
        b = boxes[keep]
        xyxy = torch.stack([b[:, 0] - b[:, 2] / 2, b[:, 1] - b[:, 3] / 2, b[:, 0] + b[:, 2] / 2, b[:, 1] + b[:, 3] / 2], 1)
        xyxy = (xyxy * torch.tensor([W, H, W, H], device=xyxy.device)).cpu().numpy()
        return [dict(box=bb.astype(np.float32), score=float(s), cls=COCO91[int(l)])
                for bb, s, l in zip(xyxy, sc[keep].cpu().numpy(), lab[keep].cpu().numpy()) if COCO91[int(l)] != "N/A"]

    def _forward(self, img, keep_grad):
        store = {}

        def enc_hook(mod, inp, out):
            if keep_grad:
                out.retain_grad()
            store["mem"] = out                                   # (h*w, 1, C)

        def proj_hook(mod, inp, out):
            store["hw"] = out.shape[-2:]

        h1 = self.model.transformer.encoder.register_forward_hook(enc_hook)
        h2 = self.model.input_proj.register_forward_hook(proj_hook)
        x, (rh, rw) = self._tensor(img)
        try:
            ctx = torch.enable_grad() if keep_grad else torch.no_grad()
            with ctx:
                out = self.model([x])
        finally:
            h1.remove(); h2.remove()
        return out, store, (rh, rw)

    # ------------------------------------------------------------------ detection
    def detect_many(self, images):
        res = []
        for s in range(0, len(images), self.batch):
            chunk = images[s:s + self.batch]
            xs = [self._tensor(im)[0] for im in chunk]
            with torch.no_grad():
                out = self.model(xs)
            for k, im in enumerate(chunk):
                res.append(self._post(out["pred_logits"][k], out["pred_boxes"][k], *im.shape[:2]))
        return res

    # ------------------------------------------------------------------ readout (Eq. 17)
    def readout(self, image, union_box):
        H, W = image.shape[:2]
        _, st, (rh, rw) = self._forward(image, keep_grad=False)
        h, w = st["hw"]
        F = st["mem"][:, 0].reshape(h, w, -1).float().cpu().numpy()
        cw, ch = (rw / w) * W / rw, (rh / h) * H / rh                     # cell size in original pixels
        r0, r1, c0, c1, inside, extent = cells_for_region(union_box, 0.0, 0.0, cw, ch, w, h)
        return Readout(grid=F[r0:r1, c0:c1], extent=extent, inside=inside)

    # ------------------------------------------------------------------ gradients
    def gradient_map(self, image, targets, kind="odam"):
        H, W = image.shape[:2]
        out, st, _ = self._forward(image, keep_grad=True)
        prob = out["pred_logits"][0].softmax(-1)
        b = out["pred_boxes"][0].detach()
        xyxy = (torch.stack([b[:, 0] - b[:, 2] / 2, b[:, 1] - b[:, 3] / 2, b[:, 0] + b[:, 2] / 2, b[:, 1] + b[:, 3] / 2], 1)
                * torch.tensor([W, H, W, H], device=b.device)).cpu().numpy()
        total = None
        for t in targets:
            c = self.cls_index[t["cls"]]
            q = int(np.argmax(iou_many(xyxy, t["box"]) * prob[:, c].detach().cpu().numpy()))
            s = prob[q, c]
            if kind == "finercam":
                others = torch.cat([prob[q, :c], prob[q, c + 1:-1]])
                s = s - others.max()
            total = s if total is None else total * s
        total.backward()
        h, w = st["hw"]
        mem = st["mem"]
        grad = mem.grad[:, 0].reshape(h, w, -1).float()
        feat = mem.detach()[:, 0].reshape(h, w, -1).float()
        m = torch.relu((grad * feat).sum(-1)) if kind == "odam" else \
            torch.relu((grad.mean((0, 1))[None, None] * feat).sum(-1))
        self.model.zero_grad(set_to_none=True)
        return norm01(cv2.resize(m.cpu().numpy(), (W, H), interpolation=cv2.INTER_LINEAR))
