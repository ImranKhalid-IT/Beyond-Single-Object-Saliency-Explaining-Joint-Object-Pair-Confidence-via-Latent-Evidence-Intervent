"""Box geometry used throughout PIE (Eqs. 9-10, 30)."""
from __future__ import annotations

import numpy as np


def iou(a, b) -> float:
    """IoU of two xyxy boxes (Eq. 30)."""
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    area_a = (a[2] - a[0]) * (a[3] - a[1])
    area_b = (b[2] - b[0]) * (b[3] - b[1])
    return float(inter / (area_a + area_b - inter + 1e-8))


def iou_many(boxes: np.ndarray, b) -> np.ndarray:
    """IoU between every row of `boxes` (N x 4, xyxy) and one box `b`."""
    x1 = np.maximum(boxes[:, 0], b[0]); y1 = np.maximum(boxes[:, 1], b[1])
    x2 = np.minimum(boxes[:, 2], b[2]); y2 = np.minimum(boxes[:, 3], b[3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    area = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
    return inter / (area + (b[2] - b[0]) * (b[3] - b[1]) - inter + 1e-8)


def contact(a, b) -> float:
    """Intersection over the smaller box (1 = one box lies inside the other)."""
    iw = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    ih = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    small = min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1]))
    return float(iw * ih / (small + 1e-8))


def union_box(a, b) -> np.ndarray:
    """Smallest axis-aligned box enclosing both boxes (Eq. 9)."""
    return np.array([min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3])], np.float32)


def box_mask(b, width: int, height: int) -> np.ndarray:
    """Boolean pixel mask of a box, i.e. the region Omega_ij of Eq. 10 for the union box."""
    m = np.zeros((height, width), bool)
    x1, y1, x2, y2 = np.round(np.asarray(b, np.float64)).astype(int)
    m[max(0, y1):min(height, y2), max(0, x1):min(width, x2)] = True
    return m


def norm01(x) -> np.ndarray:
    x = np.asarray(x, np.float32)
    x = x - x.min()
    return x / (x.max() + 1e-8)
