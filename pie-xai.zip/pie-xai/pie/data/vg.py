"""Visual Genome pairs stratified by predicate annotation (Section IV-G, Tables 12-13).

Only objects whose names map to a COCO class are used, so that the COCO-trained detectors can
detect them. Annotated pairs carry a predicate from relationships.json; non-annotated pairs are
co-occurring objects without any relationship between them and with box IoU < max_iou.
Predicate labels are used only to stratify the pairs.
"""
from __future__ import annotations

import json
import shutil
import ssl
import urllib.request
from pathlib import Path

import numpy as np
from PIL import Image

from ..geometry import iou

ALIASES = {
    "person": ["person", "man", "woman", "boy", "girl", "child", "kid", "lady", "guy", "people", "player", "rider",
               "skier", "surfer", "skateboarder", "biker"],
    "bicycle": ["bicycle", "bike"], "car": ["car"], "motorcycle": ["motorcycle", "motorbike"],
    "horse": ["horse"], "dog": ["dog"], "laptop": ["laptop"], "cell phone": ["phone", "cellphone", "cell phone"],
    "traffic light": ["traffic light", "stoplight"], "cup": ["cup", "mug"], "frisbee": ["frisbee"],
    "skateboard": ["skateboard"], "surfboard": ["surfboard"], "umbrella": ["umbrella"], "chair": ["chair"],
    "bench": ["bench"], "tv": ["tv", "television"], "kite": ["kite"], "elephant": ["elephant"],
}
NAME2COCO = {a: c for c, al in ALIASES.items() for a in al}
CONTACT = {"holding", "riding", "on", "sitting on", "carrying", "wearing", "using", "has", "with", "eating",
           "standing on", "laying on", "lying on", "touching", "playing with", "walking"}
SPATIAL = {"next to", "behind", "near", "in front of", "beside", "above", "below", "under", "by"}


def _name(o):
    n = (o.get("names") or [o.get("name", "")])[0]
    return NAME2COCO.get(n.strip().lower())


def _box(o):
    return [o["x"], o["y"], o["x"] + o["w"], o["y"] + o["h"]]


class VGPairs:
    def __init__(self, root, n_annotated=600, n_plain=600, max_iou=0.1, min_side=24, seed=42):
        self.root = Path(root)
        meta = {m["image_id"]: m for m in json.load(open(self.root / "image_data.json"))}
        rels = json.load(open(self.root / "relationships.json"))
        rng = np.random.default_rng(seed)
        ann, plain = [], []
        for item in rels:
            iid = item["image_id"]
            related, objs = set(), {}
            for r in item["relationships"]:
                s, o = r["subject"], r["object"]
                cs, co = _name(s), _name(o)
                objs[s["object_id"]] = (s, cs); objs[o["object_id"]] = (o, co)
                related.add((s["object_id"], o["object_id"])); related.add((o["object_id"], s["object_id"]))
                if cs and co and cs != co and min(s["w"], s["h"], o["w"], o["h"]) >= min_side:
                    pred = r["predicate"].strip().lower()
                    ann.append(dict(image_id=iid, class_i=cs, class_j=co, gt_i=_box(s), gt_j=_box(o),
                                    predicate=pred, category="contact" if pred in CONTACT else
                                    "spatial" if pred in SPATIAL else "other", annotated=True))
            mapped = [(k, o, c) for k, (o, c) in objs.items() if c and min(o["w"], o["h"]) >= min_side]
            for x in range(len(mapped)):
                for y in range(x + 1, len(mapped)):
                    (ka, oa, ca), (kb, ob, cb) = mapped[x], mapped[y]
                    if ca == cb or (ka, kb) in related or iou(_box(oa), _box(ob)) >= max_iou:
                        continue
                    plain.append(dict(image_id=iid, class_i=ca, class_j=cb, gt_i=_box(oa), gt_j=_box(ob),
                                      predicate="", category="none", annotated=False))
        self.meta = meta
        self.pairs = [ann[i] for i in sorted(rng.permutation(len(ann))[:n_annotated])] + \
                     [plain[i] for i in sorted(rng.permutation(len(plain))[:n_plain])]

    def image(self, image_id):
        path = self.root / "images" / f"{image_id}.jpg"
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            with urllib.request.urlopen(self.meta[image_id]["url"], context=ssl.create_default_context()) as r, \
                    open(path, "wb") as f:
                shutil.copyfileobj(r, f)
        return np.asarray(Image.open(path).convert("RGB"))
