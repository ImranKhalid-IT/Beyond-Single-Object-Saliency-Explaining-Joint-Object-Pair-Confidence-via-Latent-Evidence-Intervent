"""MS-COCO 2017 pair construction (Table 3) and image loading."""
from __future__ import annotations

import shutil
import ssl
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

from ..geometry import contact

URLS = {"val2017": "http://images.cocodataset.org/zips/val2017.zip",
        "annotations": "http://images.cocodataset.org/annotations/annotations_trainval2017.zip"}


def _download(url, dst):
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(url, context=ctx) as r, open(dst, "wb") as f:
        shutil.copyfileobj(r, f)


def ensure_coco(root, need_val_images=True):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    ann = root / "annotations" / "instances_val2017.json"
    if not ann.exists():
        z = root / "annotations.zip"
        if not z.exists():
            print("downloading", URLS["annotations"]); _download(URLS["annotations"], z)
        zipfile.ZipFile(z).extractall(root)
    if need_val_images and not (root / "val2017").exists():
        z = root / "val2017.zip"
        if not z.exists():
            print("downloading", URLS["val2017"]); _download(URLS["val2017"], z)
        zipfile.ZipFile(z).extractall(root)
    return root


class CocoPairs:
    """All co-occurring instance pairs of the given class pairs.

    split      : "val2017" (evaluation, Table 3) or "train2017" (hyper-parameter selection,
                 images are fetched one by one from their coco_url, so the 18 GB zip is not needed)
    min_area   : ignore instances smaller than this (pixels^2)
    min_contact: optional, keep only pairs whose boxes overlap (intersection over smaller box)
    """

    def __init__(self, root, split="val2017", class_pairs=(("person", "bicycle"),), min_area=0.0,
                 min_contact=None, max_pairs_per_image=None, iscrowd=False):
        from pycocotools.coco import COCO
        self.root, self.split = Path(root), split
        self.coco = COCO(str(self.root / "annotations" / f"instances_{split}.json"))
        xy = lambda b: [b[0], b[1], b[0] + b[2], b[1] + b[3]]
        self.pairs = []
        for a, b in class_pairs:
            ca, cb = self.coco.getCatIds(catNms=[a])[0], self.coco.getCatIds(catNms=[b])[0]
            ids = sorted(set(self.coco.getImgIds(catIds=[ca])) & set(self.coco.getImgIds(catIds=[cb])))
            for iid in ids:
                A = [x for x in self.coco.loadAnns(self.coco.getAnnIds(imgIds=[iid], catIds=[ca], iscrowd=iscrowd))
                     if x["area"] >= min_area]
                B = [x for x in self.coco.loadAnns(self.coco.getAnnIds(imgIds=[iid], catIds=[cb], iscrowd=iscrowd))
                     if x["area"] >= min_area]
                rows = []
                for p in A:
                    for q in B:
                        c = contact(xy(p["bbox"]), xy(q["bbox"]))
                        if min_contact is not None and c < min_contact:
                            continue
                        rows.append(dict(image_id=iid, ann_i=p["id"], ann_j=q["id"], class_i=a, class_j=b,
                                         gt_i=xy(p["bbox"]), gt_j=xy(q["bbox"]), contact=round(c, 4)))
                rows.sort(key=lambda r: -r["contact"])
                self.pairs += rows[:max_pairs_per_image] if max_pairs_per_image else rows

    def sample(self, n, seed):
        rng = np.random.default_rng(seed)
        idx = rng.permutation(len(self.pairs))[:n]
        return [self.pairs[i] for i in sorted(idx)]

    def image(self, image_id):
        info = self.coco.loadImgs([image_id])[0]
        path = self.root / self.split / info["file_name"]
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            _download(info["coco_url"], path)
        return np.asarray(Image.open(path).convert("RGB"))


def pair_key(row):
    return f'{row["image_id"]}_{row.get("ann_i", "")}_{row.get("ann_j", "")}_{row["class_i"]}_{row["class_j"]}'
