"""Baselines and controls, all evaluated with the same pair-level protocol.

Object-wise methods (Grad-CAM, ODAM, Finer-CAM, D-RISE, CRAFT-adapted) explain d_i and d_j
separately and are merged with Eq. 2. Gradient methods live in the detector adapters
(`detector.gradient_map`), because they need the detector's internals.
"""
from __future__ import annotations

import cv2
import numpy as np
from sklearn.decomposition import NMF

from .geometry import box_mask, iou, norm01
from .intervention import gaussian_blur
from .units import grid_to_pixels


# ----------------------------------------------------------------------------- D-RISE (Eq. 5)
def drise(detector, img, targets, n_masks=1000, grid=16, p=0.5, rng=None, mean_center=True, batch=64):
    """D-RISE saliency for each target detection.

    Weight of a mask = max over same-class detections of IoU * score. With `mean_center`, the
    weights are centred before accumulation, which removes the uniform bias of Eq. 5.
    """
    rng = np.random.default_rng(0) if rng is None else rng
    H, W = img.shape[:2]
    cell = np.ceil(np.array([H, W]) / grid).astype(int)
    up = (grid + 1) * cell
    ws = [[] for _ in targets]
    masks = []
    for s in range(0, n_masks, batch):
        ms = []
        for _ in range(min(batch, n_masks - s)):
            g = (rng.random((grid, grid)) < p).astype(np.float32)
            m = cv2.resize(g, (int(up[1]), int(up[0])), interpolation=cv2.INTER_LINEAR)
            oy, ox = rng.integers(0, cell[0]), rng.integers(0, cell[1])
            ms.append(m[oy:oy + H, ox:ox + W])
        res = detector.detect_many([(img * m[..., None]).astype(np.uint8) for m in ms])
        for m, r in zip(ms, res):
            for t, tgt in enumerate(targets):
                ws[t].append(max([iou(d["box"], tgt["box"]) * d["score"] for d in r if d["cls"] == tgt["cls"]] or [0.0]))
            masks.append(m.astype(np.float16))
    sal = []
    for t in range(len(targets)):
        w = np.asarray(ws[t], np.float32)
        if mean_center:
            w = w - w.mean()
        acc = np.zeros((H, W), np.float32)
        for wi, m in zip(w, masks):
            acc += wi * m.astype(np.float32)
        sal.append(norm01(np.maximum(acc, 0)))
    return sal


# ----------------------------------------------------------------------------- CRAFT-adapted
def craft_adapted(detector, img, readout, union, target, n_concepts=8, n_sobol=16, sigma=15, theta_m=0.5,
                  rng=None, seed=42):
    """CRAFT adapted to one detection inside Omega_ij.

    1. Concepts: NMF of the non-negative union-region features, A ~ U W^T (Eq. 6).
    2. Importance: Sobol total indices (Jansen estimator) of the concept coefficients on the
       target score s_r. Concepts are perturbed in pixel space: a pixel keeps the fraction
       kappa = sum_k x_k C~_k(x, y) of the image and takes the rest from I_blur.
    3. Relevance map: sum_k S_T,k C~_k.
    Uses n_sobol * (n_concepts + 2) forward passes.
    """
    rng = np.random.default_rng(seed) if rng is None else rng
    H, W = img.shape[:2]
    G = np.maximum(readout.grid.astype(np.float32), 0)
    gh, gw, C = G.shape
    k = min(n_concepts, max(1, int(readout.inside.sum()) - 1))
    nmf = NMF(n_components=k, init="nndsvda", random_state=seed, max_iter=400)
    coef = nmf.fit_transform(G.reshape(-1, C)).reshape(gh, gw, k)
    omega = box_mask(union, W, H)
    cmaps = np.stack([np.where(omega, grid_to_pixels(coef[..., q], readout.extent, W, H), 0) for q in range(k)])
    cmaps = cmaps / np.maximum(cmaps.sum(0, keepdims=True), 1e-8)            # partition of Omega
    blur = gaussian_blur(img, sigma)

    def render(x):
        kappa = np.where(omega, np.tensordot(x, cmaps, axes=1), 1.0)[..., None]
        return (kappa * img + (1 - kappa) * blur).astype(np.uint8)

    A = rng.random((n_sobol, k)); B = rng.random((n_sobol, k))
    designs = [A, B] + [np.where(np.arange(k)[None] == q, B, A) for q in range(k)]
    imgs = [render(x) for D in designs for x in D]
    res = detector.detect_many(imgs)
    f = np.array([max([d["score"] for d in r if d["cls"] == target["cls"] and iou(d["box"], target["box"]) >= theta_m]
                      or [0.0]) for r in res]).reshape(len(designs), n_sobol)
    fA, fB = f[0], f[1]
    var = np.var(np.concatenate([fA, fB])) + 1e-12
    st = np.array([0.5 * np.mean((fA - f[2 + q]) ** 2) / var for q in range(k)])  # Jansen total index
    return norm01(np.tensordot(st, cmaps, axes=1)), st


# ----------------------------------------------------------------------------- spatial controls
def random_partition(omega, K, rng):
    """K random Voronoi regions of Omega_ij, ranked in random order ("random spatial masking")."""
    ys, xs = np.nonzero(omega)
    seeds = rng.choice(len(ys), size=K, replace=False)
    d = (ys[:, None] - ys[seeds][None]) ** 2 + (xs[:, None] - xs[seeds][None]) ** 2
    lab = d.argmin(1)
    masks = np.zeros((K,) + omega.shape, bool)
    masks[lab, ys, xs] = True
    return masks, rng.permutation(K).astype(np.float32)


def grid_partition(union, omega, n=8):
    """PC-Grid: b_ij divided into n x n cells."""
    x0, y0, x1, y1 = union
    xs = np.linspace(x0, x1, n + 1); ys = np.linspace(y0, y1, n + 1)
    H, W = omega.shape
    masks = []
    for r in range(n):
        for c in range(n):
            m = box_mask((xs[c], ys[r], xs[c + 1], ys[r + 1]), W, H) & omega
            if m.any():
                masks.append(m)
    return np.stack(masks)


def restrict(rel, omega):
    return np.where(omega, rel, 0.0).astype(np.float32)
