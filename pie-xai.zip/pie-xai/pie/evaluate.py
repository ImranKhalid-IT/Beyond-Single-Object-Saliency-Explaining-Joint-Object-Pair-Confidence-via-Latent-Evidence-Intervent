"""One-pair evaluation: PIE, its ablations, the spatial controls and the baselines under the
shared pair-level deletion/insertion protocol (Section IV)."""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
from scipy import stats

from . import baselines as B
from .geometry import box_mask, union_box
from .intervention import explain_pair, explain_partition, gaussian_blur
from .matching import pick_target
from .metrics import deletion_insertion, map_pixel_order, merge_object_maps, unit_pixel_order
from .units import discover_units

UNIT_METHODS = ("pie", "first_order", "activation")
ALL_METHODS = ("pie", "first_order", "activation", "random", "pcgrid", "pair_union",
               "gradcam", "odam", "finercam", "drise", "craft")


def _sync():
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.synchronize()
    except ImportError:
        pass


class Timer:
    def __enter__(self):
        _sync(); self.t = time.perf_counter(); return self

    def __exit__(self, *a):
        _sync(); self.dt = time.perf_counter() - self.t


def targets_for(detector, img, row):
    dets = detector.detect(img)
    di = pick_target(dets, row["class_i"], row["gt_i"])
    dj = pick_target(dets, row["class_j"], row["gt_j"])
    return di, dj


def evaluate_pair(detector, img, row, cfg, methods=ALL_METHODS, external_dir=None, keep=False):
    """Returns (record, artifacts). record is None with a reason string when the pair is skipped."""
    di, dj = targets_for(detector, img, row)
    if di is None or dj is None:
        return None, "target not detected"
    H, W = img.shape[:2]
    rng = np.random.default_rng(cfg["seed"])
    fr = np.linspace(0, 1, cfg["n_fractions"])
    blur = gaussian_blur(img, cfg["sigma"])
    rec = dict(row, detector=detector.name, s_i=di["score"], s_j=dj["score"], S_ij=di["score"] * dj["score"])

    def score_order(name, order):
        rec[f"morf_{name}"], rec[f"ins_{name}"], _, _ = deletion_insertion(
            detector, img, P.omega, order, di, dj, fr, cfg["sigma"], cfg["theta_m"], blur)

    with Timer() as t:
        P = explain_pair(detector, img, di, dj, cfg)
    if P is None:
        return None, "union too small for K units"
    rec["time_pie"] = t.dt
    rec.update(union_frac=float(P.omega.mean()), n_forward_pie=P.n_forward,
               ce=P.ce.round(5).tolist(), fo=P.fo.round(5).tolist(), cross=P.cross.round(5).tolist(),
               post_i=P.post[:, 0].round(5).tolist(), post_j=P.post[:, 1].round(5).tolist(),
               ce_max=float(P.ce.max()))
    tb = P.post.sum(1)
    if "pie" in methods:
        score_order("pie", unit_pixel_order(P.ce, P.maps, P.masks, P.omega, tb))
    if "first_order" in methods:
        score_order("first_order", unit_pixel_order(P.fo, P.maps, P.masks, P.omega, tb))
        rec["kendall_ce_fo"] = float(stats.kendalltau(P.ce, P.fo)[0])
    if "activation" in methods:
        score_order("activation", unit_pixel_order(P.activation, P.maps, P.masks, P.omega))
    if "random" in methods:
        masks, sc = B.random_partition(P.omega, len(P.ce), rng)
        score_order("random", unit_pixel_order(sc, masks.astype(np.float32), masks, P.omega))
    if "pcgrid" in methods:
        with Timer() as t:
            masks = B.grid_partition(P.union, P.omega, cfg["pcgrid_n"])
            G = explain_partition(detector, img, di, dj, masks, P.omega, cfg)
        rec["time_pcgrid"] = t.dt
        score_order("pcgrid", unit_pixel_order(G.ce, G.maps, G.masks, P.omega, G.post.sum(1)))

    maps = {}
    for kind in ("gradcam", "odam", "finercam"):
        if kind in methods and not (kind == "finercam" and detector.name in cfg.get("finercam_skip", [])):
            with Timer() as t:
                ri = detector.gradient_map(img, [di], kind); rj = detector.gradient_map(img, [dj], kind)
            maps[kind] = (ri, rj); rec[f"time_{kind}"] = t.dt
            score_order(kind, map_pixel_order(merge_object_maps(ri, rj), P.omega))
    if "pair_union" in methods:
        with Timer() as t:
            r = detector.gradient_map(img, [di, dj], "gradcam")       # gradient of s_i * s_j
        rec["time_pair_union"] = t.dt
        score_order("pair_union", map_pixel_order(B.restrict(r, P.omega), P.omega))
    if "drise" in methods:
        with Timer() as t:
            ri, rj = B.drise(detector, img, [di, dj], cfg["drise"]["n_masks"], cfg["drise"]["grid"],
                             cfg["drise"]["p"], rng, cfg["drise"]["mean_center"], cfg.get("batch", 32))
        maps["drise"] = (ri, rj); rec["time_drise"] = t.dt
        score_order("drise", map_pixel_order(merge_object_maps(ri, rj), P.omega))
    if "craft" in methods:
        with Timer() as t:
            ro = detector.readout(img, P.union)
            ri, _ = B.craft_adapted(detector, img, ro, P.union, di, cfg["craft"]["n_concepts"],
                                    cfg["craft"]["n_sobol"], cfg["sigma"], cfg["theta_m"], seed=cfg["seed"])
            rj, _ = B.craft_adapted(detector, img, ro, P.union, dj, cfg["craft"]["n_concepts"],
                                    cfg["craft"]["n_sobol"], cfg["sigma"], cfg["theta_m"], seed=cfg["seed"])
        maps["craft"] = (ri, rj); rec["time_craft"] = t.dt
        score_order("craft", map_pixel_order(merge_object_maps(ri, rj), P.omega))
    if external_dir:                                   # e.g. GCE / CoE maps produced by their own code
        for d in Path(external_dir).iterdir():
            f = d / f'{rec["detector"]}_{row["image_id"]}_{row["class_i"]}_{row["class_j"]}.npz'
            if f.exists():
                z = np.load(f)
                rel = merge_object_maps(z["ri"], z["rj"]) if "ri" in z else z["r"]
                score_order(f"ext_{d.name}", map_pixel_order(rel, P.omega))
    return rec, (dict(P=P, di=di, dj=dj, maps=maps) if keep else None)


# ----------------------------------------------------------------------------- variants
def pie_variant_morf(detector, img, di, dj, cfg, units=None, replacement="gaussian"):
    """MoRF/insertion of PIE for one configuration; the metric always uses the default Gaussian."""
    P = explain_pair(detector, img, di, dj, cfg, replacement=replacement, units=units)
    if P is None:
        return None
    fr = np.linspace(0, 1, cfg["n_fractions"])
    order = unit_pixel_order(P.ce, P.maps, P.masks, P.omega, P.post.sum(1))
    m, i, _, _ = deletion_insertion(detector, img, P.omega, order, di, dj, fr, cfg["metric_sigma"], cfg["theta_m"])
    return P, m, i


def units_for(detector, img, di, dj, cfg, K=None):
    H, W = img.shape[:2]
    U = union_box(di["box"], dj["box"])
    return discover_units(detector.readout(img, U), U, W, H, K or cfg["K"], cfg["tau_s"], seed=cfg["seed"],
                          n_init=cfg.get("kmeans_n_init", 10))
