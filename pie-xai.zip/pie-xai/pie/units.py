"""Image-specific latent evidence units (Section III-C, Eqs. 19-24, Algorithm 2)."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
from sklearn.cluster import KMeans

from .geometry import box_mask


@dataclass
class Readout:
    """Located union-region features (Eq. 18) on a regular grid.

    grid    : (gh, gw, C) feature vectors v_m, one per located cell
    extent  : (x0, y0, x1, y1) image-coordinate rectangle covered by the grid cells
    inside  : (gh, gw) bool, True for cells whose centre lies in Omega_ij (Eq. 14); these
              cells define the prototypes. The other cells only border Omega_ij and are used
              so that every pixel of Omega_ij receives a map value.
    """
    grid: np.ndarray
    extent: tuple
    inside: np.ndarray


def grid_to_pixels(fmap: np.ndarray, extent, width: int, height: int) -> np.ndarray:
    """Bilinear resampling R(.) of a (gh, gw) grid map to the image (Eq. 24)."""
    x0, y0, x1, y1 = [int(round(v)) for v in extent]
    x0c, y0c, x1c, y1c = max(x0, 0), max(y0, 0), min(x1, width), min(y1, height)
    out = np.zeros((height, width), np.float32)
    if x1 <= x0 or y1 <= y0:
        return out
    up = cv2.resize(np.ascontiguousarray(fmap, np.float32), (x1 - x0, y1 - y0), interpolation=cv2.INTER_LINEAR)
    out[y0c:y1c, x0c:x1c] = up[y0c - y0:y1c - y0, x0c - x0:x1c - x0]
    return out


def discover_units(readout: Readout, union, width: int, height: int, K: int, tau_s: float,
                   seed: int = 42, n_init: int = 10, l2_normalise: bool = True):
    """K-Means prototypes (Eqs. 19-20), softmax unit maps (Eqs. 21-23), pixel maps (Eq. 24).

    Features are L2-normalised before clustering, so the squared distances in Eq. 21 lie in
    [0, 4] and tau_s = 0.05 gives graded rather than binary maps.

    Returns dict with
      maps       (K, H, W) float32, zero outside Omega_ij
      omega      (H, W) bool
      activation (K,) mean raw feature norm of the cells assigned to each unit
      labels     (gh, gw) hard assignment (for inspection)
    or None when Omega_ij contains fewer than K located cells.
    """
    G = readout.grid.astype(np.float32)
    gh, gw, C = G.shape
    raw_norm = np.linalg.norm(G, axis=2)
    Gn = G / np.maximum(raw_norm[..., None], 1e-6) if l2_normalise else G
    V = Gn[readout.inside]
    if V.shape[0] < K:
        return None
    km = KMeans(n_clusters=K, random_state=seed, n_init=n_init).fit(V)
    mu = km.cluster_centers_.astype(np.float32)
    if l2_normalise:
        mu = mu / np.maximum(np.linalg.norm(mu, axis=1, keepdims=True), 1e-6)
    flat = Gn.reshape(-1, C)
    d2 = (flat ** 2).sum(1, keepdims=True) - 2 * flat @ mu.T + (mu ** 2).sum(1)[None]      # Eq. 21
    logits = -np.maximum(d2, 0) / tau_s
    logits -= logits.max(1, keepdims=True)
    U = np.exp(logits); U /= U.sum(1, keepdims=True)                                       # Eq. 22
    U = U.reshape(gh, gw, K)
    omega = box_mask(union, width, height)
    maps = np.stack([np.where(omega, grid_to_pixels(U[..., k], readout.extent, width, height), 0.0)
                     for k in range(K)]).astype(np.float32)
    labels = U.argmax(2)
    act = np.array([raw_norm[readout.inside & (labels == k)].mean() if np.any(readout.inside & (labels == k)) else 0.0
                    for k in range(K)], np.float32)
    return dict(maps=maps, omega=omega, activation=act, labels=labels)
