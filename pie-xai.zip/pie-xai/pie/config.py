from __future__ import annotations

import copy
import os
import random

import numpy as np
import yaml


def load_config(path, overrides=None):
    with open(path) as f:
        cfg = yaml.safe_load(f)
    for item in overrides or []:                     # key=value or a.b=value
        k, v = item.split("=", 1)
        d = cfg
        *parents, last = k.split(".")
        for p in parents:
            d = d[p]
        d[last] = yaml.safe_load(v)
    return cfg


def with_overrides(cfg, **kv):
    c = copy.deepcopy(cfg)
    c.update(kv)
    return c


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass
