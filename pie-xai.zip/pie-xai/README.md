# PIE: Pair-level Interventional Explanation

Code for **"Beyond Single-Object Saliency: Explaining Joint Object-Pair Confidence via Latent Evidence
Interventions"** (IEEE Access).

PIE explains the *joint confidence* `S_ij = s_i * s_j` of two detections of a frozen object detector.
Union-region features are grouped into `K` image-specific latent evidence units; each unit is replaced
by a blurred baseline, the detector is re-run, the two targets are recovered by one-to-one same-class
IoU matching, and the units are ranked by the measured drop `CE_k = S_ij - s'_i s'_j`.
PIE explains detector confidence, not predicate (relationship) predictions.

```
pie/
  geometry.py        boxes, union region (Eqs. 9-10)
  units.py           latent evidence units: K-Means, softmax maps, resampling (Eqs. 19-24)
  intervention.py    masks, replacement, re-detection, CE_k / FO_k / cross term (Eqs. 25-37)
  matching.py        pair-preserving matching (Eqs. 30-33, Alg. 4)
  metrics.py         pair-level MoRF deletion and insertion (Eqs. 38-42)
  baselines.py       D-RISE, CRAFT-adapted, random and PC-Grid controls
  evaluate.py        one-pair evaluation of all methods
  detectors/         YOLOv5x (grid), Faster R-CNN R101-FPN (ROI-Align), DETR-DC5 (encoder tokens)
  data/              MS-COCO pairs (Table 3), Visual Genome pairs (Tables 12-13)
scripts/
  run_eval.py        all experiments, one JSON line per pair, resumable and shardable
  make_tables.py     LaTeX/CSV tables + bootstrap CIs + Wilcoxon/Holm
  make_figures.py    qualitative figure (Fig. 15), comparison figure (Fig. 16), charts
tests/               unit tests and a GPU-free mock detector that runs the whole pipeline
configs/default.yaml every hyper-parameter of the paper (Tables 4-5)
```

## 1. Installation

```bash
conda create -n pie python=3.10 -y && conda activate pie
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121   # match your CUDA
pip install -r requirements.txt
pip install 'git+https://github.com/facebookresearch/detectron2.git'               # Faster R-CNN only
python -m pytest -q tests                                                          # 11 tests, CPU, ~3 s
```

YOLOv5x and DETR-DC5 are loaded through `torch.hub` (`ultralytics/yolov5`, `facebookresearch/detr`);
Faster R-CNN uses the Detectron2 model-zoo checkpoint `faster_rcnn_R_101_FPN_3x` (`model_final_f6e8b1.pkl`).

## 2. Data

* **MS-COCO 2017**: `val2017` images and annotations are downloaded automatically to `data/coco`.
  The 500 hyper-parameter pairs come from `train2017`; only those images are fetched (by `coco_url`).
* **Visual Genome 1.4**: put `image_data.json` and `relationships.json` in `data/vg`; images are fetched
  on demand from the URLs in `image_data.json`.

## 3. Reproducing the paper

| Paper item | Command |
|---|---|
| Table 6 (hyper-parameter selection, train2017) | `python scripts/run_eval.py --detector yolov5 --experiment hparam` (repeat per detector) |
| Tables 3, 7, 8, 9, 11; Figs. 9, 11 | `python scripts/run_eval.py --detector {yolov5,faster_rcnn,detr} --experiment main` |
| Fig. 12 / 13(c) (sensitivity) | `python scripts/run_eval.py --detector yolov5 --experiment sensitivity --max-pairs 500` |
| Table 10 (replacement operators) | `python scripts/run_eval.py --detector yolov5 --experiment replacement --max-pairs 500` |
| Tables 12-13 (Visual Genome) | `python scripts/run_eval.py --detector yolov5 --experiment main --dataset vg --methods pie odam` |
| all tables | `python scripts/make_tables.py` → `results/tables/*.tex`, `*.csv`, `SUMMARY.md` |
| Fig. 15 (qualitative) | `python scripts/make_figures.py qualitative --detector yolov5` |
| Fig. 16 (method comparison) | `python scripts/make_figures.py comparison --detector yolov5 --image-id 367095 --classes person laptop` |
| Figs. 9, 11, 12 (charts) | `python scripts/make_figures.py charts` |

`bash reproduce.sh` runs everything in order. Every run writes `config_used.json` next to its results.

**Runtime.** Per pair, PIE needs K+1 = 9 forward passes. The full `main` experiment is dominated by the
baselines (D-RISE with 1000 masks per object, CRAFT-adapted with 160 passes per object) and by the
42 metric evaluations per method. Use `--shard i --num-shards n` to split a run over several GPUs or
sessions (runs resume automatically), or evaluate D-RISE on a subset:
`--methods pie first_order activation random pcgrid pair_union gradcam odam finercam craft` on all pairs and
`--methods drise --max-pairs 500` separately.

**Determinism.** Seeds are fixed (`seed: 42`), K-Means uses `random_state=seed`, cuDNN runs in deterministic
mode, and D-RISE / random controls use seeded generators. Skipped pairs are logged with the reason in
`*.skipped.jsonl`; nothing is dropped silently.

## 4. Implementation details that the paper should state

* **Feature normalisation.** Located features and prototypes are L2-normalised before Eqs. 19-22, so the
  squared distances lie in [0, 4] and `tau_s = 0.05` gives graded rather than binary maps.
* **Mask area.** `M_k` keeps exactly the top 15 % of Omega_ij pixels of each map (ties in raster order),
  which equals the 85th-percentile rule of Eq. 25 when values are distinct.
* **Grid coverage.** Prototypes use the cells whose centres lie in Omega_ij (Eq. 14); unit maps are also
  evaluated on the bordering cells so that every pixel of Omega_ij receives a value (Eq. 23).
* **Ties in the ranking.** Units with equal `CE_k` (typically `CE_k = S_ij` when a target is lost) are ordered
  by the lower remaining score `s'_i + s'_j`.
* **DETR** is a set predictor, so no NMS is applied to it; the NMS threshold applies to YOLOv5 and Faster R-CNN.
* **Faster R-CNN gradients** are taken through the ROI head on the fixed detected box, at the FPN levels
  that receive gradient.

### Baselines and controls (Table 9 definitions)

| Name in tables | Definition in this code |
|---|---|
| Detector baseline | per-object Grad-CAM of the detector, merged with Eq. 2, no pair context |
| Random spatial masking | Omega_ij split into K random Voronoi regions, ranked in random order |
| Pair-union attribution | Grad-CAM of the joint score `s_i s_j`, restricted to Omega_ij |
| PC-Grid | b_ij split into 8 x 8 cells, each cell intervened on and ranked by CE |
| Activation-ranked | PIE units ranked by the mean raw feature norm of their cells |
| First-order-ranked | PIE units ranked by `FO_k = -(s_j Δs_i + s_i Δs_j)` |
| ODAM / Grad-CAM / Finer-CAM | instance-specific gradients of the matched prediction; Finer-CAM contrasts the target class with the most similar other class |
| D-RISE | 16 x 16 random masks, p = 0.5, weight = IoU x score of the best same-class detection, mean-centred weights |
| CRAFT-adapted | NMF concepts of the union-region features; importance = Sobol total index (Jansen) of the concept coefficients on `s_r`, perturbing concepts in pixel space |

**GCE and CoE** depend on their own pipelines (a global concept dictionary and language-described concept
circuits). Export their per-object maps as `external/<method>/<detector>_<image_id>_<class_i>_<class_j>.npz`
with arrays `ri`, `rj` (or one pair map `r`) and pass `--external-dir external`; they are then scored with
exactly the same metric.

Failure categories (Fig. 18) require manual inspection of explanations and are not automated here.

## 5. Results

Numbers in the paper must be the ones produced by `make_tables.py` from these runs. The tables are written
as LaTeX (`results/tables/*.tex`) and can be pasted into the manuscript; 95 % bootstrap intervals and paired
tests are in `morf_bootstrap_ci.csv` and `significance.csv`.

## Citation

```bibtex
@article{khalid2026pie,
  title   = {Beyond Single-Object Saliency: Explaining Joint Object-Pair Confidence via Latent Evidence Interventions},
  author  = {Khalid, Muhammad Imran and Mi, Jian-Xun and Frnda, Jaroslav and Khan, Inayat and Khan, Jawad},
  journal = {IEEE Access},
  year    = {2026}
}
```

## License

MIT (see `LICENSE`). MS-COCO, Visual Genome, YOLOv5 (AGPL-3.0), Detectron2 (Apache-2.0) and DETR
(Apache-2.0) keep their own licenses.
