#!/usr/bin/env python
"""Aggregate the JSONL results into the tables of the paper (LaTeX + CSV).

  python scripts/make_tables.py --results results --out results/tables

Every number is a mean over evaluated pairs; 95 % bootstrap confidence intervals and paired
Wilcoxon tests (Holm-corrected) are written to the CSV files for the supplementary material.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

DET = {"yolov5": "YOLOv5", "faster_rcnn": "Faster R-CNN", "detr": "DETR"}
NAMES = {"pie": "PIE (Ours)", "first_order": "Latent units, first-order-ranked",
         "activation": "Latent units, activation-ranked", "random": "Random spatial masking",
         "pcgrid": "PC-Grid ($8\\times8$ cells)", "pair_union": "Pair-union attribution",
         "gradcam": "Grad-CAM (detector baseline)", "odam": "ODAM", "finercam": "Finer-CAM",
         "drise": "D-RISE", "craft": "CRAFT-adapted"}


def load(folder):
    rows = []
    for f in sorted(Path(folder).glob("*.jsonl")):
        if f.name.endswith(".skipped.jsonl"):
            continue
        rows += [json.loads(l) for l in open(f)]
    return pd.DataFrame(rows)


def skipped(folder):
    rows = []
    for f in sorted(Path(folder).glob("*.skipped.jsonl")):
        rows += [json.loads(l) for l in open(f)]
    return pd.DataFrame(rows)


def md(df):
    try:
        return df.to_markdown()
    except ImportError:
        return "```\n" + df.to_string() + "\n```"


def boot_ci(x, n=5000, seed=42):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    if len(x) == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    m = x[rng.integers(0, len(x), (n, len(x)))].mean(1)
    return tuple(np.percentile(m, [2.5, 97.5]))


def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); adj = np.empty(len(p)); run = 0
    for r, i in enumerate(o):
        run = max(run, (len(p) - r) * p[i]); adj[i] = min(1, run)
    return adj


def latex(df, caption, label, fmt="{:.2f}"):
    cols = list(df.columns)
    lines = ["\\begin{table}[!t]", f"\\caption{{{caption}}}", f"\\label{{{label}}}", "\\centering",
             "\\resizebox{\\linewidth}{!}{%", "\\begin{tabular}{|l|" + "c|" * len(cols) + "}", "\\hline",
             "\\textbf{" + df.index.name + "} & " + " & ".join(f"\\textbf{{{c}}}" for c in cols) + " \\\\", "\\hline"]
    for idx, r in df.iterrows():
        cells = ["--" if pd.isna(v) else (fmt.format(v) if isinstance(v, (float, np.floating)) else str(v)) for v in r]
        lines += [f"{idx} & " + " & ".join(cells) + " \\\\", "\\hline"]
    lines += ["\\end{tabular}%", "}", "\\end{table}"]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="results/tables")
    a = ap.parse_args()
    R, out = Path(a.results), Path(a.out); out.mkdir(parents=True, exist_ok=True)
    report = []

    # ---------------------------------------------------------------- main COCO
    df = load(R / "main" / "coco")
    if len(df):
        sk = skipped(R / "main" / "coco")
        t3 = df.groupby([df.class_i + " + " + df.class_j, "detector"]).size().unstack().rename(columns=DET)
        t3.index.name = "Class pair"
        (out / "table3_pairs.tex").write_text(latex(t3, "Evaluated co-occurring pairs (MS-COCO val2017).",
                                                    "tab:dataset_stats", "{:.0f}"))
        if len(sk):
            sk.groupby(["detector", "reason"]).size().to_csv(out / "table3_skipped.csv")
        methods = [c[5:] for c in df.columns if c.startswith("morf_")]
        t7 = df.groupby("detector")[[f"morf_{m}" for m in methods]].mean().T
        t7.index = [NAMES.get(m, m) for m in methods]; t7 = t7.rename(columns=DET)
        t7["Mean"] = t7.mean(axis=1); t7.index.name = "Method"
        t7 = t7.sort_values("Mean", ascending=False)
        (out / "table7_morf.tex").write_text(latex(t7, "MoRF-AUC ($\\downarrow$) under the shared pair-level deletion protocol.",
                                                   "tab:faithfulness"))
        t7.to_csv(out / "table7_morf.csv")
        if {"morf_first_order", "ins_pie"} <= set(df.columns):
            t8 = df.groupby("detector")[["morf_pie", "morf_first_order", "ins_pie", "ins_first_order"]].mean()
            t8.loc["mean"] = t8.mean(); t8 = t8.rename(index=DET | {"mean": "Mean"})
            t8.columns = ["PIE MoRF", "First-order MoRF", "PIE Insertion", "First-order Insertion"]
            t8.index.name = "Detector"
            (out / "table8_insertion.tex").write_text(latex(t8, "Deletion and insertion AUC of effect-based and first-order ranking.",
                                                            "tab:insertion"))
        abl = [m for m in ["gradcam", "random", "pair_union", "pcgrid", "activation", "first_order", "pie"] if m in methods]
        t9 = pd.DataFrame({"MoRF-AUC": [df[f"morf_{m}"].mean() for m in abl]}, index=[NAMES[m] for m in abl])
        t9.index.name = "Variant"
        (out / "table9_ablation.tex").write_text(latex(t9, "Ablation and spatial controls (mean over detectors).",
                                                       "tab:ablation"))
        tcols = [c for c in df.columns if c.startswith("time_")]
        t11 = df.groupby("detector")[tcols].mean().T.rename(columns=DET)
        t11.index = [NAMES.get(c[5:], c[5:]) for c in tcols]; t11.index.name = "Method"
        (out / "table11_time.tex").write_text(latex(t11, "Explanation time per pair (seconds).", "tab:efficiency"))
        # statistics
        tests, cis = [], []
        for det_name, g in df.groupby("detector"):
            for m in methods:
                lo, hi = boot_ci(g[f"morf_{m}"]); cis.append(dict(detector=det_name, method=m, mean=g[f"morf_{m}"].mean(),
                                                                  ci_low=lo, ci_high=hi, n=g[f"morf_{m}"].notna().sum()))
                if m == "pie":
                    continue
                ok = g["morf_pie"].notna() & g[f"morf_{m}"].notna()
                d = (g[f"morf_{m}"] - g["morf_pie"])[ok]
                p = 1.0 if len(d) < 2 or np.allclose(d, 0) else stats.wilcoxon(g["morf_pie"][ok], g[f"morf_{m}"][ok]).pvalue
                tests.append(dict(detector=det_name, comparison=f"PIE vs {m}", mean_gain=d.mean(),
                                  pie_better_on=float((d > 0).mean()), p=p))
        t = pd.DataFrame(tests)
        if len(t):
            t["p_holm"] = holm(t["p"]); t.to_csv(out / "significance.csv", index=False)
        pd.DataFrame(cis).to_csv(out / "morf_bootstrap_ci.csv", index=False)
        report.append("## Table 7 (MoRF-AUC)\n" + t7.round(3).pipe(md))
        if "ce_max" in df:
            df[["detector", "ce_max", "S_ij"]].to_csv(out / "fig_ce_distribution_source.csv", index=False)
            ce_all = [(r.detector, v) for r in df.itertuples() for v in r.ce]
            pd.DataFrame(ce_all, columns=["detector", "CE_k"]).to_csv(out / "fig11_ce_values.csv", index=False)

    # ---------------------------------------------------------------- hparam / sensitivity
    for exp, label in (("hparam", "tab:hyperparameter_sensitivity"), ("sensitivity", "fig:hyperparameter-sensitivity")):
        d = load(R / exp / "coco")
        if len(d):
            cols = [c for c in d.columns if c.startswith("morf_")]
            t = d.groupby("detector")[cols].mean().T.rename(columns=DET)
            t["Mean"] = t.mean(axis=1); t.index = [c[5:] for c in cols]; t.index.name = "Setting"
            (out / f"{exp}.tex").write_text(latex(t, f"{exp} (MoRF-AUC, lower is better).", label, "{:.3f}"))
            t.to_csv(out / f"{exp}.csv"); report.append(f"## {exp}\n" + t.round(3).pipe(md))

    # ---------------------------------------------------------------- replacement (Table 10)
    d = load(R / "replacement" / "coco")
    if len(d):
        ops = [c[5:] for c in d.columns if c.startswith("morf_")]
        t10 = pd.DataFrame({"MoRF-AUC": [d[f"morf_{o}"].mean() for o in ops],
                            "Spearman rho": [d[f"spearman_{o}"].mean() for o in ops],
                            "Latency (s)": [d[f"time_{o}"].mean() for o in ops]}, index=ops)
        t10.index.name = "Replacement"
        (out / "table10_replacement.tex").write_text(latex(t10, "Ranking stability under alternative replacement operators.",
                                                           "tab:intervention_robustness", "{:.3f}"))
        report.append("## Table 10\n" + t10.round(3).pipe(md))

    # ---------------------------------------------------------------- Visual Genome (Tables 12-13)
    d = load(R / "main" / "vg")
    if len(d):
        rows = {p: d.loc[d.predicate == p, "morf_pie"].mean() for p in ["holding", "riding", "next to", "behind"]}
        t12 = pd.DataFrame({"PIE MoRF-AUC": list(rows.values()) + [d["morf_pie"].mean()],
                            "ODAM MoRF-AUC": [d.loc[d.predicate == p, "morf_odam"].mean() if "morf_odam" in d else np.nan
                                              for p in rows] + [d["morf_odam"].mean() if "morf_odam" in d else np.nan]},
                           index=list(rows) + [f"All {len(d)} pairs"])
        t12.index.name = "Predicate"
        (out / "table12_vg_predicates.tex").write_text(latex(t12, "MoRF-AUC for predicate categories (Visual Genome).",
                                                             "tab:per_relation"))
        t13 = d.groupby("annotated")["ce_max"].agg(["count", "mean", "std"])
        t13.index = ["Non-annotated" if not i else "Predicate-annotated" for i in t13.index]
        t13.columns = ["Pairs", "Mean CE_max", "s.d."]; t13.index.name = "Pair group"
        (out / "table13_vg_cemax.tex").write_text(latex(t13, "Largest confidence effect per pair (Visual Genome).",
                                                        "tab:negative_pairs", "{:.3f}"))
        report += ["## Table 12\n" + t12.round(3).pipe(md), "## Table 13\n" + t13.round(3).pipe(md)]

    (out / "SUMMARY.md").write_text("\n\n".join(report))
    print("\n\n".join(report) if report else "no results found")


if __name__ == "__main__":
    main()
