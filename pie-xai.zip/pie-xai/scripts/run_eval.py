#!/usr/bin/env python
"""Run every experiment of the paper and write one JSON line per pair.

Examples
  python scripts/run_eval.py --detector yolov5 --experiment main
  python scripts/run_eval.py --detector detr --experiment main --shard 0 --num-shards 4
  python scripts/run_eval.py --detector yolov5 --experiment main --dataset vg --methods pie odam
  python scripts/run_eval.py --detector yolov5 --experiment hparam        # Table 6 (train2017)
  python scripts/run_eval.py --detector yolov5 --experiment sensitivity --max-pairs 500
  python scripts/run_eval.py --detector yolov5 --experiment replacement --max-pairs 500

Runs are resumable: pairs already present in the output file are skipped.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pie.config import load_config, seed_everything, with_overrides  # noqa: E402
from pie.data.coco import CocoPairs, ensure_coco, pair_key  # noqa: E402
from pie.detectors import build_detector  # noqa: E402
from pie.evaluate import ALL_METHODS, Timer, evaluate_pair, pie_variant_morf, targets_for, units_for  # noqa: E402

try:
    from tqdm import tqdm
except ImportError:                                   # pragma: no cover
    def tqdm(x, **k):
        return x


def jsonable(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


def load_pairs(args, cfg):
    d = cfg["data"]
    if args.dataset == "vg":
        from pie.data.vg import VGPairs
        ds = VGPairs(d["vg_root"], d["vg_annotated"], d["vg_plain"], d["vg_max_iou"], seed=cfg["seed"])
        return ds, ds.pairs
    split = "train2017" if args.experiment == "hparam" else "val2017"
    ensure_coco(d["coco_root"], need_val_images=(split == "val2017"))
    ds = CocoPairs(d["coco_root"], split, [tuple(p) for p in d["class_pairs"]], d["min_area"],
                   d["min_contact"], d["max_pairs_per_image"])
    pairs = ds.sample(d["hparam_pairs"], cfg["seed"]) if args.experiment == "hparam" else ds.pairs
    return ds, pairs


def run_variants(det, img, row, cfg, grid, rec):
    di, dj = targets_for(det, img, row)
    if di is None or dj is None:
        return None, "target not detected"
    base_units = units_for(det, img, di, dj, cfg)
    if base_units is None:
        return None, "union too small for K units"
    rec.update(s_i=di["score"], s_j=dj["score"], S_ij=di["score"] * dj["score"])
    for name, values in grid.items():
        for v in values:
            c = with_overrides(cfg, **{name: v})
            units = units_for(det, img, di, dj, c, K=v) if name == "K" else base_units
            out = pie_variant_morf(det, img, di, dj, c, units=units) if units is not None else None
            rec[f"morf_{name}={v}"] = None if out is None else out[1]
    return rec, None


def run_replacement(det, img, row, cfg, ops, rec):
    di, dj = targets_for(det, img, row)
    if di is None or dj is None:
        return None, "target not detected"
    units = units_for(det, img, di, dj, cfg)
    if units is None:
        return None, "union too small for K units"
    ref = None
    for op in ops:
        with Timer() as t:
            P, m, i = pie_variant_morf(det, img, di, dj, cfg, units=units, replacement=op)
        rec[f"morf_{op}"], rec[f"time_{op}"] = m, t.dt
        if ref is None:
            ref = P.ce
        rec[f"spearman_{op}"] = 1.0 if op == ops[0] else float(stats.spearmanr(ref, P.ce)[0])
    return rec, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--detector", required=True, choices=["yolov5", "faster_rcnn", "detr"])
    ap.add_argument("--experiment", default="main", choices=["main", "hparam", "sensitivity", "replacement"])
    ap.add_argument("--dataset", default="coco", choices=["coco", "vg"])
    ap.add_argument("--methods", nargs="*", default=list(ALL_METHODS))
    ap.add_argument("--max-pairs", type=int, default=None)
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--num-shards", type=int, default=1)
    ap.add_argument("--external-dir", default=None, help="folder of external maps (e.g. GCE, CoE)")
    ap.add_argument("--out", default="results")
    ap.add_argument("--set", nargs="*", default=[], help="config overrides, e.g. K=8 drise.n_masks=4000")
    args = ap.parse_args()

    cfg = load_config(args.config, args.set)
    seed_everything(cfg["seed"])
    ds, pairs = load_pairs(args, cfg)
    if args.max_pairs:
        rng = np.random.default_rng(cfg["seed"])
        pairs = [pairs[i] for i in sorted(rng.permutation(len(pairs))[: args.max_pairs])]
    pairs = pairs[args.shard::args.num_shards]

    out_dir = Path(args.out) / args.experiment / args.dataset
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{args.detector}_shard{args.shard}of{args.num_shards}.jsonl"
    skip_log = out.with_suffix(".skipped.jsonl")
    done = set()
    for f in (out, skip_log):
        if f.exists():
            done |= {json.loads(l)["key"] for l in open(f)}
    (out_dir / "config_used.json").write_text(json.dumps(dict(cfg=cfg, args=vars(args)), indent=2))

    det = build_detector(args.detector, cfg)
    t0 = time.time()
    with open(out, "a") as fo, open(skip_log, "a") as fs:
        for row in tqdm(pairs, desc=f"{args.experiment}/{args.dataset}/{args.detector}"):
            key = pair_key(row) + ("_" + row.get("predicate", "") if args.dataset == "vg" else "")
            if key in done:
                continue
            img = ds.image(row["image_id"])
            base = dict(row, key=key, detector=args.detector, dataset=args.dataset)
            try:
                if args.experiment == "main":
                    rec, info = evaluate_pair(det, img, row, cfg, args.methods, args.external_dir)
                    if rec is not None:
                        rec.update(key=key, dataset=args.dataset)
                elif args.experiment in ("hparam", "sensitivity"):
                    rec, info = run_variants(det, img, row, cfg, cfg["experiments"][args.experiment], base)
                else:
                    rec, info = run_replacement(det, img, row, cfg, cfg["experiments"]["replacement"], base)
            except Exception as e:                                   # recorded, never silently dropped
                rec, info = None, f"error: {type(e).__name__}: {e}"
            if rec is None:
                fs.write(json.dumps(dict(base, reason=info), default=jsonable) + "\n"); fs.flush()
            else:
                fo.write(json.dumps(rec, default=jsonable) + "\n"); fo.flush()
    print(f"done in {(time.time() - t0) / 60:.1f} min -> {out}")


if __name__ == "__main__":
    main()
