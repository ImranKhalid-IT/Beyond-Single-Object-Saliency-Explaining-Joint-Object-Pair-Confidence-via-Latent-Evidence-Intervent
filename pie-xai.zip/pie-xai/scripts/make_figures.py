#!/usr/bin/env python
"""Figures of the paper, recomputed from the code (all text bold DejaVu Serif, vector PDF).

  python scripts/make_figures.py qualitative --detector yolov5          # Fig. 15 (2 x 4 grid)
  python scripts/make_figures.py comparison  --detector yolov5 --image-id 367095 --classes person laptop   # Fig. 16
  python scripts/make_figures.py charts      --tables results/tables     # Figs. 9, 11, 12

Qualitative examples are chosen by a fixed rule that is written into the caption file.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

from pie.config import load_config, seed_everything  # noqa: E402
from pie.geometry import box_mask  # noqa: E402

STYLE = {"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 7, "font.weight": "bold",
         "axes.titleweight": "bold", "axes.labelweight": "bold", "mathtext.fontset": "dejavuserif",
         "mathtext.default": "bf", "pdf.fonttype": 42, "ps.fonttype": 42}


# ----------------------------------------------------------------------------- helpers
def crop_window(U, W, H, pad=0.30, aspect=4 / 3):
    cx, cy = (U[0] + U[2]) / 2, (U[1] + U[3]) / 2
    w, h = (U[2] - U[0]) * (1 + 2 * pad), (U[3] - U[1]) * (1 + 2 * pad)
    if w / h < aspect:
        w = h * aspect
    else:
        h = w / aspect
    w, h = min(w, W), min(h, H)
    return float(np.clip(cx - w / 2, 0, W - w)), float(np.clip(cy - h / 2, 0, H - h)), w, h


def img_panel(ax, img, win, title, fs=5.6):
    ax.imshow(img, interpolation="none")
    if win is not None:
        x0, y0, w, h = win
        ax.set_xlim(x0, x0 + w); ax.set_ylim(y0 + h, y0)
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_title(title, fontsize=fs, pad=2)
    for s in ax.spines.values():
        s.set_linewidth(0.4)


def draw_boxes(ax, di, dj, fs=4.8):
    for d, col in ((di, "#17BECF"), (dj, "#F1C40F")):
        b = d["box"]
        ax.add_patch(Rectangle((b[0], b[1]), b[2] - b[0], b[3] - b[1], fill=False, ec=col, lw=1.1))
        ax.text(b[0], b[1], f'{d["cls"]} {d["score"]:.2f}', fontsize=fs, va="bottom",
                bbox=dict(fc=col, ec="none", pad=0.6), clip_on=True)


def ranking_panel(ax, P, title="$CE_k$ ranking", fs=4.8):
    order = P.order(); vals = P.ce[order]; K = len(vals); y = np.arange(K)[::-1]; S = P.S
    cols = ["#E8743B"] + ["#F2A97E" if v >= 0 else "#B0B0B0" for v in vals[1:]]
    ax.barh(y, vals, color=cols, height=0.7, edgecolor="#7a3b1b", linewidth=0.3)
    for yy, vv in zip(y, vals):
        ax.text(max(vv, 0) + 0.02 * S, yy, f"{vv:.3f}", fontsize=fs - 0.5, va="center", ha="left")
    ax.set_yticks(y); ax.set_yticklabels([f"U{q + 1}" for q in order], fontsize=fs)
    ax.axvline(0, color="k", lw=0.4); ax.axvline(S, color="k", lw=0.5, ls="--")
    ax.text(S, -0.95, r"$S_{ij}$", fontsize=fs, ha="center", va="top")
    ax.set_xlim(min(0.0, vals.min()) - 0.03 * S, S * 1.38); ax.set_ylim(-0.6, K - 0.4)
    ax.tick_params(axis="x", labelsize=fs - 0.3, length=1.5, pad=1); ax.tick_params(axis="y", length=0, pad=1)
    ax.set_xlabel(r"$CE_k$", fontsize=fs + 0.2, labelpad=3); ax.set_title(title, fontsize=fs + 0.8, pad=2)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def top_unit_overlay(ax, P):
    top = int(P.order()[0]); m = P.masks[top]; heat = P.maps[top].copy(); v = heat[m]
    heat = (heat - v.min()) / (v.max() - v.min() + 1e-8)
    ax.imshow(np.where(m, heat, np.nan), cmap="jet", alpha=0.6, vmin=0, vmax=1, interpolation="none")
    U = P.union
    ax.add_patch(Rectangle((U[0], U[1]), U[2] - U[0], U[3] - U[1], fill=False, ec="white", lw=0.9, ls="--"))
    return top


def shared_coverage(mask, bi, bj):
    n = mask.sum() + 1e-8; H, W = mask.shape
    return float(min((mask & box_mask(bi, W, H)).sum() / n, (mask & box_mask(bj, W, H)).sum() / n))


# ----------------------------------------------------------------------------- Fig. 15
def qualitative(args, cfg):
    from pie.data.coco import CocoPairs, ensure_coco
    from pie.detectors import build_detector
    from pie.evaluate import targets_for
    from pie.intervention import explain_pair

    ensure_coco(cfg["data"]["coco_root"])
    det = build_detector(args.detector, cfg)
    chosen, log = [], []
    for spec in args.examples:
        a, b, n = spec.split(":")
        ds = CocoPairs(cfg["data"]["coco_root"], "val2017", [(a.replace("_", " "), b.replace("_", " "))],
                       args.min_area, args.min_contact, max_pairs_per_image=1)
        cands = sorted(ds.pairs, key=lambda r: -r["contact"])[: args.candidates]   # most overlapping first
        scored = []
        for row in cands:
            img = ds.image(row["image_id"]); di, dj = targets_for(det, img, row)
            if di is None or dj is None or min(di["score"], dj["score"]) < args.min_score:
                continue
            P = explain_pair(det, img, di, dj, cfg)
            if P is None:
                continue
            o = P.order(); top, sec = int(o[0]), int(o[1])
            both = bool(P.post[top, 0] < di["score"] and P.post[top, 1] < dj["score"])
            rec = dict(image_id=row["image_id"], pair=f"{a}+{b}", contact=row["contact"], S=P.S,
                       ce_norm=float(P.ce[top] / P.S), gap=float((P.ce[top] - P.ce[sec]) / P.S),
                       shared=shared_coverage(P.masks[top], di["box"], dj["box"]), both=both)
            log.append(rec)
            if both and rec["shared"] >= args.min_shared:
                scored.append((rec, row))
        scored.sort(key=lambda t: (-round(t[0]["ce_norm"], 2), -t[0]["gap"], -t[0]["shared"]))
        for rec, row in scored[: int(n)]:
            chosen.append((row, ds))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "fig15_candidates.json").write_text(json.dumps(log, indent=1))

    plt.rcParams.update(STYLE)
    ncols = 4; nrows = math.ceil(len(chosen) / ncols)
    fig = plt.figure(figsize=(7.16, 2.05 * nrows))
    outer = fig.add_gridspec(nrows, ncols, wspace=0.10, hspace=0.30)
    for n, (row, ds) in enumerate(chosen):
        img = ds.image(row["image_id"]); di, dj = targets_for(det, img, row)
        P = explain_pair(det, img, di, dj, cfg)
        H, W = img.shape[:2]; win = crop_window(P.union, W, H)
        hdr = fig.add_subplot(outer[n // ncols, n % ncols]); hdr.axis("off")
        hdr.set_title(f'({n + 1}) {row["class_i"]} + {row["class_j"]}', fontsize=7, pad=10)
        g = outer[n // ncols, n % ncols].subgridspec(2, 2, wspace=0.34, hspace=0.32)
        ax = fig.add_subplot(g[0, 0]); img_panel(ax, img, win, "1. Pair"); draw_boxes(ax, di, dj)
        ax.text(0.02, 0.03, f'COCO {row["image_id"]}', transform=ax.transAxes, fontsize=4.3, color="white",
                va="bottom", bbox=dict(fc="black", alpha=0.55, ec="none", pad=0.5))
        ax = fig.add_subplot(g[0, 1]); img_panel(ax, img, win, r"2. Union $\Omega_{ij}$")
        U = P.union
        ax.add_patch(Rectangle((U[0], U[1]), U[2] - U[0], U[3] - U[1], fc="#C000C0", alpha=0.28, ec="#C000C0", lw=1.1))
        ax = fig.add_subplot(g[1, 0]); img_panel(ax, img, win, f"3. Top: U{int(P.order()[0]) + 1}")
        top_unit_overlay(ax, P)
        ranking_panel(fig.add_subplot(g[1, 1]), P, "4. $CE_k$ ranking")
    fig.savefig(out / "fig15_qualitative.pdf", bbox_inches="tight", dpi=600)
    fig.savefig(out / "fig15_qualitative.png", bbox_inches="tight", dpi=300)
    cap = (r"\caption{MS-COCO examples of \ours{} (" + det.name + r"). Panels: detected pair, union region "
           r"$\Omega_{ij}$, top-ranked unit, and $CE_k$ of all $K=" + str(cfg["K"]) + r"$ units (dashed line: $S_{ij}$; "
           r"ties at $CE_k=S_{ij}$ are ordered by the lower remaining score). Only pairs whose boxes overlap "
           r"(intersection over the smaller box $\geq " + str(args.min_contact) + r"$) were considered; for each class "
           r"pair the examples are those with the largest $CE_{\max}/S_{ij}$ among " + str(args.candidates) +
           r" candidates whose top unit lowers both detections and lies at least " + str(int(100 * args.min_shared)) +
           r"\% on each box. Unit indices carry no meaning across images.}")
    (out / "fig15_caption.tex").write_text(cap)
    print("saved", out / "fig15_qualitative.pdf")


# ----------------------------------------------------------------------------- Fig. 16
def comparison(args, cfg):
    from pie import baselines as B
    from pie.data.coco import CocoPairs, ensure_coco
    from pie.detectors import build_detector
    from pie.evaluate import targets_for
    from pie.intervention import explain_pair

    ensure_coco(cfg["data"]["coco_root"])
    det = build_detector(args.detector, cfg)
    a, b = [c.replace("_", " ") for c in args.classes]
    ds = CocoPairs(cfg["data"]["coco_root"], "val2017", [(a, b)], max_pairs_per_image=1)
    row = next(r for r in ds.pairs if r["image_id"] == args.image_id)
    img = ds.image(row["image_id"]); di, dj = targets_for(det, img, row)
    P = explain_pair(det, img, di, dj, cfg)
    rng = np.random.default_rng(cfg["seed"])
    maps = {"Grad-CAM": [det.gradient_map(img, [d], "gradcam") for d in (di, dj)],
            "ODAM": [det.gradient_map(img, [d], "odam") for d in (di, dj)],
            "D-RISE": B.drise(det, img, [di, dj], args.drise_masks, cfg["drise"]["grid"], cfg["drise"]["p"], rng)}
    if det.name not in cfg.get("finercam_skip", []):
        maps["Finer-CAM"] = [det.gradient_map(img, [d], "finercam") for d in (di, dj)]
    ro = det.readout(img, P.union)
    maps["CRAFT-adapted"] = [B.craft_adapted(det, img, ro, P.union, d, cfg["craft"]["n_concepts"], cfg["craft"]["n_sobol"],
                                             cfg["sigma"], cfg["theta_m"], seed=cfg["seed"])[0] for d in (di, dj)]
    plt.rcParams.update(STYLE)
    ncol = len(maps) + 1
    fig = plt.figure(figsize=(7.16, 2.2))
    gs = fig.add_gridspec(2, ncol + 1, width_ratios=[1] * ncol + [1.25], wspace=0.08, hspace=0.25)
    ax = fig.add_subplot(gs[0, 0]); img_panel(ax, img, None, "Target pair", 6); draw_boxes(ax, di, dj, 5)
    ax = fig.add_subplot(gs[1, 0]); img_panel(ax, img, None, r"Union $\Omega_{ij}$", 6)
    U = P.union
    ax.add_patch(Rectangle((U[0], U[1]), U[2] - U[0], U[3] - U[1], fc="#C000C0", alpha=0.28, ec="#C000C0", lw=1.1))
    for c, (name, (ri, rj)) in enumerate(maps.items(), start=1):
        for r, (m, d) in enumerate(((ri, di), (rj, dj))):
            ax = fig.add_subplot(gs[r, c]); img_panel(ax, img, None, f'{name}: {d["cls"]}', 5.6)
            ax.imshow(m, cmap="jet", alpha=0.5, interpolation="none")
    ax = fig.add_subplot(gs[0, ncol]); img_panel(ax, img, None, f"PIE: top unit U{int(P.order()[0]) + 1}", 6)
    top_unit_overlay(ax, P)
    ranking_panel(fig.add_subplot(gs[1, ncol]), P, "PIE: $CE_k$ ranking", 5)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / f"fig16_comparison_{args.image_id}.pdf", bbox_inches="tight", dpi=600)
    fig.savefig(out / f"fig16_comparison_{args.image_id}.png", bbox_inches="tight", dpi=300)
    print("saved", out / f"fig16_comparison_{args.image_id}.pdf")


# ----------------------------------------------------------------------------- charts
def charts(args, cfg):
    import pandas as pd
    plt.rcParams.update(STYLE)
    T = Path(args.tables); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    if (T / "table7_morf.csv").exists():
        t = pd.read_csv(T / "table7_morf.csv", index_col=0).drop(columns="Mean")
        ax = t.T.plot.bar(figsize=(3.5, 2.2), width=0.8, rot=0, legend=True)
        ax.set_ylabel("MoRF-AUC (lower is better)"); ax.legend(fontsize=4.5, ncol=2, frameon=False)
        plt.tight_layout(); plt.savefig(out / "fig9_morf_bars.pdf"); plt.close()
    if (T / "fig11_ce_values.csv").exists():
        d = pd.read_csv(T / "fig11_ce_values.csv")
        fig, ax = plt.subplots(figsize=(3.5, 2.0))
        ax.hist(d["CE_k"], bins=60, density=True, color="#2E6DA4")
        ax.set_xlabel(r"Confidence effect $CE_k$"); ax.set_ylabel("Density")
        plt.tight_layout(); plt.savefig(out / "fig11_ce_distribution.pdf"); plt.close()
    if (T / "sensitivity.csv").exists():
        t = pd.read_csv(T / "sensitivity.csv", index_col=0)
        fig, axes = plt.subplots(1, 3, figsize=(7.16, 1.9))
        for ax, name in zip(axes, ["K", "sigma", "mask_percentile"]):
            rows = t[t.index.str.startswith(name + "=")]
            x = [float(i.split("=")[1]) for i in rows.index]
            for c in rows.columns:
                ax.plot(x, rows[c], marker="o", ms=2.5, lw=1, label=c)
            ax.axvline(cfg[name], ls="--", color="gray", lw=0.6); ax.set_xlabel(name); ax.set_ylabel("MoRF-AUC")
        axes[0].legend(fontsize=4.5, frameon=False)
        plt.tight_layout(); plt.savefig(out / "fig12_sensitivity.pdf"); plt.close()
    print("charts written to", out)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("qualitative", "comparison", "charts"):
        p = sub.add_parser(name)
        p.add_argument("--config", default="configs/default.yaml")
        p.add_argument("--out", default="results/figures")
        p.add_argument("--detector", default="yolov5")
    q = sub.choices["qualitative"]
    q.add_argument("--examples", nargs="*", default=["dog:frisbee:2", "person:laptop:2", "person:horse:2",
                                                     "person:motorcycle:1", "person:cup:1"])
    q.add_argument("--candidates", type=int, default=60)
    q.add_argument("--min-contact", type=float, default=0.30)
    q.add_argument("--min-shared", type=float, default=0.20)
    q.add_argument("--min-score", type=float, default=0.50)
    q.add_argument("--min-area", type=float, default=900)
    c = sub.choices["comparison"]
    c.add_argument("--image-id", type=int, required=True)
    c.add_argument("--classes", nargs=2, required=True)
    c.add_argument("--drise-masks", type=int, default=4000)
    sub.choices["charts"].add_argument("--tables", default="results/tables")
    args = ap.parse_args()
    cfg = load_config(args.config); seed_everything(cfg["seed"])
    {"qualitative": qualitative, "comparison": comparison, "charts": charts}[args.cmd](args, cfg)


if __name__ == "__main__":
    main()
