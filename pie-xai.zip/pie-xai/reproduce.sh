#!/usr/bin/env bash
# Reproduces every table and figure of the paper. Each step resumes if interrupted.
set -euo pipefail
cd "$(dirname "$0")"

python -m pytest -q tests

for D in yolov5 faster_rcnn detr; do
  python scripts/run_eval.py --detector $D --experiment hparam                      # Table 6
  python scripts/run_eval.py --detector $D --experiment main                        # Tables 3, 7-9, 11
  python scripts/run_eval.py --detector $D --experiment sensitivity --max-pairs 500 # Figs. 12-13
done
python scripts/run_eval.py --detector yolov5 --experiment replacement --max-pairs 500           # Table 10
python scripts/run_eval.py --detector yolov5 --experiment main --dataset vg --methods pie odam   # Tables 12-13

python scripts/make_tables.py
python scripts/make_figures.py charts
python scripts/make_figures.py qualitative --detector yolov5
python scripts/make_figures.py comparison --detector yolov5 --image-id 367095 --classes person laptop
echo "tables: results/tables   figures: results/figures"
