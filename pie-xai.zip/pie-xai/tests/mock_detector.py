"""A tiny deterministic 'detector' used to test the full PIE pipeline without a GPU.

Two textured objects are painted on a flat background. The score of an object is the amount of
high-frequency texture left inside its box, so blurring evidence lowers the score exactly as an
intervention should. Features are local texture statistics on a 16-pixel grid.
"""
import cv2
import numpy as np

from pie.detectors.base import Detector, cells_for_region
from pie.geometry import norm01
from pie.units import Readout

BOX_A = np.array([40, 30, 150, 200], np.float32)     # "person"
BOX_B = np.array([110, 120, 230, 210], np.float32)   # "laptop", overlaps A


def make_image(h=240, w=320, seed=0):
    rng = np.random.default_rng(seed)
    img = np.full((h, w, 3), 120, np.uint8)
    for b, period in ((BOX_A, 4), (BOX_B, 6)):
        x0, y0, x1, y1 = b.astype(int)
        yy, xx = np.mgrid[y0:y1, x0:x1]
        tex = 127 + 100 * np.sign(np.sin(xx / period * np.pi) * np.sin(yy / period * np.pi))
        img[y0:y1, x0:x1] = np.clip(tex[..., None] + rng.normal(0, 5, (y1 - y0, x1 - x0, 1)), 0, 255)
    return img


class MockDetector(Detector):
    name, family = "mock", "one-stage"

    def __init__(self, conf=0.25):
        self.conf = conf
        self.ref = {k: self._texture(make_image(), b) for k, b in (("person", BOX_A), ("laptop", BOX_B))}

    @staticmethod
    def _texture(img, b):
        g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(np.float32)
        hp = np.abs(g - cv2.GaussianBlur(g, (0, 0), 2))
        x0, y0, x1, y1 = b.astype(int)
        return float(hp[y0:y1, x0:x1].mean())

    def detect_many(self, images):
        out = []
        for im in images:
            dets = []
            for cls, b in (("person", BOX_A), ("laptop", BOX_B)):
                s = min(0.99, self._texture(im, b) / self.ref[cls] * 0.95)
                if s >= self.conf:
                    dets.append(dict(box=b.copy(), score=float(s), cls=cls))
            out.append(dets)
        return out

    def readout(self, image, union_box):
        g = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY).astype(np.float32)
        hp = np.abs(g - cv2.GaussianBlur(g, (0, 0), 2))
        cell = 16
        h, w = g.shape[0] // cell, g.shape[1] // cell
        feats = []
        for f in (g, hp, cv2.Sobel(g, cv2.CV_32F, 1, 0), cv2.Sobel(g, cv2.CV_32F, 0, 1)):
            feats.append(cv2.resize(np.abs(f), (w, h), interpolation=cv2.INTER_AREA))
        F = np.stack(feats, -1) + 1e-3
        r0, r1, c0, c1, inside, extent = cells_for_region(union_box, 0, 0, cell, cell, w, h)
        return Readout(grid=F[r0:r1, c0:c1], extent=extent, inside=inside)

    def gradient_map(self, image, targets, kind="odam"):
        H, W = image.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]
        m = np.zeros((H, W), np.float32)
        for t in targets:
            b = t["box"]; cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
            m += np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * 40 ** 2))
        return norm01(m)
