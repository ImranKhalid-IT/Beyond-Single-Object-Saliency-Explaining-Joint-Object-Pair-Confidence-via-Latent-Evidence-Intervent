import numpy as np
import pytest

from pie.geometry import box_mask, contact, iou, union_box
from pie.intervention import explain_pair, top_fraction_mask
from pie.matching import match_pair
from pie.metrics import deletion_insertion, map_pixel_order, unit_pixel_order
from pie.units import Readout, discover_units

from mock_detector import BOX_A, BOX_B, MockDetector, make_image

CFG = dict(K=8, tau_s=0.05, mask_percentile=85, sigma=15, metric_sigma=15, theta_m=0.5, seed=42,
           kmeans_n_init=4, n_fractions=11, pcgrid_n=8, finercam_skip=[], batch=8,
           drise=dict(n_masks=40, grid=8, p=0.5, mean_center=True), craft=dict(n_concepts=4, n_sobol=4))


def d(box, s, c):
    return dict(box=np.array(box, np.float32), score=s, cls=c)


# ---------------------------------------------------------------- geometry
def test_iou_and_union():
    assert iou([0, 0, 10, 10], [0, 0, 10, 10]) == pytest.approx(1.0)
    assert iou([0, 0, 10, 10], [10, 10, 20, 20]) == pytest.approx(0.0)
    assert list(union_box([0, 5, 10, 10], [5, 0, 20, 8])) == [0, 0, 20, 10]
    assert contact([0, 0, 10, 10], [2, 2, 4, 4]) == pytest.approx(1.0)


# ---------------------------------------------------------------- matching (Eqs. 30-33)
def test_matching_one_to_one_same_class():
    di, dj = d([0, 0, 10, 10], 0.9, "person"), d([1, 1, 11, 11], 0.8, "person")
    post = [d([0, 0, 10, 10], 0.7, "person")]
    si, sj = match_pair(post, di, dj, 0.5)
    assert (si, sj) in [(0.7, 0.0), (0.0, 0.7)]          # one detection cannot serve both targets


def test_matching_lost_target_is_zero():
    di, dj = d([0, 0, 10, 10], 0.9, "person"), d([20, 20, 30, 30], 0.8, "laptop")
    assert match_pair([d([0, 0, 10, 10], 0.6, "person")], di, dj, 0.5) == (0.6, 0.0)
    assert match_pair([d([0, 0, 10, 10], 0.6, "laptop")], di, dj, 0.5) == (0.0, 0.0)   # class must agree


# ---------------------------------------------------------------- masks and units
def test_top_fraction_mask_exact_area():
    omega = box_mask([10, 10, 50, 40], 64, 64)
    m = top_fraction_mask(np.zeros((64, 64)), omega, 0.15)            # all values tied
    assert m.sum() == int(np.ceil(0.15 * omega.sum())) and not (m & ~omega).any()


def test_units_partition_property():
    rng = np.random.default_rng(0)
    grid = rng.random((6, 8, 5)).astype(np.float32)
    ro = Readout(grid=grid, extent=(0, 0, 128, 96), inside=np.ones((6, 8), bool))
    u = discover_units(ro, [10, 10, 120, 90], 128, 96, K=4, tau_s=0.05, n_init=2)
    s = u["maps"].sum(0)[u["omega"]]
    assert np.allclose(s, 1.0, atol=1e-4)                              # Eq. 23 on every pixel of Omega
    assert np.all(u["maps"][:, ~u["omega"]] == 0)                      # Eq. 24: zero outside Omega


# ---------------------------------------------------------------- CE algebra (Eqs. 34-35)
def test_ce_decomposition_and_bounds():
    det, img = MockDetector(), make_image()
    di, dj = [x for x in det.detect(img)]
    P = explain_pair(det, img, di, dj, CFG)
    assert np.allclose(P.ce, P.fo - P.cross, atol=1e-6)                 # CE = FO - ds_i ds_j
    assert np.all(P.ce <= P.S + 1e-6) and np.all(P.ce >= P.S - 1 - 1e-6)
    assert P.n_forward == CFG["K"] + 1                                  # Eq. 37


def test_worked_example_from_paper():
    si = sj = 0.9; dsi = dsj = -0.9                                     # both targets lost
    fo = -(sj * dsi + si * dsj); ce = fo - dsi * dsj
    assert fo == pytest.approx(1.62) and ce == pytest.approx(0.81)


# ---------------------------------------------------------------- metric
def test_pixel_orders_cover_union_once():
    omega = box_mask([5, 5, 40, 30], 48, 36)
    maps = np.random.default_rng(1).random((3, 36, 48)) * omega
    masks = np.stack([top_fraction_mask(m, omega, 0.15) for m in maps])
    ys, xs = unit_pixel_order(np.array([0.1, 0.5, 0.3]), maps, masks, omega)
    assert len(ys) == omega.sum() and len(set(zip(ys, xs))) == omega.sum()
    first = masks[1][ys[: masks[1].sum()], xs[: masks[1].sum()]]
    assert first.all()                                                  # highest-CE unit's mask is deleted first
    ys2, xs2 = map_pixel_order(maps[0], omega)
    assert len(ys2) == omega.sum()


def test_pie_beats_reverse_order_on_mock():
    det, img = MockDetector(), make_image()
    di, dj = det.detect(img)
    P = explain_pair(det, img, di, dj, CFG)
    fr = np.linspace(0, 1, CFG["n_fractions"])
    good = unit_pixel_order(P.ce, P.maps, P.masks, P.omega, P.post.sum(1))
    bad = unit_pixel_order(-P.ce, P.maps, P.masks, P.omega)
    m_good, i_good, curve, _ = deletion_insertion(det, img, P.omega, good, di, dj, fr, 15, 0.5)
    m_bad, _, _, _ = deletion_insertion(det, img, P.omega, bad, di, dj, fr, 15, 0.5)
    assert curve[0] == pytest.approx(1.0, abs=1e-6)                     # alpha = 0 keeps S_ij
    assert m_good <= m_bad


# ---------------------------------------------------------------- full evaluation of one pair
def test_evaluate_pair_all_methods():
    from pie.evaluate import ALL_METHODS, evaluate_pair
    det, img = MockDetector(), make_image()
    row = dict(image_id=1, class_i="person", class_j="laptop", gt_i=BOX_A.tolist(), gt_j=BOX_B.tolist())
    rec, _ = evaluate_pair(det, img, row, CFG, ALL_METHODS)
    for m in ALL_METHODS:
        assert 0.0 <= rec[f"morf_{m}"] <= 1.5 and 0.0 <= rec[f"ins_{m}"] <= 1.5, m
    assert rec["ce_max"] <= rec["S_ij"] + 1e-6


def test_replacement_and_variants():
    from pie.evaluate import pie_variant_morf, units_for
    det, img = MockDetector(), make_image()
    di, dj = det.detect(img)
    units = units_for(det, img, di, dj, CFG)
    for op in ("gaussian", "mean", "noise", "inpaint"):
        P, m, i = pie_variant_morf(det, img, di, dj, CFG, units=units, replacement=op)
        assert 0 <= m <= 1.5 and len(P.ce) == CFG["K"]
